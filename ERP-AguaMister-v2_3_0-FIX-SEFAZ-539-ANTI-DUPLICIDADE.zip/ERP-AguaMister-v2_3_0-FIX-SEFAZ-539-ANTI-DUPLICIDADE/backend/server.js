/**
 * ============================================================
 *  ERP AGUA MISTER - Backend NF-e / NFC-e (v1.7.0)
 *  Node.js + Express | Porta 3000
 *  Assina XML com certificado A1 (.pfx) e transmite à SEFAZ
 * ============================================================
 */

'use strict';

const express    = require('express');
const cors       = require('cors');
const https      = require('https');
const tls        = require('tls');
const http       = require('http');
const fs         = require('fs');
const path       = require('path');
const forge      = require('node-forge');
const crypto     = require('crypto');
const { SignedXml } = require('xml-crypto');
const archiver   = require('archiver');
const { exec, execFile }   = require('child_process');
const os         = require('os');
const PDFDocument = require('pdfkit');

const app  = express();
const PORT = 3000;

// -- Middleware --
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '30mb' })); // aumentado pra caber o estado completo do ERP (clientes, vendas, financeiro...)
app.use(express.urlencoded({ extended: true }));

// Servir o ERP estático - o manual pede pra colocar o
// erp_aguamister.html na pasta PAI (ao lado de backend/), então
// procuramos ali primeiro; se não achar, tentamos dentro da própria
// pasta backend/ também (caso o usuário tenha colocado os dois juntos).
const ERP_FILE_PAI  = path.join(__dirname, '..', 'erp_aguamister.html');
const ERP_FILE_AQUI = path.join(__dirname, 'erp_aguamister.html');
app.get('/', (req, res) => {
  if (fs.existsSync(ERP_FILE_PAI))       res.sendFile(ERP_FILE_PAI);
  else if (fs.existsSync(ERP_FILE_AQUI)) res.sendFile(ERP_FILE_AQUI);
  else res.send('<h2>ERP Agua Mister - coloque o arquivo erp_aguamister.html na pasta ACIMA desta (backend/), ou dentro dela.</h2><p>Mesmo sem isso, você pode simplesmente abrir o erp_aguamister.html direto no navegador - o backend continua funcionando normalmente para emissão real, ele só não fica disponível em http://localhost:3000/.</p>');
});

// -- Armazenar certificado em memória (carregado via API) --
let CERT_STATE = {
  loaded:   false,
  pfxB64:   null,
  senha:    null,
  cert:     null,   // node-forge certificate
  key:      null,   // node-forge private key
  certPem:  null,
  keyPem:   null,
  validade: null,
  cnpj:     null,
  nome:     null,
};

// -- Estado de numeração --
let NUMERACAO = {
  nfe:  1,
  nfce: 1,
};
// -- Estrutura de pastas organizada --
// Antes tudo ficava solto em backend/xml/. Agora fica tudo dentro de
// backend/dados/, separado por tipo - mais fácil de achar e de fazer
// backup de cada coisa isoladamente:
//   backend/dados/xml/         -> XML das notas (autorizadas e rejeitadas)
//   backend/dados/danfe-pdf/   -> cópia em PDF de cada DANFE já gerada
//   backend/dados/backups/     -> backups completos (.zip), com data/hora
const PASTA_DADOS      = path.join(__dirname, 'dados');
const PASTA_XML        = path.join(PASTA_DADOS, 'xml');
const PASTA_DANFE_PDF  = path.join(PASTA_DADOS, 'danfe-pdf');
const PASTA_BACKUPS    = path.join(PASTA_DADOS, 'backups');
const PASTA_LOGO       = path.join(__dirname, '..', 'logo');
const XML_SYNC_FILE    = path.join(PASTA_DADOS, 'xml-sync.json');
[PASTA_XML, PASTA_DANFE_PDF, PASTA_BACKUPS, PASTA_LOGO].forEach(p => fs.mkdirSync(p, { recursive: true }));
app.use('/logo', express.static(PASTA_LOGO));

// Sincronização contínua da pasta externa de XMLs. O ERP nunca apaga o
// arquivo arquivado em dados/xml: quando o usuário exclui o original da
// pasta monitorada, o sistema apenas sinaliza a ausência e oferece
// recuperação. Isso evita perda acidental do histórico fiscal.
let XML_SYNC = { ativo:false, pasta:'', arquivos:{}, eventos:[], proximoEventoId:1 };
if(fs.existsSync(XML_SYNC_FILE)) { try { const x=JSON.parse(fs.readFileSync(XML_SYNC_FILE,'utf8')); if(x&&typeof x==='object') XML_SYNC=Object.assign(XML_SYNC,x); } catch(e) {} }
function salvarXmlSync(){ try{ fs.writeFileSync(XML_SYNC_FILE, JSON.stringify(XML_SYNC,null,2), {mode:0o600}); }catch(e){ console.log('[!] Não foi possível salvar xml-sync.json:',e.message); } }
function xmlSyncEvento(tipo, arquivo, chave, detalhe){
  const ev={id:Number(XML_SYNC.proximoEventoId||1),tipo,arquivo:arquivo||'',chave:chave||'',detalhe:detalhe||'',data:new Date().toISOString()};
  XML_SYNC.proximoEventoId=ev.id+1; XML_SYNC.eventos=(XML_SYNC.eventos||[]).concat(ev).slice(-80); salvarXmlSync(); return ev;
}
function listarXmlRecursivo(dir, base=dir, out=[]){
  let ents=[]; try{ents=fs.readdirSync(dir,{withFileTypes:true});}catch(e){return out;}
  ents.forEach(ent=>{ const p=path.join(dir,ent.name); if(ent.isDirectory()){ if(!ent.isSymbolicLink()) listarXmlRecursivo(p,base,out); } else if(ent.isFile() && /\.xml$/i.test(ent.name)){ out.push({path:p,rel:path.relative(base,p),name:ent.name}); } });
  return out;
}
function hashArquivoXml(p){ try{ const st=fs.statSync(p); return st.size+':'+st.mtimeMs; }catch(e){return null;} }
function chaveDoXmlTexto(xml){ const m=String(xml||'').match(/Id=["']NFe(\d{44})["']/)||String(xml||'').match(/<chNFe>(\d{44})<\/chNFe>/); return m?m[1]:''; }
function catalogoXmlInterno(){
  const files=fs.existsSync(PASTA_XML)?fs.readdirSync(PASTA_XML).filter(f=>/\.xml$/i.test(f)):[];
  return files.map(nome=>{
    const p=path.join(PASTA_XML,nome); let xml=''; try{xml=fs.readFileSync(p,'utf8');}catch(e){}
    return extrairCatalogoXml(nome,p,xml);
  }).filter(Boolean);
}


// Migração automática: se existir a pasta antiga backend/xml/ (de uma
// versão anterior) com arquivos dentro, move tudo para dados/xml/ na
// primeira vez que o backend novo iniciar - para você não perder XMLs
// já emitidos ao atualizar.
(function migrarPastaAntiga(){
  const antiga = path.join(__dirname, 'xml');
  if (!fs.existsSync(antiga)) return;
  try {
    const arquivos = fs.readdirSync(antiga).filter(f => f.endsWith('.xml'));
    arquivos.forEach(f => {
      const destino = path.join(PASTA_XML, f);
      if (!fs.existsSync(destino)) fs.renameSync(path.join(antiga, f), destino);
    });
    if (arquivos.length) console.log(` Migrados ${arquivos.length} XML(s) de backend/xml/ para backend/dados/xml/`);
  } catch (e) { console.log('[!]  Não foi possível migrar backend/xml/ automaticamente:', e.message); }
})();

const NUM_FILE = path.join(__dirname, 'numeracao.json');
if (fs.existsSync(NUM_FILE)) {
  try { NUMERACAO = JSON.parse(fs.readFileSync(NUM_FILE)); } catch(e) {}
}
function salvarNumeracao() {
  // Escrita síncrona e imediata: a numeração reservada não pode ser perdida
  // se o backend for reiniciado entre duas transmissões.
  fs.writeFileSync(NUM_FILE, JSON.stringify(NUMERACAO));
}

// ============================================================
// RESERVA ATÔMICA DE NUMERAÇÃO FISCAL
// ============================================================
// Um dos motivos do cStat 539 voltar mesmo com a recuperação automática é
// concorrência: duas vendas podem chegar quase simultaneamente e ler o mesmo
// NUMERACAO antes que qualquer uma delas receba resposta da SEFAZ. As duas
// então montam a mesma série/número.
//
// A partir daqui o número é RESERVADO antes de montar/assinar o XML e o
// contador é persistido imediatamente. Assim cada transmissão concorrente
// recebe um número diferente, inclusive em NFC-e.
const EMISSAO_LOCKS = { nfe: Promise.resolve(), nfce: Promise.resolve() };

function comLockEmissao(modelo, tarefa) {
  const anterior = EMISSAO_LOCKS[modelo] || Promise.resolve();
  let liberar;
  const atual = new Promise(resolve => { liberar = resolve; });
  EMISSAO_LOCKS[modelo] = anterior.then(() => atual);
  return anterior.then(async () => {
    try { return await tarefa(); }
    finally { liberar(); }
  });
}

function numerosLocaisOcupados(modelo) {
  const usados = new Set();
  const mod = String(modelo);
  try {
    const arquivos = listarXmlRecursivo(PASTA_XML);
    for (const item of arquivos) {
      let xml = '';
      try { xml = fs.readFileSync(item.path, 'utf8'); } catch (_) { continue; }
      const chaves = [];
      const reId = /Id=[\"']NFe(\d{44})[\"']/gi;
      let m;
      while ((m = reId.exec(xml)) !== null) chaves.push(m[1]);
      const reCh = /<chNFe(?:\s[^>]*)?>(\d{44})<\/chNFe>/gi;
      while ((m = reCh.exec(xml)) !== null) chaves.push(m[1]);
      for (const chave of chaves) {
        if (chave.slice(20,22) === mod) {
          const n = Number(chave.slice(25,34));
          if (Number.isInteger(n) && n > 0) usados.add(n);
        }
      }
    }
  } catch (e) {
    console.warn('[NUMERACAO] Não foi possível varrer XMLs locais:', e.message);
  }
  return usados;
}

function proximaNumeracaoSegura(modelo, numeroSugerido) {
  const chaveModelo = modelo === '65' ? 'nfce' : 'nfe';
  const usados = numerosLocaisOcupados(modelo);
  let n = Math.max(1, Number(numeroSugerido) || 1);
  while (usados.has(n)) n++;
  // Reserva AGORA, antes da transmissão.
  NUMERACAO[chaveModelo] = n + 1;
  salvarNumeracao();
  return n;
}

function reservarProximoNumero(modelo) {
  const chaveModelo = modelo === '65' ? 'nfce' : 'nfe';
  return proximaNumeracaoSegura(modelo, NUMERACAO[chaveModelo]);
}

function numeroDaChave(chave) {
  const d = somenteDigitos(chave);
  return /^\d{44}$/.test(d) ? Number(d.slice(25, 34)) : null;
}

function reservarNumeroApos539(modelo, resultado, numeroAtual) {
  const chaveModelo = modelo === '65' ? 'nfce' : 'nfe';
  const chaveExistente = resultado && (resultado.chNFe || '');
  const nExistente = numeroDaChave(chaveExistente);
  const motivo = String(resultado && resultado.xMotivo || '');
  const m = motivo.match(/chNFe\s*:\s*(\d{44})/i);
  const nMotivo = m ? numeroDaChave(m[1]) : null;
  const maiorConhecido = Math.max(
    Number(NUMERACAO[chaveModelo]) || 1,
    Number(numeroAtual) + 1 || 1,
    nExistente != null ? nExistente + 1 : 1,
    nMotivo != null ? nMotivo + 1 : 1
  );
  return proximaNumeracaoSegura(modelo, maiorConhecido);
}

// -- Ambiente fiscal (homologação/produção) - trocável pelo próprio
// sistema, sem precisar editar os arquivos .bat/.sh. Persiste em disco
// para sobreviver a reinícios do backend. --
const AMBIENTE_FILE = path.join(__dirname, 'ambiente.json');
let AMBIENTE_ATUAL = process.env.NFE_AMBIENTE || 'homologacao';
if (fs.existsSync(AMBIENTE_FILE)) {
  try {
    const salvo = JSON.parse(fs.readFileSync(AMBIENTE_FILE)).ambiente;
    if (salvo === 'producao' || salvo === 'homologacao') AMBIENTE_ATUAL = salvo;
  } catch (e) {}
}
function salvarAmbiente(amb) {
  AMBIENTE_ATUAL = amb;
  fs.writeFileSync(AMBIENTE_FILE, JSON.stringify({ ambiente: amb, alteradoEm: new Date().toISOString() }));
}

app.get('/api/config/csc', (req, res) => {
  const h = CSC.homologacao || {};
  const p = CSC.producao || {};
  res.json({ ok: true,
    homologacao: { cadastrado: !!(h.id && h.codigo), idCSC: h.id || null },
    producao: { cadastrado: !!(p.id && p.codigo), idCSC: p.id || null }
  });
});

app.post('/api/config/csc', (req, res) => {
  const { ambiente, idCSC, csc } = req.body || {};
  if (ambiente !== 'homologacao' && ambiente !== 'producao') return res.status(400).json({ ok:false, erro:'Informe o ambiente do CSC: homologacao ou producao.' });
  const id = String(idCSC || '').trim();
  const codigo = String(csc || '').trim();
  if (!id || !codigo) return res.status(400).json({ ok:false, erro:'Informe o ID do CSC e o CSC.' });
  if (!/^\d{6}$/.test(id)) return res.status(400).json({ ok:false, erro:'O ID do CSC deve conter exatamente 6 dígitos.' });
  if (codigo.length < 16 || codigo.length > 36 || !/^[A-Za-z0-9]+$/.test(codigo)) return res.status(400).json({ ok:false, erro:'O CSC deve conter de 16 a 36 caracteres alfanuméricos.' });
  salvarCSC(ambiente, id, codigo);
  console.log('CSC NFC-e cadastrado para '+ambiente+' (ID '+id+')');
  res.json({ ok:true, cadastrado:true, ambiente, idCSC:id });
});

app.get('/api/config/ambiente', (req, res) => {
  res.json({ ok: true, ambiente: AMBIENTE_ATUAL });
});

app.get('/api/sefaz/protecao', (req, res) => {
  const tpAmb = String(req.query.tpAmb || (AMBIENTE_ATUAL === 'producao' ? '1' : '2'));
  const modelo = String(req.query.modelo || '55');
  const g = SEFAZ_GUARD[tpAmb + ':' + modelo] || null;
  const bloqueadoAte = g ? Number(g.blockedUntil || 0) : 0;
  res.json({ ok:true, ambiente: tpAmb === '1' ? 'producao' : 'homologacao', modelo, bloqueado: bloqueadoAte > Date.now(), bloqueadoAte: bloqueadoAte || null, ultimo656: g ? g.last656At : null });
});

app.post('/api/config/ambiente', (req, res) => {
  const { ambiente } = req.body;
  if (ambiente !== 'producao' && ambiente !== 'homologacao') {
    return res.status(400).json({ ok: false, erro: 'Ambiente deve ser "producao" ou "homologacao"' });
  }
  if (ambiente === 'producao' && !CERT_STATE.loaded) {
    return res.status(400).json({ ok: false, erro: 'Carregue o certificado A1 antes de mudar para produção - sem certificado nenhuma nota é transmitida de qualquer forma, mas é mais seguro garantir isso antes.' });
  }
  salvarAmbiente(ambiente);
  console.log(` Ambiente alterado para: ${ambiente.toUpperCase()}`);
  res.json({ ok: true, ambiente: AMBIENTE_ATUAL });
});


// ============================================================
//  EMPRESA (padrão - sobrescrita via /api/config)
// ============================================================
let EMPRESA = {
  nome:        'AGUA MISTER COMERCIO E SERVICOS ADMINISTRATIVOS LTDA',
  cnpj:        '65601139000136',
  cnpjFmt:     '65.601.139/0001-36',
  ie:          '158567867115',
  cuf:         '35',   // SP
  cmun:        '3550308', // São Paulo
  logradouro:  'Avenida Eliseu de Almeida',
  numero:      '1036',
  complemento: '(Fundos) Domingos Barbieri, 80',
  bairro:      'Instituto de Previdencia',
  municipio:   'São Paulo',
  uf:          'SP',
  cep:         '05533000',
  fone:        '1137221565',
  email:       'vendas@aguamister.com.br',
  crt:         '1',   // 1=SN 2=SN com excesso 3=Normal
  regime:      'SN',
  serieNFe:    '001',
  serieNFCe:   '001',
};

// Configuração fiscal persistente da empresa. Sem isso, uma alteração
// de endereço feita pelo ERP voltava ao endereço antigo após reiniciar
// o backend, podendo gerar NF-e com dados cadastrais divergentes.
const EMPRESA_FILE = path.join(__dirname, 'empresa.json');
if (fs.existsSync(EMPRESA_FILE)) {
  try {
    const salva = JSON.parse(fs.readFileSync(EMPRESA_FILE, 'utf8'));
    if (salva && typeof salva === 'object') Object.assign(EMPRESA, salva);
  } catch (e) { console.log('[!] Não foi possível carregar empresa.json:', e.message); }
}
function salvarEmpresa() {
  fs.writeFileSync(EMPRESA_FILE, JSON.stringify(EMPRESA, null, 2), { mode: 0o600 });
}

// ============================================================
//  ROTAS DE STATUS E CONFIG
// ============================================================

app.get('/api/status', (req, res) => {
  res.json({
    ok:       true,
    version:  '2.0.0',
    corrigeECONNRESET: true,
    corrigeHTTP404: true, // endpoints e diagnóstico HTTP corrigidos
    empresa:  EMPRESA.nome,
    cnpj:     EMPRESA.cnpjFmt,
    cert: {
      loaded:   CERT_STATE.loaded,
      nome:     CERT_STATE.nome || null,
      cnpj:     CERT_STATE.cnpj || null,
      validade: CERT_STATE.validade || null,
    },
    numeracao: NUMERACAO,
    ambiente:  AMBIENTE_ATUAL,
  });
});

app.get('/api/config', (req, res) => {
  res.json({ ok: true, empresa: EMPRESA, numeracao: NUMERACAO });
});
app.post('/api/config', (req, res) => {
  const { empresa, numeracao, logoBase64 } = req.body;
  if (empresa) {
    // Sempre grava CNPJ/IE/CEP/telefone/cUF/cMun só com dígitos - é a
    // causa mais comum de chave de acesso com tamanho errado (usuário
    // salva o CNPJ formatado "65.601.139/0001-36" na tela de
    // configurações e isso vaza pra dentro da chave de 44 dígitos).
    const camposNumericos = ['cnpj', 'ie', 'cep', 'fone', 'cuf', 'cmun'];
    const limpo = { ...empresa };
    camposNumericos.forEach(campo => {
      if (limpo[campo] != null) limpo[campo] = somenteDigitos(limpo[campo]);
    });
    Object.assign(EMPRESA, limpo);
    salvarEmpresa();
  }
  if (numeracao) { Object.assign(NUMERACAO, numeracao); salvarNumeracao(); }
  if (logoBase64 !== undefined) {
    // Guarda o logotipo em dois formatos: data URL para compatibilidade
    // com versões anteriores e arquivo em logo/Logo.jpeg, que é a pasta
    // oficial do logotipo usada pelo ERP e pela DANFE.
    if (logoBase64) {
      fs.writeFileSync(path.join(__dirname, 'logo.b64'), logoBase64);
      try {
        const m=String(logoBase64).match(/^data:image\/([^;]+);base64,(.+)$/s);
        if(m){
          const buf=Buffer.from(m[2],'base64');
          const ext=(m[1]||'jpeg').toLowerCase();
          const alvo=path.join(PASTA_LOGO,'Logo.'+(ext==='jpeg'||ext==='jpg'?'jpeg':ext));
          fs.writeFileSync(alvo,buf);
          if(!/Logo\.jpeg$/i.test(alvo)) { try{ fs.copyFileSync(alvo,path.join(PASTA_LOGO,'Logo.jpeg')); }catch(e){} }
        }
      } catch(e) { console.log('[!] Logo recebido, mas não foi possível criar Logo.jpeg:',e.message); }
    } else {
      if (fs.existsSync(path.join(__dirname, 'logo.b64'))) fs.unlinkSync(path.join(__dirname, 'logo.b64'));
    }
  }
  res.json({ ok: true });
});

function obterLogoDataUrl() {
  const p = path.join(__dirname, 'logo.b64');
  if (fs.existsSync(p)) { try { return fs.readFileSync(p, 'utf8'); } catch (e) {} }
  const lp = path.join(PASTA_LOGO,'Logo.jpeg');
  if (fs.existsSync(lp)) { try { return 'data:image/jpeg;base64,'+fs.readFileSync(lp).toString('base64'); } catch(e) {} }
  return null;
}



// ============================================================
//  CARREGAR CERTIFICADO A1 (.pfx / .p12)
// ============================================================

// Caminho do certificado "residente" - se você colocar um arquivo
// chamado certificado.pfx dentro desta pasta (backend/), o ERP detecta
// sozinho e você só precisa digitar a senha, sem arrastar o arquivo
// toda vez. A senha NUNCA é salva em disco nem sai da sua máquina.
const CERT_ARQUIVO_LOCAL = path.join(__dirname, 'certificado.pfx');

function carregarCertificadoDeBuffer(pfxDer, senha) {
  const pfxAsn1  = forge.asn1.fromDer(pfxDer.toString('binary'));
  const pfx      = forge.pkcs12.pkcs12FromAsn1(pfxAsn1, false, senha);

  // Extrair chave privada
  const keyBags  = pfx.getBags({ bagType: forge.pki.oids.pkcs8ShroudedKeyBag });
  const certBags = pfx.getBags({ bagType: forge.pki.oids.certBag });
  const keyBag   = keyBags[forge.pki.oids.pkcs8ShroudedKeyBag] && keyBags[forge.pki.oids.pkcs8ShroudedKeyBag][0];
  const todosCertBags = (certBags[forge.pki.oids.certBag] || []);

  if (!keyBag || !todosCertBags.length) throw new Error('Certificado inválido ou senha incorreta');

  const privateKey = keyBag.key;

  // Um .pfx de certificado A1 real (ICP-Brasil) normalmente traz o SEU
  // certificado + os certificados da cadeia da Autoridade Certificadora
  // (AC) juntos no mesmo arquivo. Pegar "o primeiro" às cegas pode
  // pegar um certificado da AC em vez do seu - aí a assinatura fica
  // com o certificado errado, e tudo dá errado silenciosamente depois
  // (inclusive a impressão de que "não gravou"). O jeito certo é achar,
  // entre todos os certificados do arquivo, o que tem a chave pública
  // correspondente à chave privada que acabamos de carregar.
  let cert = null;
  for (const bag of todosCertBags) {
    const c = bag.cert;
    if (c.publicKey && c.publicKey.n && privateKey.n && c.publicKey.n.equals(privateKey.n)) {
      cert = c;
      break;
    }
  }
  if (!cert) cert = todosCertBags[0].cert; // fallback, não deveria cair aqui num .pfx válido

  // Extrair informações
  const subject   = cert.subject;
  const cnField   = subject.getField('CN') || subject.getField('2.5.4.3');
  const notAfter  = cert.validity.notAfter;
  const notBefore = cert.validity.notBefore;

  if (notAfter.getTime() < Date.now()) {
    throw new Error('Certificado vencido em ' + notAfter.toLocaleDateString('pt-BR') + '. Emita um novo A1 junto à sua AC.');
  }

  // Converter para PEM
  const keyPem  = forge.pki.privateKeyToPem(privateKey);
  const certPem = forge.pki.certificateToPem(cert);

  CERT_STATE = {
    loaded:   true,
    cert,
    key:      privateKey,
    certPem,
    keyPem,
    validade: notAfter.toLocaleDateString('pt-BR'),
    validoDe: notBefore.toLocaleDateString('pt-BR'),
    nome:     cnField ? cnField.value : 'Certificado',
    cnpj:     EMPRESA.cnpjFmt,
  };

  // Salvar PEM em disco (só o certificado + chave já decifrados, sem a
  // senha) para os requests HTTPS mTLS e para recarregar sozinho da
  // próxima vez que o backend for iniciado, sem pedir a senha de novo.
  // Escreve num arquivo temporário e só troca o definitivo depois de
  // confirmar que gravou certo - evita ficar com um cert.pem pela
  // metade se der erro de disco no meio do caminho (permissão, disco
  // cheio, etc.) em qualquer ambiente (homologação ou produção, tanto
  // faz - este passo independe do ambiente fiscal).
  const certPath = path.join(__dirname, 'cert.pem');
  const keyPath  = path.join(__dirname, 'key.pem');
  try {
    fs.writeFileSync(certPath + '.tmp', certPem);
    fs.writeFileSync(keyPath  + '.tmp', keyPem);
    fs.renameSync(certPath + '.tmp', certPath);
    fs.renameSync(keyPath  + '.tmp', keyPath);
  } catch (e) {
    throw new Error('Certificado foi validado, mas não consegui GRAVAR em disco (' + e.message + '). Verifique se a pasta backend/ tem permissão de escrita.');
  }

  // Confere que realmente gravou e que dá pra ler de volta, pra nunca
  // reportar sucesso sem ter certeza.
  if (!fs.existsSync(certPath) || !fs.existsSync(keyPath)) {
    throw new Error('Certificado não foi confirmado em disco após gravar - tente novamente.');
  }

  return CERT_STATE;
}

// Ao iniciar o backend, se já existir cert.pem/key.pem de uma vez
// anterior que a senha foi digitada, recarrega automaticamente - não
// precisa digitar a senha de novo a cada reinício.
function tentarAutoCarregarCertificado() {
  const certPemPath = path.join(__dirname, 'cert.pem');
  const keyPemPath  = path.join(__dirname, 'key.pem');
  if (!fs.existsSync(certPemPath) || !fs.existsSync(keyPemPath)) return;
  try {
    const certPem = fs.readFileSync(certPemPath, 'utf8');
    const keyPem  = fs.readFileSync(keyPemPath, 'utf8');
    const cert    = forge.pki.certificateFromPem(certPem);
    const key     = forge.pki.privateKeyFromPem(keyPem);
    const subject = cert.subject;
    const cnField = subject.getField('CN') || subject.getField('2.5.4.3');
    const notAfter = cert.validity.notAfter;

    if (notAfter.getTime() < Date.now()) {
      console.log('[!]  Certificado salvo (cert.pem) está VENCIDO desde ' + notAfter.toLocaleDateString('pt-BR') + ' - carregue um novo.');
      return;
    }

    CERT_STATE = {
      loaded: true, cert, key, certPem, keyPem,
      validade: notAfter.toLocaleDateString('pt-BR'),
      nome: cnField ? cnField.value : 'Certificado',
      cnpj: EMPRESA.cnpjFmt,
    };
    console.log(' Certificado recarregado automaticamente: ' + CERT_STATE.nome + ' (válido até ' + CERT_STATE.validade + ')');
  } catch (e) {
    console.log('[!]  Não foi possível recarregar o certificado salvo automaticamente:', e.message);
  }
}

app.post('/api/certificado/carregar', (req, res) => {
  const { pfxBase64, senha } = req.body;
  if (!pfxBase64 || !senha) {
    return res.status(400).json({ ok: false, erro: 'pfxBase64 e senha são obrigatórios' });
  }
  try {
    carregarCertificadoDeBuffer(Buffer.from(pfxBase64, 'base64'), senha);
    // Se você mandou o arquivo via upload e ainda não existe uma cópia
    // residente, guarda uma cópia em backend/certificado.pfx para ser
    // detectada automaticamente da próxima vez.
    if (!fs.existsSync(CERT_ARQUIVO_LOCAL)) {
      fs.writeFileSync(CERT_ARQUIVO_LOCAL, Buffer.from(pfxBase64, 'base64'));
    }
    res.json({
      ok: true, nome: CERT_STATE.nome, cnpj: CERT_STATE.cnpj, validade: CERT_STATE.validade,
      mensagem: 'Certificado carregado com sucesso!',
    });
  } catch (err) {
    console.error('Erro certificado:', err.message);
    res.status(400).json({ ok: false, erro: 'Erro ao processar certificado: ' + err.message });
  }
});

// Detecta se já existe um certificado.pfx na pasta do backend, para o
// ERP oferecer "digite só a senha" em vez de pedir para arrastar o
// arquivo de novo.
app.get('/api/certificado/detectar', (req, res) => {
  const existe = fs.existsSync(CERT_ARQUIVO_LOCAL);
  res.json({ ok: true, existe, arquivo: existe ? path.basename(CERT_ARQUIVO_LOCAL) : null });
});

// Carrega o certificado.pfx que já está na pasta do backend - só a
// senha precisa ser digitada no navegador; ela vai direto para este
// servidor local (127.0.0.1) e nunca é gravada em disco.
app.post('/api/certificado/carregar-local', (req, res) => {
  const { senha } = req.body;
  if (!senha) return res.status(400).json({ ok: false, erro: 'Informe a senha' });
  if (!fs.existsSync(CERT_ARQUIVO_LOCAL)) {
    return res.status(404).json({ ok: false, erro: 'Nenhum certificado.pfx encontrado na pasta do backend' });
  }
  try {
    carregarCertificadoDeBuffer(fs.readFileSync(CERT_ARQUIVO_LOCAL), senha);
    res.json({
      ok: true, nome: CERT_STATE.nome, cnpj: CERT_STATE.cnpj, validade: CERT_STATE.validade,
      mensagem: 'Certificado carregado com sucesso!',
    });
  } catch (err) {
    console.error('Erro certificado local:', err.message);
    res.status(400).json({ ok: false, erro: 'Senha incorreta ou certificado inválido: ' + err.message });
  }
});

app.get('/api/certificado/status', (req, res) => {
  res.json({
    loaded:   CERT_STATE.loaded,
    nome:     CERT_STATE.nome || null,
    validade: CERT_STATE.validade || null,
    cnpj:     CERT_STATE.cnpj || null,
  });
});

// ============================================================
//  UTILITÁRIOS XML / ASSINATURA
// ============================================================

function somenteDigitos(v) {
  return String(v == null ? '' : v).replace(/\D/g, '');
}

function cDV44(ch43) {
  // Dígito verificador da chave de acesso - Módulo 11.
  // Pesos 2..9 aplicados da direita para a esquerda, cíclicos.
  // Resto da divisão por 11 igual a 0 ou 1 => DV = 0; senão DV = 11 - resto.
  const seq  = ch43.split('').reverse();
  let mult = 2, soma = 0;
  seq.forEach(d => { soma += parseInt(d, 10) * mult; mult = mult === 9 ? 2 : mult + 1; });
  const r = soma % 11;
  return r < 2 ? '0' : String(11 - r);
}

function gerarChave(mod, nNF, serie, amb) {
  const d = new Date();

  // Cada campo é limpo (só dígitos) e forçado ao tamanho EXATO exigido
  // pelo layout da chave de acesso (Manual de Orientação do
  // Contribuinte, item 7.2). Isso evita que uma configuração salva com
  // pontuação (ex: CNPJ "65.601.139/0001-36" em vez de
  // "65601139000136") gere uma chave com mais ou menos de 44 dígitos -
  // que é exatamente o "erro de tamanho" rejeitado pela SEFAZ.
  const cUF    = somenteDigitos(EMPRESA.cuf).padStart(2, '0').slice(-2);          // 2
  const AAMM   = anoMesFiscal();                                                  // 4
  const CNPJ   = somenteDigitos(EMPRESA.cnpj).padStart(14, '0').slice(-14);       // 14
  const MOD    = somenteDigitos(mod).padStart(2, '0').slice(-2);                  // 2
  const SERIE  = somenteDigitos(serie).padStart(3, '0').slice(-3);                // 3
  const NNF    = somenteDigitos(nNF).padStart(9, '0').slice(-9);                  // 9
  const TPEMIS = '1';                                                             // 1 (emissão normal)
  const cNF    = String(Math.floor(Math.random() * 99999998) + 1)
                   .padStart(8, '0').slice(-8);                                   // 8

  const base = cUF + AAMM + CNPJ + MOD + SERIE + NNF + TPEMIS + cNF;

  if (base.length !== 43) {
    throw new Error(
      `Chave de acesso inválida: campos somam ${base.length} dígitos (esperado 43). ` +
      `Confira CNPJ/IE em Configurações - não podem conter ponto, barra ou traço.`
    );
  }

  const chave = base + cDV44(base);

  if (!/^\d{44}$/.test(chave)) {
    throw new Error('Chave de acesso gerada não tem 44 dígitos numéricos: ' + chave);
  }

  return chave;
}

function dataHoraFiscal() {
  // A versao anterior usava toISOString() (que devolve UTC) e colava
  // "-03:00" no final - isso jogava a data/hora 3 horas PARA FRENTE e a
  // SEFAZ rejeitava com "Rejeicao 703: data-hora de emissao posterior ao
  // horario de recebimento". Agora montamos o horario LOCAL de Brasilia
  // (-03:00) de verdade.
  const d   = new Date();
  const off = -180; // minutos (-03:00)
  const brt = new Date(d.getTime() + (d.getTimezoneOffset() + off) * 60000);
  const p   = n => String(n).padStart(2, '0');
  return `${brt.getFullYear()}-${p(brt.getMonth()+1)}-${p(brt.getDate())}T`
       + `${p(brt.getHours())}:${p(brt.getMinutes())}:${p(brt.getSeconds())}-03:00`;
}

// AAMM da chave de acesso tem que bater com o dhEmi (mesmo fuso), senao
// a SEFAZ rejeita a chave (Rejeicao 236 - chave de acesso invalida).
function anoMesFiscal() {
  const d   = new Date();
  const brt = new Date(d.getTime() + (d.getTimezoneOffset() - 180) * 60000);
  return String(brt.getFullYear()).slice(-2) + String(brt.getMonth() + 1).padStart(2, '0');
}

// Codigo de Seguranca do Contribuinte (CSC / Token) - obrigatorio para
// gerar o QR Code da NFC-e. Sem ele o QR Code fica invalido e a SEFAZ
// rejeita (Rejeicao 615 / QR Code invalido).
const CSC_FILE = path.join(__dirname, 'csc.json');
// CSC separado por ambiente. O segredo nunca é devolvido pela API.
let CSC = {
  homologacao: { id: process.env.NFCE_CSC_ID_HOMOLOGACAO || process.env.NFCE_CSC_ID || '', codigo: process.env.NFCE_CSC_HOMOLOGACAO || process.env.NFCE_CSC || '' },
  producao: { id: process.env.NFCE_CSC_ID_PRODUCAO || '', codigo: process.env.NFCE_CSC_PRODUCAO || '' }
};
if (fs.existsSync(CSC_FILE)) {
  try {
    const salvo = JSON.parse(fs.readFileSync(CSC_FILE, 'utf8'));
    if (salvo && (salvo.homologacao || salvo.producao)) {
      CSC.homologacao = Object.assign(CSC.homologacao, salvo.homologacao || {});
      CSC.producao = Object.assign(CSC.producao, salvo.producao || {});
    } else if (salvo && (salvo.id || salvo.codigo)) {
      CSC.homologacao = { id: String(salvo.id || ''), codigo: String(salvo.codigo || '') };
    }
  } catch (e) {}
}
function salvarCSC(ambiente, id, codigo) {
  const amb = ambiente === 'producao' ? 'producao' : 'homologacao';
  CSC[amb] = { id: String(id || '').trim(), codigo: String(codigo || '').trim() };
  fs.writeFileSync(CSC_FILE, JSON.stringify(CSC, null, 2), { mode: 0o600 });
  try { fs.chmodSync(CSC_FILE, 0o600); } catch (e) {}
}
function obterCSC(tpAmb) {
  const amb = String(tpAmb) === '1' ? 'producao' : 'homologacao';
  const c = CSC[amb] || { id: '', codigo: '' };
  return { ambiente: amb, id: String(c.id || '').trim(), codigo: String(c.codigo || '').trim() };
}

function assinaarXML(xmlStr, idAttr, elemento = 'infNFe') {
  // Assina o XML com XML-DSig real (enveloped-signature + C14N 1.0 +
  // RSA-SHA1), exatamente como a SEFAZ exige no Manual de Orientação do
  // Contribuinte (MOC) da NF-e. A versão anterior apenas calculava um
  // hash da string crua (sem canonicalizar), o que gera uma assinatura
  // que a SEFAZ SEMPRE rejeita (cStat 297/298 - "rejeição: falha no
  // schema/assinatura"). Usar biblioteca dedicada (xml-crypto) evita
  // reimplementar C14N manualmente, que é uma fonte clássica de bugs.
  // `elemento` é o nome do elemento assinado - 'infNFe' para NF-e/NFC-e,
  // 'infEvento' para eventos (cancelamento, carta de correção etc.).
  if (!CERT_STATE.loaded) throw new Error('Certificado não carregado');

  const sig = new SignedXml({
    privateKey: CERT_STATE.keyPem,
    publicCert: CERT_STATE.certPem,
  });

  const xpathAlvo = `//*[local-name(.)='${elemento}']`;

  sig.addReference({
    xpath: xpathAlvo,
    digestAlgorithm: 'http://www.w3.org/2000/09/xmldsig#sha1',
    transforms: [
      'http://www.w3.org/2000/09/xmldsig#enveloped-signature',
      'http://www.w3.org/TR/2001/REC-xml-c14n-20010315',
    ],
    uri: `#${idAttr}`,
  });

  sig.signatureAlgorithm       = 'http://www.w3.org/2000/09/xmldsig#rsa-sha1';
  sig.canonicalizationAlgorithm = 'http://www.w3.org/TR/2001/REC-xml-c14n-20010315';
  sig.getKeyInfoContent = SignedXml.getKeyInfoContent; // inclui <X509Certificate> no KeyInfo

  // A <Signature> fica como IRMÃ do elemento assinado, logo após seu
  // fechamento (é o que a action:'after' faz aqui).
  sig.computeSignature(xmlStr, {
    location: { reference: xpathAlvo, action: 'after' },
  });

  return sig.getSignedXml();
}

// ============================================================
//  MONTAR nfeProc (NFe assinada + protocolo) - arquivo final
// ============================================================

function extrairBlocoProt(xmlResp) {
  const m = xmlResp.match(/<protNFe[\s\S]*?<\/protNFe>/);
  return m ? m[0] : null;
}

function montarNFeProc(nfeAssinada, blocoProt) {
  let xml = `<?xml version="1.0" encoding="UTF-8"?>`;
  xml += `<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">`;
  xml += nfeAssinada;
  xml += blocoProt || '';
  xml += `</nfeProc>`;
  return xml;
}

// ============================================================
//  CONSTRUIR XML NF-e / NFC-e
// ============================================================

function esc(v) {
  return String(v == null ? '' : v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// A SEFAZ rejeita acentuacao/caracteres de controle em varios campos.
// Normaliza para ASCII maiusculo-amigavel sem quebrar o texto.
function txtFiscal(v, max) {
  let t = String(v == null ? '' : v)
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x20-\x7E]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (max) t = t.substring(0, max);
  return esc(t);
}

const HOMOLOG_XNOME = 'NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL';

function buildXML(dados, mod) {
  const { dest = {}, itens = [], pgto, desconto, infAdd } = dados || {};
  // O front-end manda parcelas/vencimento/duplicatas dentro de `pagamento`
  // (ver _nfeCollectPagamento no HTML), mas este destructure lia direto de
  // `dados` — por isso a nota sempre caía em 1 parcela e nunca levava
  // vencimento, mesmo quando o usuário escolhia 2x, 3x etc. na tela.
  const pagObj = dados && dados.pagamento || {};
  const parcelas      = dados.parcelas      != null ? dados.parcelas      : pagObj.parcelas;
  const primeiroVenc   = dados.primeiroVenc  != null ? dados.primeiroVenc  : pagObj.primeiroVencimento;
  const intervaloDias  = dados.intervaloDias != null ? dados.intervaloDias : pagObj.intervaloDias;
  const duplicatasFront = Array.isArray(pagObj.duplicatas) ? pagObj.duplicatas : null;
  if (!itens.length) throw new Error('A nota precisa ter pelo menos um item.');

  const isNFCe  = mod === '65';
  // Permite que a rotina de recuperação de cStat 539 use automaticamente
  // a próxima numeração fiscal livre, sem alterar os dados da venda.
  const nNFForcado = dados && Number.isInteger(Number(dados._nNFOverride))
    ? Number(dados._nNFOverride)
    : null;
  const nNF     = nNFForcado != null
    ? nNFForcado
    : (isNFCe ? NUMERACAO.nfce : NUMERACAO.nfe);
  const serie   = String((isNFCe ? EMPRESA.serieNFCe : EMPRESA.serieNFe) || '001').padStart(3,'0').slice(-3);
  // "Emissao de teste (sem valor fiscal)": o front pode forcar tpAmb=2
  // (homologacao) mesmo com o sistema em producao. A nota vai de verdade
  // para a SEFAZ e e autorizada de verdade, mas sem valor fiscal - e o
  // ambiente oficial de testes da SEFAZ.
  const testeSemValorFiscal = !!(dados && (dados.teste === true || String(dados.tpAmbForce) === '2'));
  const tpAmb   = testeSemValorFiscal ? '2' : (AMBIENTE_ATUAL === 'producao' ? '1' : '2');
  const chave   = gerarChave(mod, nNF, serie, tpAmb);
  const dhEmi   = dataHoraFiscal();

  const destDoc  = somenteDigitos(dest.cnpj || dest.cpf || '');
  const temDest  = destDoc.length === 11 || destDoc.length === 14;
  const destUF   = (dest.uf || EMPRESA.uf || 'SP').toUpperCase().substring(0, 2);
  const mesmaUF  = destUF === (EMPRESA.uf || 'SP').toUpperCase();
  const idDest   = isNFCe ? '1' : (mesmaUF ? '1' : '2');
  const cfopPad  = mesmaUF ? '5102' : '6102';

  // Simples Nacional (CRT 1 ou 2) NAO pode usar <ICMS00/40/...> - tem que
  // usar <ICMSSN...> com CSOSN. Usar CST 40 com CRT=1 e uma das causas
  // classicas de recusa da SEFAZ (Rejeicao 508/509/CST incompativel).
  const crt = String(EMPRESA.crt || '1');
  const simples = crt === '1' || crt === '2';

  let xmlStr = `<NFe xmlns="http://www.portalfiscal.inf.br/nfe">`;
  xmlStr += `<infNFe versao="4.00" Id="NFe${chave}">`;

  // -- IDE (ordem do schema 4.00) --
  xmlStr += `<ide>`;
  xmlStr += `<cUF>${somenteDigitos(EMPRESA.cuf)}</cUF>`;
  xmlStr += `<cNF>${chave.slice(35, 43)}</cNF>`;
  // natOp vem do modal (campo antes era ignorado e ficava sempre fixo
  // em "Venda de mercadoria" mesmo quando o usuário escolhia outra
  // opção). Mantém o valor padrão de venda quando nada for informado.
  const natOpEscolhida = String((dados && dados.natOp) || 'Venda de mercadoria').trim().substring(0, 60);
  xmlStr += `<natOp>${natOpEscolhida.replace(/&/g,'&amp;').replace(/</g,'&lt;')}</natOp>`;
  xmlStr += `<mod>${mod}</mod>`;
  xmlStr += `<serie>${Number(serie)}</serie>`;
  xmlStr += `<nNF>${Number(nNF)}</nNF>`;
  xmlStr += `<dhEmi>${dhEmi}</dhEmi>`;
  xmlStr += `<tpNF>1</tpNF>`;
  xmlStr += `<idDest>${idDest}</idDest>`;
  xmlStr += `<cMunFG>${somenteDigitos(EMPRESA.cmun)}</cMunFG>`;
  xmlStr += `<tpImp>${isNFCe ? '4' : '1'}</tpImp>`;
  xmlStr += `<tpEmis>1</tpEmis>`;
  xmlStr += `<cDV>${chave.slice(-1)}</cDV>`;
  xmlStr += `<tpAmb>${tpAmb}</tpAmb>`;
  xmlStr += `<finNFe>1</finNFe>`;
  // Consumidor final: para NF-e, a regra 696 exige indFinal=1 quando
  // o destinatário é não contribuinte. O PDV não coleta IE do destinatário,
  // portanto não pode presumir que todo CNPJ seja contribuinte/revenda.
  // O padrão seguro deste fluxo é consumidor final. Caso uma operação
  // futura seja de revenda/contribuinte, o frontend deverá enviar
  // dest.indFinal=0 explicitamente e também a IE do destinatário.
  // Regra segura para destinatário: IE conhecida => contribuinte; sem IE => não contribuinte.
  // O ERP nunca inventa uma IE. Para indIEDest=9, a tag IE não é enviada.
  const destIEInformada = somenteDigitos(dest && dest.ie || '');
  const destIndFinal = (dest && String(dest.indFinal) === '0') ? '0' : '1';
  let destIndIEDest = ['1','2','9'].includes(String(dest && dest.indIEDest || '')) ? String(dest.indIEDest) : (destIEInformada ? '1' : '9');
  // Se o destinatário foi marcado como contribuinte, mas a IE não existe, pare antes da transmissão.
  if (destIndIEDest === '1' && destIEInformada.length === 0) {
    throw new Error('DEST_CONTRIBUINTE_SEM_IE: destinatário marcado como contribuinte de ICMS sem Inscrição Estadual. Cadastre/confirme a IE ou altere corretamente o cadastro para não contribuinte.');
  }
  // Contribuinte isento não é aceito por várias UFs (incluindo SP). Não deixe esse XML chegar à SEFAZ.
  const ufsNaoAceitamIsento = new Set(['AM','BA','CE','GO','MG','MS','MT','PE','RN','SE','SP']);
  if (destIndIEDest === '2' && ufsNaoAceitamIsento.has(destUF)) {
    throw new Error('DEST_ISENTO_NAO_PERMITIDO: a UF '+destUF+' não permite destinatário como Contribuinte Isento de IE nesta operação. Para cliente sem IE, use Não Contribuinte (indIEDest=9) quando essa for a situação fiscal real.');
  }
  const destIndPres  = (dest && dest.indPres != null && ['0','1','2','3','4','5','9'].includes(String(dest.indPres)))
    ? String(dest.indPres)
    : (isNFCe ? '1' : '1');
  xmlStr += `<indFinal>${isNFCe ? '1' : destIndFinal}</indFinal>`;
  xmlStr += `<indPres>${destIndPres}</indPres>`;
  // Indicativo do intermediador (NT 2020.006 / regra SEFAZ 434).
  // Esta operação é venda direta do emitente, sem marketplace/intermediador.
  // 0 = operação sem intermediador. O campo precisa existir no XML quando
  // exigido pela regra de validação; omiti-lo provoca cStat 434.
  const indIntermed = String(dados.indIntermed == null ? '0' : dados.indIntermed) === '1' ? '1' : '0';
  xmlStr += `<indIntermed>${indIntermed}</indIntermed>`;
  xmlStr += `<procEmi>0</procEmi><verProc>ERP-AM-1.2</verProc>`;
  xmlStr += `</ide>`;

  // -- EMIT --
  xmlStr += `<emit>`;
  xmlStr += `<CNPJ>${somenteDigitos(EMPRESA.cnpj)}</CNPJ>`;
  xmlStr += `<xNome>${txtFiscal(EMPRESA.nome, 60)}</xNome>`;
  xmlStr += `<xFant>${txtFiscal(EMPRESA.fantasia || 'AGUA MISTER', 60)}</xFant>`;
  xmlStr += `<enderEmit>`;
  xmlStr += `<xLgr>${txtFiscal(EMPRESA.logradouro, 60)}</xLgr>`;
  xmlStr += `<nro>${txtFiscal(EMPRESA.numero || 'S/N', 60)}</nro>`;
  if (EMPRESA.complemento) xmlStr += `<xCpl>${txtFiscal(EMPRESA.complemento, 60)}</xCpl>`;
  xmlStr += `<xBairro>${txtFiscal(EMPRESA.bairro, 60)}</xBairro>`;
  xmlStr += `<cMun>${somenteDigitos(EMPRESA.cmun)}</cMun>`;
  xmlStr += `<xMun>${txtFiscal(EMPRESA.municipio, 60)}</xMun>`;
  xmlStr += `<UF>${EMPRESA.uf}</UF>`;
  xmlStr += `<CEP>${somenteDigitos(EMPRESA.cep).padStart(8, '0').slice(-8)}</CEP>`;
  xmlStr += `<cPais>1058</cPais><xPais>BRASIL</xPais>`;
  const foneEmit = somenteDigitos(EMPRESA.fone);
  if (foneEmit.length >= 10) xmlStr += `<fone>${foneEmit.slice(0, 14)}</fone>`;
  xmlStr += `</enderEmit>`;
  xmlStr += `<IE>${somenteDigitos(EMPRESA.ie)}</IE>`;
  xmlStr += `<CRT>${crt}</CRT>`;
  xmlStr += `</emit>`;

  // -- DEST --
  // Para NF-e (mod 55) o destinatario e o <enderDest> sao OBRIGATORIOS.
  // A versao anterior nao enviava <enderDest> e colocava <indIEDest> fora
  // de ordem: isso quebra o schema e a SEFAZ recusa (Rejeicao 215/229).
  if (!isNFCe && !temDest) {
    throw new Error('NF-e exige destinatario com CNPJ (14 digitos) ou CPF (11 digitos) valido.');
  }
  if (temDest) {
    const destTag = destDoc.length === 14 ? 'CNPJ' : 'CPF';
    const destIE  = somenteDigitos(dest.ie);
    // Contribuinte de ICMS (indIEDest=1) exige IE. Isento (2) e não contribuinte (9) não enviam IE.
    if (destIndIEDest === '1' && destDoc.length !== 14) {
      throw new Error('Destinatário contribuinte de ICMS deve ser informado com CNPJ e Inscrição Estadual.');
    }
    if (destIndIEDest === '1' && destIE.length === 0) {
      throw new Error('Destinatário marcado como contribuinte de ICMS, mas a Inscrição Estadual não foi informada.');
    }
    xmlStr += `<dest>`;
    xmlStr += `<${destTag}>${destDoc}</${destTag}>`;
    // Em HOMOLOGACAO a razao social do destinatario TEM que ser esta
    // frase exata, senao a SEFAZ recusa (Rejeicao 539/preenchimento).
    xmlStr += `<xNome>${tpAmb === '2' ? HOMOLOG_XNOME : txtFiscal(dest.nome || 'CONSUMIDOR', 60)}</xNome>`;
    if (!isNFCe) {
      xmlStr += `<enderDest>`;
      xmlStr += `<xLgr>${txtFiscal(dest.logradouro || dest.endereco || 'NAO INFORMADO', 60)}</xLgr>`;
      xmlStr += `<nro>${txtFiscal(dest.numero || 'S/N', 60)}</nro>`;
      if (dest.complemento) xmlStr += `<xCpl>${txtFiscal(dest.complemento, 60)}</xCpl>`;
      xmlStr += `<xBairro>${txtFiscal(dest.bairro || 'CENTRO', 60)}</xBairro>`;
      xmlStr += `<cMun>${somenteDigitos(dest.cmun || EMPRESA.cmun)}</cMun>`;
      xmlStr += `<xMun>${txtFiscal(dest.municipio || dest.cidade || EMPRESA.municipio, 60)}</xMun>`;
      xmlStr += `<UF>${destUF}</UF>`;
      xmlStr += `<CEP>${somenteDigitos(dest.cep || EMPRESA.cep).padStart(8, '0').slice(-8)}</CEP>`;
      xmlStr += `<cPais>1058</cPais><xPais>BRASIL</xPais>`;
      const foneDest = somenteDigitos(dest.fone || dest.telefone);
      if (foneDest.length >= 10) xmlStr += `<fone>${foneDest.slice(0, 14)}</fone>`;
      xmlStr += `</enderDest>`;
    }
    // indIEDest vem DEPOIS de enderDest (ordem do schema).
    // 1=contribuinte, 2=contribuinte isento, 9=não contribuinte.
    if (destIndIEDest === '1') {
      xmlStr += `<indIEDest>1</indIEDest><IE>${destIE}</IE>`;
    } else if (destIndIEDest === '2') {
      xmlStr += `<indIEDest>2</indIEDest>`;
    } else {
      xmlStr += `<indIEDest>9</indIEDest>`;
    }
    const em = String(dest.email || '').trim();
    if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) xmlStr += `<email>${esc(em.substring(0, 60))}</email>`;
    xmlStr += `</dest>`;
  }

  // -- ITENS --
  let vProdTotal = 0;
  itens.forEach((item, i) => {
    const qtd   = parseFloat(item.qtd || item.qty || 1);
    const preco = parseFloat(item.preco || 0);
    if (!(qtd > 0)) throw new Error(`Item ${i + 1}: quantidade invalida.`);
    if (!(preco >= 0)) throw new Error(`Item ${i + 1}: preco invalido.`);
    // vProd tem que ser exatamente qCom x vUnCom arredondado - divergencia
    // aqui gera Rejeicao 528/531 ("valor do produto difere do calculado").
    const vUn   = Number(preco.toFixed(2));
    const vItem = Number((qtd * vUn).toFixed(2));
    vProdTotal  = Number((vProdTotal + vItem).toFixed(2));
    const un    = txtFiscal(item.un || 'UN', 6) || 'UN';

    xmlStr += `<det nItem="${i + 1}">`;
    xmlStr += `<prod>`;
    xmlStr += `<cProd>${txtFiscal(item.cod || (i + 1), 60)}</cProd>`;
    xmlStr += `<cEAN>SEM GTIN</cEAN>`;
    xmlStr += `<xProd>${txtFiscal(item.nome || 'PRODUTO', 120) || 'PRODUTO'}</xProd>`;
    xmlStr += `<NCM>${somenteDigitos(item.ncm || '22011000').padEnd(8, '0').slice(0, 8)}</NCM>`;
    xmlStr += `<CFOP>${somenteDigitos(item.cfop || cfopPad).padStart(4, '0').slice(0, 4)}</CFOP>`;
    xmlStr += `<uCom>${un}</uCom>`;
    xmlStr += `<qCom>${qtd.toFixed(4)}</qCom>`;
    xmlStr += `<vUnCom>${vUn.toFixed(2)}</vUnCom>`;
    xmlStr += `<vProd>${vItem.toFixed(2)}</vProd>`;
    xmlStr += `<cEANTrib>SEM GTIN</cEANTrib>`;
    xmlStr += `<uTrib>${un}</uTrib>`;
    xmlStr += `<qTrib>${qtd.toFixed(4)}</qTrib>`;
    xmlStr += `<vUnTrib>${vUn.toFixed(2)}</vUnTrib>`;
    xmlStr += `<indTot>1</indTot>`;
    xmlStr += `</prod>`;
    xmlStr += `<imposto>`;
    xmlStr += `<vTotTrib>0.00</vTotTrib>`;
    if (simples) {
      const csosn = somenteDigitos(item.csosn || '102').padStart(3, '0').slice(0, 3);
      xmlStr += `<ICMS><ICMSSN102><orig>0</orig><CSOSN>${csosn}</CSOSN></ICMSSN102></ICMS>`;
    } else {
      xmlStr += `<ICMS><ICMS40><orig>0</orig><CST>41</CST></ICMS40></ICMS>`;
    }
    // Empresa do Simples Nacional nao destaca PIS/COFINS: CST 49/99 com
    // valores zerados. Antes ia CST 01 com aliquota cheia, o que gera
    // rejeicao/divergencia de totais.
    xmlStr += `<PIS><PISOutr><CST>99</CST><vBC>0.00</vBC><pPIS>0.00</pPIS><vPIS>0.00</vPIS></PISOutr></PIS>`;
    xmlStr += `<COFINS><COFINSOutr><CST>99</CST><vBC>0.00</vBC><pCOFINS>0.00</pCOFINS><vCOFINS>0.00</vCOFINS></COFINSOutr></COFINS>`;
    xmlStr += `</imposto>`;
    xmlStr += `</det>`;
  });

  let vDesc = Number(parseFloat(desconto || 0).toFixed(2));
  if (!(vDesc >= 0)) vDesc = 0;
  if (vDesc > vProdTotal) vDesc = vProdTotal;
  const vNFTotal = Number((vProdTotal - vDesc).toFixed(2));

  // -- TOTAL --
  xmlStr += `<total><ICMSTot>`;
  xmlStr += `<vBC>0.00</vBC><vICMS>0.00</vICMS><vICMSDeson>0.00</vICMSDeson>`;
  xmlStr += `<vFCPUFDest>0.00</vFCPUFDest><vICMSUFDest>0.00</vICMSUFDest><vICMSUFRemet>0.00</vICMSUFRemet>`;
  xmlStr += `<vFCP>0.00</vFCP><vBCST>0.00</vBCST><vST>0.00</vST><vFCPST>0.00</vFCPST><vFCPSTRet>0.00</vFCPSTRet>`;
  xmlStr += `<vProd>${vProdTotal.toFixed(2)}</vProd>`;
  xmlStr += `<vFrete>0.00</vFrete><vSeg>0.00</vSeg><vDesc>${vDesc.toFixed(2)}</vDesc>`;
  xmlStr += `<vII>0.00</vII><vIPI>0.00</vIPI><vIPIDevol>0.00</vIPIDevol>`;
  xmlStr += `<vPIS>0.00</vPIS><vCOFINS>0.00</vCOFINS><vOutro>0.00</vOutro>`;
  xmlStr += `<vNF>${vNFTotal.toFixed(2)}</vNF><vTotTrib>0.00</vTotTrib>`;
  xmlStr += `</ICMSTot></total>`;

  // -- TRANSPORTE / VOLUMES --
  // Campos de volume (quantidade, espécie, marca, numeração, peso bruto e
  // peso líquido) são opcionais no schema mas, quando o usuário informa
  // qualquer um deles na tela, precisam ir dentro de <transp><vol>.
  const volInfo = dados && dados.volume || {};
  const volCampos = ['qVol','esp','marca','nVol','pesoL','pesoB']
    .map(k => volInfo[k]).some(v => v !== undefined && v !== null && String(v).trim() !== '');
  let volTag = '';
  if (volCampos) {
    const qVol   = txtFiscal(volInfo.qVol, 15);
    const esp    = txtFiscal(volInfo.esp, 60);
    const marca  = txtFiscal(volInfo.marca, 60);
    const nVolTx = txtFiscal(volInfo.nVol, 60);
    const pesoL  = volInfo.pesoL !== undefined && volInfo.pesoL !== '' ? Number(volInfo.pesoL).toFixed(3) : '';
    const pesoB  = volInfo.pesoB !== undefined && volInfo.pesoB !== '' ? Number(volInfo.pesoB).toFixed(3) : '';
    volTag = '<vol>'
      + (qVol   ? `<qVol>${qVol}</qVol>`     : '')
      + (esp    ? `<esp>${esp}</esp>`        : '')
      + (marca  ? `<marca>${marca}</marca>`  : '')
      + (nVolTx ? `<nVol>${nVolTx}</nVol>`   : '')
      + (pesoL  ? `<pesoL>${pesoL}</pesoL>`  : '')
      + (pesoB  ? `<pesoB>${pesoB}</pesoB>`  : '')
      + '</vol>';
  }
  xmlStr += `<transp><modFrete>9</modFrete>${volTag}</transp>`;

  // -- COBRANÇA / PARCELAS --
  // Gera o grupo cobr/dup sempre que houver mais de 1 parcela OU o usuário
  // tiver informado uma data de vencimento (venda a prazo/fiado em 1x) —
  // antes só entrava com qtdParcelas>1, por isso a nota de venda a prazo
  // em parcela única saía sem vencimento nenhum.
  const qtdParcelas = Math.max(1, Math.min(100, parseInt(parcelas || 1, 10) || 1));
  const vencInformado = /^\d{4}-\d{2}-\d{2}$/.test(String(primeiroVenc || ''));
  const vencBase = vencInformado ? String(primeiroVenc) : new Date(Date.now() + 30*86400000).toISOString().slice(0,10);
  const intervalo = Math.max(1, Math.min(365, parseInt(intervaloDias || 30, 10) || 30));
  const precisaCobr = qtdParcelas > 1 || vencInformado || (duplicatasFront && duplicatasFront.length);
  if (precisaCobr) {
    const nFat = String(nNF).padStart(6, '0');
    xmlStr += `<cobr><fat><nFat>${nFat}</nFat><vOrig>${vNFTotal.toFixed(2)}</vOrig><vDesc>0.00</vDesc><vLiq>${vNFTotal.toFixed(2)}</vLiq></fat>`;
    if (duplicatasFront && duplicatasFront.length) {
      // Usa exatamente as parcelas/valores/datas que o usuário conferiu na tela.
      duplicatasFront.forEach((d, i) => {
        const nDup  = String(d.nDup || d.numero || (i + 1)).padStart(3, '0');
        const dVenc = /^\d{4}-\d{2}-\d{2}$/.test(String(d.dVenc || d.vencimento || '')) ? String(d.dVenc || d.vencimento) : vencBase;
        const vDup  = Number(d.vDup || d.valor || 0).toFixed(2);
        xmlStr += `<dup><nDup>${nDup}</nDup><dVenc>${dVenc}</dVenc><vDup>${vDup}</dup>`.replace('</dup>','</vDup></dup>');
      });
    } else {
      let valores = [];
      let acumulado = 0;
      const baseCent = Math.floor((vNFTotal * 100) / qtdParcelas);
      for (let i = 0; i < qtdParcelas; i++) {
        const cent = (i === qtdParcelas - 1) ? Math.round(vNFTotal * 100) - acumulado : baseCent;
        valores.push(cent / 100);
        acumulado += cent;
      }
      for (let i = 0; i < qtdParcelas; i++) {
        const venc = new Date(vencBase + 'T12:00:00');
        venc.setDate(venc.getDate() + (i * intervalo));
        xmlStr += `<dup><nDup>${String(i + 1).padStart(3, '0')}</nDup><dVenc>${venc.toISOString().slice(0,10)}</dVenc><vDup>${valores[i].toFixed(2)}</vDup></dup>`;
      }
    }
    xmlStr += `</cobr>`;
  }

  // -- PAGAMENTO --
  const pgtoMap = { '0': '01', '1': '04', '2': '03', '3': '17', '4': '18', '5': '15' };
  const tPag    = pgtoMap[String(pgto == null ? 0 : pgto)] || '01';
  const indPag  = precisaCobr ? '1' : '0';
  // A SEFAZ rejeita (cStat 391) pagamento em cartão de crédito/débito
  // (tPag 03/04) sem o grupo <card>. Como o caixa não tem integração
  // com maquininha, informamos tpIntegra=2 (pagamento não integrado
  // ao emissor de NF-e) — é o mínimo exigido e dispensa CNPJ/bandeira/
  // código de autorização, que só são obrigatórios quando tpIntegra=1.
  const precisaCard = tPag === '03' || tPag === '04';
  const cardTag = precisaCard ? `<card><tpIntegra>2</tpIntegra></card>` : '';
  xmlStr += `<pag><detPag><indPag>${indPag}</indPag><tPag>${tPag}</tPag><vPag>${vNFTotal.toFixed(2)}</vPag>${cardTag}</detPag></pag>`;

  // -- INFO ADICIONAL --
  const obsSimples = simples
    ? 'DOCUMENTO EMITIDO POR ME/EPP OPTANTE PELO SIMPLES NACIONAL. NAO GERA DIREITO A CREDITO FISCAL DE IPI.'
    : '';
  const cpl = [obsSimples, txtFiscal(infAdd, 4000)].filter(Boolean).join(' ');
  if (cpl) xmlStr += `<infAdic><infCpl>${cpl.substring(0, 5000)}</infCpl></infAdic>`;

  // -- RESPONSAVEL TECNICO --
  xmlStr += `<infRespTec>`;
  xmlStr += `<CNPJ>${somenteDigitos(EMPRESA.cnpj)}</CNPJ>`;
  xmlStr += `<xContato>${txtFiscal(EMPRESA.nome, 60)}</xContato>`;
  xmlStr += `<email>${esc(EMPRESA.email || 'vendas@aguamister.com.br')}</email>`;
  xmlStr += `<fone>${(somenteDigitos(EMPRESA.fone) || '1137221565').slice(0, 14)}</fone>`;
  xmlStr += `</infRespTec>`;

  xmlStr += `</infNFe>`;
  // ATENCAO: <infNFeSupl> (QR Code da NFC-e) NAO vai dentro de <infNFe>.
  // No schema ele e IRMAO de infNFe e vem ANTES da <Signature>. A versao
  // anterior colocava dentro de infNFe - schema invalido, recusa na hora.
  xmlStr += `</NFe>`;

  return { xmlStr, chave, nNF, tpAmb, isNFCe, vNF: vNFTotal, dhEmi, teste: testeSemValorFiscal };
}

// ============================================================
//  QR CODE NFC-e (parâmetros oficiais / nVersao=100) + infNFeSupl
// ============================================================

const URL_NFCE = {
  '1': { qr: 'https://www.nfce.fazenda.sp.gov.br/qrcode', consulta: 'https://www.nfce.fazenda.sp.gov.br/consulta' },
  '2': { qr: 'https://www.homologacao.nfce.fazenda.sp.gov.br/qrcode', consulta: 'https://www.homologacao.nfce.fazenda.sp.gov.br/consulta' },
};
function hexUtf8(valor) { return Buffer.from(String(valor || ''), 'utf8').toString('hex'); }
function montarQRCodeNFCe(chave, tpAmb, xmlAssinado) {
  const cred = obterCSC(tpAmb);
  if (!cred.codigo || !cred.id) {
    const nomeAmb = cred.ambiente === 'producao' ? 'produção' : 'homologação';
    throw new Error(`CSC_NAO_CONFIGURADO: Para emitir NFC-e em ${nomeAmb}, cadastre o CSC e o ID do CSC nas Configurações do ERP. A SEFAZ-SP informa que, após o credenciamento, o código de segurança deve ser obtido em "Gerenciar Cód Segurança".`);
  }
  const idToken = String(cred.id).padStart(6, '0');
  const getTag = (tag) => {
    const m = String(xmlAssinado || '').match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, 'i'));
    return m ? m[1].trim() : '';
  };
  const dhEmi = getTag('dhEmi');
  const vNF = (String(xmlAssinado).match(/<ICMSTot>[\s\S]*?<vNF>([^<]+)<\/vNF>/i) || [,'0.00'])[1];
  const vICMS = (String(xmlAssinado).match(/<ICMSTot>[\s\S]*?<vICMS>([^<]+)<\/vICMS>/i) || [,'0.00'])[1];
  const digVal = getTag('DigestValue');
  const destBlock = (String(xmlAssinado).match(/<dest(?:\s[^>]*)?>([\s\S]*?)<\/dest>/i) || [,''])[1];
  const cDest = (destBlock.match(/<(?:CPF|CNPJ|idEstrangeiro)>([^<]+)<\/(?:CPF|CNPJ|idEstrangeiro)>/i) || [,''])[1];
  if (!dhEmi || !digVal) throw new Error('CSC_QR_DADOS: Não foi possível obter dhEmi/DigestValue do XML assinado para gerar o QR Code da NFC-e.');
  const partes = [`chNFe=${chave}`, 'nVersao=100', `tpAmb=${tpAmb}`];
  if (cDest) partes.push(`cDest=${String(cDest).replace(/\D/g, '')}`);
  partes.push(`dhEmi=${hexUtf8(dhEmi)}`, `vNF=${vNF}`, `vICMS=${vICMS}`, `digVal=${hexUtf8(digVal)}`, `cIdToken=${idToken}`);
  const base = partes.join('&');
  const hash = crypto.createHash('sha1').update(base + cred.codigo, 'utf8').digest('hex');
  const urls = URL_NFCE[String(tpAmb)] || URL_NFCE['2'];
  return { qrCode: `${urls.qr}?${base}&cHashQRCode=${hash}`, urlChave: urls.consulta };
}
function inserirInfNFeSupl(xmlAssinado, chave, tpAmb) {
  const { qrCode, urlChave } = montarQRCodeNFCe(chave, tpAmb, xmlAssinado);
  const supl = `<infNFeSupl><qrCode><![CDATA[${qrCode}]]></qrCode><urlChave>${urlChave}</urlChave></infNFeSupl>`;
  const idx = xmlAssinado.indexOf('<Signature');
  if (idx === -1) throw new Error('XML assinado sem <Signature> - não foi possível montar o QR Code.');
  return xmlAssinado.slice(0, idx) + supl + xmlAssinado.slice(idx);
}

// ============================================================
//  TRANSMITIR PARA SEFAZ
// ============================================================

// Endpoints oficiais SEFAZ-SP (NF-e/NFC-e 4.00), conferidos em 10/08/2026.
// A NFC-e usa o host nfce.fazenda.sp.gov.br e o nome canônico NFeAutorizacao4.asmx.
const ENDPOINTS = {
  nfe: {
    '1': 'https://nfe.fazenda.sp.gov.br/ws/nfeautorizacao4.asmx',
    '2': 'https://homologacao.nfe.fazenda.sp.gov.br/ws/nfeautorizacao4.asmx',
  },
  nfce: {
    '1': 'https://nfce.fazenda.sp.gov.br/ws/NFeAutorizacao4.asmx',
    '2': 'https://homologacao.nfce.fazenda.sp.gov.br/ws/NFeAutorizacao4.asmx',
  },
  evento: {
    nfe: {
      '1': 'https://nfe.fazenda.sp.gov.br/ws/nferecepcaoevento4.asmx',
      '2': 'https://homologacao.nfe.fazenda.sp.gov.br/ws/nferecepcaoevento4.asmx',
    },
    nfce: {
      '1': 'https://nfce.fazenda.sp.gov.br/ws/NFeRecepcaoEvento4.asmx',
      '2': 'https://homologacao.nfce.fazenda.sp.gov.br/ws/NFeRecepcaoEvento4.asmx',
    },
  },
};

// ═══════════════════════════════════════════════════════
//  RESOLUÇÃO AUTOMÁTICA DA CADEIA DE CERTIFICADOS ICP-BRASIL
// ─────────────────────────────────────────────────────────
//  Corrige o erro real "unable to get issuer certificate" ao
//  transmitir pra SEFAZ. Isso acontece porque os certificados
//  dos webservices da SEFAZ são emitidos por Autoridades
//  Certificadoras da ICP-Brasil, e a ICP-Brasil NÃO faz parte do
//  programa de raízes públicas que o Node.js/S.O. traz instalado
//  por padrão (esse programa segue a lista da Mozilla) — então,
//  mesmo com o certificado A1 do cliente 100% correto, o Node não
//  consegue validar sozinho o certificado do SERVIDOR da SEFAZ.
//
//  Duas técnicas combinadas, na ordem que os navegadores usam:
//  1) Cadeia que o próprio servidor manda no aperto de mão TLS
//     (rápido, mas vários servidores da SEFAZ mandam só o
//     certificado final, sem os intermediários — é exatamente
//     por isso que só essa técnica não bastou da primeira vez).
//  2) "AIA chasing" de verdade: o certificado do servidor tem uma
//     extensão padrão (Authority Information Access) apontando a
//     URL de onde baixar o certificado de quem o emitiu. A gente
//     segue essa URL, baixa, e repete recursivamente até achar uma
//     raiz auto-assinada — é isso que o Chrome/Firefox fazem por
//     baixo dos panos e o Node não faz sozinho.
//  A validação do certificado continua OBRIGATÓRIA o tempo todo
//  (rejectUnauthorized nunca é desligado) — só estamos completando
//  a cadeia que falta, não pulando a verificação.
// ═══════════════════════════════════════════════════════
const CA_CACHE_DIR = path.join(__dirname, 'dados', 'ca-cache');
const _caChainMem = {};

function _certParaPem(der) {
  const b64 = der.toString('base64').match(/.{1,64}/g).join('\n');
  return `-----BEGIN CERTIFICATE-----\n${b64}\n-----END CERTIFICATE-----\n`;
}
function _bufParaPem(buf) {
  const texto = buf.toString('utf8', 0, Math.min(buf.length, 100));
  if (texto.includes('BEGIN CERTIFICATE')) return buf.toString('utf8');
  return _certParaPem(buf); // veio em DER, converte
}
function _extrairAiaUrls(certPem) {
  try {
    const x509 = new crypto.X509Certificate(certPem);
    const info = x509.infoAccess || '';
    const urls = [];
    const re = /CA Issuers - URI:(\S+)/g;
    let m;
    while ((m = re.exec(info))) urls.push(m[1]);
    return urls;
  } catch (e) { return []; }
}
function _ehAutoAssinado(certPem) {
  try {
    const x509 = new crypto.X509Certificate(certPem);
    return typeof x509.checkIssued === 'function' ? x509.checkIssued(x509) : (x509.issuer === x509.subject);
  } catch (e) { return false; }
}
function _baixarBuffer(url, timeout, redirecoes) {
  redirecoes = redirecoes || 0;
  return new Promise((resolve, reject) => {
    if (redirecoes > 3) return reject(new Error('redirecionamentos demais'));
    let mod, urlObj;
    try { urlObj = new URL(url); mod = urlObj.protocol === 'http:' ? http : https; }
    catch (e) { return reject(e); }
    const req = mod.get(url, { timeout: timeout || 10000, rejectUnauthorized: false }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return resolve(_baixarBuffer(new URL(res.headers.location, url).toString(), timeout, redirecoes + 1));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout ao baixar certificado intermediário')); });
  });
}
// Persegue a extensão AIA do certificado (CA Issuers), baixando cada
// autoridade emissora até chegar numa raiz auto-assinada.
async function perseguirAIA(certLeafPem, maxSaltos) {
  let atualPem = certLeafPem;
  let cadeia = '';
  const vistos = new Set();
  for (let i = 0; i < (maxSaltos || 6); i++) {
    if (_ehAutoAssinado(atualPem)) break;
    const urls = _extrairAiaUrls(atualPem);
    if (!urls.length) break;
    let baixou = false;
    for (const url of urls) {
      if (vistos.has(url)) continue;
      vistos.add(url);
      try {
        const buf = await _baixarBuffer(url, 10000);
        if (!buf || !buf.length) continue;
        const pem = _bufParaPem(buf);
        // valida que realmente é um certificado antes de aceitar
        // eslint-disable-next-line no-new
        new crypto.X509Certificate(pem);
        cadeia += pem;
        atualPem = pem;
        baixou = true;
        break;
      } catch (e) { /* tenta a próxima URL da lista, se houver */ }
    }
    if (!baixou) break;
  }
  return cadeia;
}

// URLs oficiais e estáveis do repositório do Governo Federal com a
// Autoridade Certificadora Raiz da ICP-Brasil — publicadas pela própria
// Receita/ITI e citadas nos comunicados oficiais das SEFAZ estaduais.
// Servem como mais uma fonte, independente da cadeia que o servidor
// manda ou da extensão AIA do certificado.
const ICP_BRASIL_RAIZ_URLS = [
  'http://acraiz.icpbrasil.gov.br/credenciadas/RAIZ/ICP-Brasilv10.crt',
  'http://acraiz.icpbrasil.gov.br/ICP-Brasilv5.crt',
];
let _icpBrasilRaizCache = null;
async function _baixarRaizIcpBrasil() {
  if (_icpBrasilRaizCache !== null) return _icpBrasilRaizCache;
  let cadeia = '';
  for (const url of ICP_BRASIL_RAIZ_URLS) {
    try {
      const buf = await _baixarBuffer(url, 8000);
      if (buf && buf.length) {
        const pem = _bufParaPem(buf);
        new crypto.X509Certificate(pem); // valida antes de aceitar
        cadeia += pem;
      }
    } catch (e) { /* essa URL falhou, tenta a próxima da lista */ }
  }
  _icpBrasilRaizCache = cadeia;
  return cadeia;
}

function resolverCadeiaCA(hostname, diag) {
  diag = diag || {};
  if (_caChainMem[hostname]) { diag.origem = 'cache-memoria'; return Promise.resolve(_caChainMem[hostname]); }

  let cacheFile = null;
  try {
    if (!fs.existsSync(CA_CACHE_DIR)) fs.mkdirSync(CA_CACHE_DIR, { recursive: true });
    cacheFile = path.join(CA_CACHE_DIR, hostname.replace(/[^a-z0-9.-]/gi, '_') + '.pem');
    if (fs.existsSync(cacheFile)) {
      const idadeDias = (Date.now() - fs.statSync(cacheFile).mtimeMs) / 86400000;
      const conteudo = fs.readFileSync(cacheFile, 'utf8');
      if (idadeDias < 30 && conteudo.includes('BEGIN CERTIFICATE')) {
        _caChainMem[hostname] = conteudo;
        diag.origem = 'cache-disco';
        return Promise.resolve(conteudo);
      }
    }
  } catch (e) { diag.erroCache = e.message; }

  return new Promise((resolve) => {
    let resolvido = false;
    const finalizar = (pemChain) => {
      if (resolvido) return;
      resolvido = true;
      if (pemChain) {
        _caChainMem[hostname] = pemChain;
        try { if (cacheFile) fs.writeFileSync(cacheFile, pemChain); } catch (e) {}
      }
      resolve(pemChain || '');
    };
    try {
      let jaTemDadosDoHandshake = false;
      const socket = tls.connect({ host: hostname, port: 443, servername: hostname, rejectUnauthorized: false, timeout: 10000 }, async () => {
        try {
          const leaf = socket.getPeerCertificate(true);
          let cadeia = '';
          const vistos = new Set();

          // 1) O que o servidor já mandou no handshake (rápido, quando disponível)
          let atual = leaf;
          let voltas = 0;
          while (atual && atual.issuerCertificate && voltas < 6) {
            voltas++;
            const proximo = atual.issuerCertificate;
            const fpAtual = atual.fingerprint256 || atual.fingerprint;
            const fpProx  = proximo.fingerprint256 || proximo.fingerprint;
            if (!fpProx || fpProx === fpAtual || vistos.has(fpProx)) break;
            vistos.add(fpProx);
            cadeia += _certParaPem(proximo.raw);
            atual = proximo;
          }
          // A partir daqui já temos o que precisávamos do socket (o
          // certificado do servidor). Um "error" que apareça DEPOIS
          // disso (ex.: ECONNRESET ao fechar a conexão, muito comum)
          // não deve mais jogar fora o resultado — é só ruído da
          // desconexão, o handler abaixo passa a ignorar.
          jaTemDadosDoHandshake = true;
          socket.end();
          diag.viaHandshake = (cadeia.match(/BEGIN CERTIFICATE/g) || []).length;
          diag.leafPresente = !!(leaf && leaf.raw);
          diag.leafAssunto = leaf && leaf.subject ? (leaf.subject.CN || JSON.stringify(leaf.subject)) : null;

          // 2) AIA chasing de verdade a partir do certificado do servidor —
          //    cobre os casos (comuns na SEFAZ) em que o servidor não manda
          //    a cadeia intermediária completa no aperto de mão.
          if (leaf && leaf.raw) {
            try {
              const leafPem = _certParaPem(leaf.raw);
              diag.aiaUrls = _extrairAiaUrls(leafPem);
              const viaAia = await perseguirAIA(leafPem, 6);
              diag.viaAia = (viaAia.match(/BEGIN CERTIFICATE/g) || []).length;
              if (viaAia) cadeia += viaAia;
            } catch (e) { diag.erroAia = e.message; }
          }

          // 3) Raiz oficial ICP-Brasil publicada pelo governo, como reforço
          //    independente das duas técnicas acima.
          try {
            const viaRaizOficial = await _baixarRaizIcpBrasil();
            diag.viaRaizOficial = (viaRaizOficial.match(/BEGIN CERTIFICATE/g) || []).length;
            if (viaRaizOficial) cadeia += viaRaizOficial;
          } catch (e) { diag.erroRaizOficial = e.message; }

          finalizar(cadeia);
        } catch (e) { diag.erroGeral = e.message; try { socket.end(); } catch(e2){} finalizar(''); }
      });
      socket.on('error', (e) => {
        if (jaTemDadosDoHandshake) return; // ruído de desconexão, já temos o que precisávamos
        diag.erroConexao = e.message; finalizar('');
      });
      socket.on('timeout', () => {
        if (jaTemDadosDoHandshake) return;
        diag.erroConexao = 'timeout ao conectar em '+hostname; socket.destroy(); finalizar('');
      });
    } catch (e) { diag.erroGeral = e.message; finalizar(''); }
  });
}

// POST SOAP genérico para os webservices da SEFAZ, já com a cadeia
// ICP-Brasil resolvida automaticamente. Usado por transmissão de
// NF-e/NFC-e, cancelamento (evento) e consulta de status.
// Certificados do repositório de confiança do próprio Sistema
// Operacional (Windows/macOS), quando o Node.js suportar essa API
// (Node 24+; em versões mais antigas simplesmente não existe, e aqui
// a gente só usa se existir — sem flag de linha de comando nenhuma,
// então não corre risco de travar o programa em versões antigas do
// Node). Em máquinas Windows que já têm a cadeia ICP-Brasil instalada
// (comum em quem usa e-CAC, gov.br, ou instalou o certificado A1 via
// o assistente do fabricante), isso já resolve sozinho.
function _certificadosDoSistema() {
  try {
    if (typeof tls.getCACertificates === 'function') {
      return tls.getCACertificates('system') || [];
    }
  } catch (e) { /* API não disponível nessa versão do Node, segue sem */ }
  return [];
}

async function httpsPostSefaz({ url, soapEnv, soapAction, certPem, keyPem, timeout }) {
  const urlObj = new URL(url);
  const diag = { node: process.version, plataforma: process.platform };
  const cadeiaExtra = await resolverCadeiaCA(urlObj.hostname, diag).catch((e) => { diag.erroResolucao = e.message; return ''; });
  const doSistema = _certificadosDoSistema();
  diag.viaSistema = doSistema.length;
  const cadeiaExtraArr = cadeiaExtra
    ? cadeiaExtra.split(/(?=-----BEGIN CERTIFICATE-----)/).map(s => s.trim()).filter(Boolean)
    : [];
  const caCombinado = (cadeiaExtraArr.length || doSistema.length)
    ? [...tls.rootCertificates, ...doSistema, ...cadeiaExtraArr]
    : undefined; // undefined = Node usa a lista padrão dele (comportamento anterior, sem regressão)
  diag.totalCAsExtras = cadeiaExtraArr.length + doSistema.length;

  return new Promise((resolve, reject) => {
    const options = {
      hostname: urlObj.hostname, port: 443, path: urlObj.pathname + urlObj.search, method: 'POST',
      cert: certPem, key: keyPem,
      headers: {
        // SOAP 1.2 transport: a ação é informada pelo parâmetro "action"
        // do Content-Type. Não enviar o cabeçalho SOAPAction separado:
        // alguns IIS da SEFAZ-SP respondem HTTP 400 quando recebem os dois.
        'Content-Type': `application/soap+xml; charset=utf-8; action="${soapAction}"`,
        'Accept': 'application/soap+xml',
        'User-Agent': 'ERP-AguaMister-SEFAZ/1.6.0',
        'Content-Length': Buffer.byteLength(soapEnv, 'utf8'),
      },
      rejectUnauthorized: true,
      timeout: timeout || 30000,
    };
    if (caCombinado) options.ca = caCombinado;
    diag.url = url;
    diag.method = 'POST';
    diag.soapAction = soapAction;
    diag.contentType = options.headers['Content-Type'];
    diag.requestPath = options.path;

    const req = https.request(options, res => {
      // Descobre, de forma definitiva, se o NOSSO certificado (o A1 do
      // cliente) foi realmente enviado nessa conexão. Isso separa dois
      // problemas bem diferentes por trás de um HTTP 403 do IIS:
      // (a) o certificado não foi enviado/aceito -> dá pra corrigir aqui
      // (b) o certificado foi aceito mas a SEFAZ bloqueou o IP de origem
      //     -> nenhum ajuste de código resolve, só trocar de rede/host
      try {
        const sock = res.socket;
        const certUsado = sock && sock.getCertificate && sock.getCertificate();
        diag.certClienteEnviado = !!(certUsado && certUsado.subject);
        diag.certClienteAssunto = certUsado && certUsado.subject ? (certUsado.subject.CN || JSON.stringify(certUsado.subject)) : null;
        diag.tlsAuthorized = sock ? sock.authorized : null;
        diag.tlsAuthError  = sock && sock.authorizationError ? String(sock.authorizationError) : null;
      } catch (e) { diag.erroDiagCert = e.message; }

      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        diag.http = res.statusCode;
        diag.responseHeaders = res.headers;
        diag.responseBody = data.slice(0, 5000);
        diag.responseBodyLength = Buffer.byteLength(data, 'utf8');
        diag.httpServer = res.headers && (res.headers.server || null);
        diag.http404 = res.statusCode === 404;
        diag.http403 = res.statusCode === 403;
        resolve({ http: res.statusCode, xml: data, headers: res.headers, diagConexao: diag });
      });
    });
    req.on('error', (e) => { e.diagCA = diag; reject(e); });
    req.on('timeout', () => { req.destroy(); const e = new Error('Timeout SEFAZ'); e.diagCA = diag; reject(e); });
    req.write(soapEnv);
    req.end();
  });
}

// Proteção contra Consumo Indevido no Web Service de AUTORIZAÇÃO.
//
// IMPORTANTE: o cStat 656 NÃO deve bloquear todas as vendas do ERP por uma
// hora. Na SEFAZ-SP, o bloqueio é da mesma solicitação: se a NF-e for
// alterada, uma nova solicitação pode ser transmitida. Portanto, o ERP
// precisa impedir somente a retransmissão idêntica e não criar um
// "cooldown" global que paralise o PDV.
//
// Também impedimos duas transmissões simultâneas do MESMO XML, evitando
// duplo clique/requisições duplicadas. Cada nova emissão monta uma nova
// chave de acesso (cNF aleatório), portanto é uma nova solicitação.
const TRANSMISSOES_EM_ANDAMENTO = new Set();
const REQUISICOES_656 = new Set();
const VENDA_EM_ANDAMENTO = new Set();
const SEFAZ_GUARD_FILE = path.join(PASTA_DADOS, 'sefaz-autorizacao-guard.json');
let SEFAZ_GUARD = {};
try {
  if (fs.existsSync(SEFAZ_GUARD_FILE)) SEFAZ_GUARD = JSON.parse(fs.readFileSync(SEFAZ_GUARD_FILE, 'utf8')) || {};
} catch (e) { SEFAZ_GUARD = {}; }
function salvarGuardSefaz() {
  try { fs.writeFileSync(SEFAZ_GUARD_FILE, JSON.stringify(SEFAZ_GUARD, null, 2), { mode: 0o600 }); } catch (e) {}
}
function chaveGuardSefaz(tpAmb, isNFCe) { return String(tpAmb) + ':' + (isNFCe ? '65' : '55'); }
function verificarGuardSefaz(tpAmb, isNFCe) {
  const k = chaveGuardSefaz(tpAmb, isNFCe);
  const g = SEFAZ_GUARD[k];
  if (g && Number(g.blockedUntil || 0) > Date.now()) {
    const restante = Math.ceil((Number(g.blockedUntil) - Date.now()) / 60000);
    const erro = new Error('Proteção local ativa após cStat 656. Nenhuma nova transmissão será enviada à SEFAZ durante o bloqueio registrado (' + restante + ' min restantes).');
    erro.code = 'SEFAZ_656_BLOQUEIO_LOCAL';
    erro.blockedUntil = Number(g.blockedUntil);
    throw erro;
  }
  if (g && Number(g.blockedUntil || 0) <= Date.now()) { delete SEFAZ_GUARD[k]; salvarGuardSefaz(); }
}
function registrarGuardSefaz(tpAmb, isNFCe, motivo) {
  const k = chaveGuardSefaz(tpAmb, isNFCe);
  SEFAZ_GUARD[k] = { blockedUntil: Date.now() + 60 * 60 * 1000, last656At: new Date().toISOString(), motivo: motivo || '656' };
  salvarGuardSefaz();
}

async function transmitirSEFAZ(xmlAssinado, tpAmb, isNFCe) {
  const tipo = isNFCe ? 'nfce' : 'nfe';
  const url  = ENDPOINTS[tipo][tpAmb] || ENDPOINTS[tipo]['2'];
  verificarGuardSefaz(tpAmb, isNFCe);
  const fingerprint = crypto.createHash('sha256').update(String(xmlAssinado)).digest('hex');

  if (REQUISICOES_656.has(fingerprint)) {
    const erro = new Error('Esta mesma NF-e já recebeu cStat 656. Gere uma nova emissão corrigida; não retransmita o XML idêntico.');
    erro.code = 'SEFAZ_656_MESMA_REQUISICAO';
    throw erro;
  }

  if (TRANSMISSOES_EM_ANDAMENTO.has(fingerprint)) {
    const erro = new Error('Esta mesma NF-e já está sendo transmitida para a SEFAZ. Aguarde a resposta antes de tentar novamente.');
    erro.code = 'SEFAZ_TRANSMISSAO_DUPLICADA';
    throw erro;
  }

  TRANSMISSOES_EM_ANDAMENTO.add(fingerprint);
  try {

  // O lote está dentro do SOAP Body; NÃO pode conter uma segunda
  // declaração XML (<?xml ...?>). Isso torna o documento SOAP inválido
  // e pode provocar HTTP 400 antes mesmo de a SEFAZ processar o XML.
  //
  // IMPORTANTE: nada de quebra de linha/indentação entre as tags aqui
  // nem no soapEnv abaixo. A SEFAZ rejeita (cStat 588 - "não é
  // permitida a presença de caracteres de edição no início/fim da
  // mensagem ou entre as tags da mensagem") se o XML dentro do
  // <nfeDadosMsg> vier "bonitinho"/formatado com \n e espaços entre
  // tags - tem que ser uma única linha, sem nenhum caractere entre o
  // fechamento de uma tag e a abertura da próxima.
  const lote = `<enviNFe xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00"><idLote>${Date.now()}</idLote><indSinc>1</indSinc>${xmlAssinado}</enviNFe>`;

  const soapAction = isNFCe
    ? 'http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4/nfeAutorizacaoLote'
    : 'http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4/nfeAutorizacaoLote';

  const soapEnv = `<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4">${lote}</nfeDadosMsg></soap12:Body></soap12:Envelope>`;

  if (!CERT_STATE.loaded) throw new Error('Certificado não carregado');

  const certPem = fs.readFileSync(path.join(__dirname, 'cert.pem'));
  const keyPem  = fs.readFileSync(path.join(__dirname, 'key.pem'));

    const resp = await httpsPostSefaz({ url, soapEnv, soapAction, certPem, keyPem, timeout: 30000 });
    return resp; // {http, xml} — o chamador decide o que fazer com o status HTTP
  } finally {
    TRANSMISSOES_EM_ANDAMENTO.delete(fingerprint);
  }
}

function registrarConsumoIndevido(xmlAssinado) {
  // Marca SOMENTE esta solicitação. Uma nova NF-e, mesmo para o mesmo
  // produto/cliente/valor, terá outra chave/cNF e poderá ser transmitida.
  const fingerprint = crypto.createHash('sha256').update(String(xmlAssinado)).digest('hex');
  REQUISICOES_656.add(fingerprint);
}

// Interpreta a resposta da SEFAZ. Cobre 3 formatos possíveis:
// 1) Resposta normal de autorização (<cStat>/<xMotivo> dentro do corpo)
// 2) SOAP Fault (erro de protocolo/segurança — SEFAZ recusou o pedido
//    antes mesmo de processar a NF-e; muito comum quando o certificado
//    é aceito na camada TLS mas rejeitado na autenticação do WS-Security,
//    ou quando o XML/SOAP enviado tem algum problema de formato)
// 3) Corpo vazio ou HTTP de erro sem XML nenhum
function _xmlTag(bloco, tag) {
  if (!bloco) return '';
  const re = new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'i');
  const m = bloco.match(re);
  return m ? m[1].trim() : '';
}

function _extrairProtNFe(xmlResp) {
  const lista = [];
  const re = /<protNFe(?:\s[^>]*)?>[\s\S]*?<\/protNFe>/gi;
  let m;
  while ((m = re.exec(xmlResp || '')) !== null) {
    const bloco = m[0];
    const infProt = bloco.match(/<infProt(?:\s[^>]*)?>[\s\S]*?<\/infProt>/i);
    const base = infProt ? infProt[0] : bloco;
    lista.push({
      cStat: _xmlTag(base, 'cStat'),
      xMotivo: _xmlTag(base, 'xMotivo'),
      chNFe: _xmlTag(base, 'chNFe'),
      nProt: _xmlTag(base, 'nProt'),
      dhRecbto: _xmlTag(base, 'dhRecbto'),
      digVal: _xmlTag(base, 'digVal'),
      tpAmb: _xmlTag(base, 'tpAmb'),
      verAplic: _xmlTag(base, 'verAplic'),
    });
  }
  return lista;
}

// Interpreta a resposta da SEFAZ separando o status do LOTE do status
// fiscal de cada NF-e. Em uma resposta síncrona normal, a SEFAZ pode
// devolver cStat=104 (Lote processado) no nível externo e, dentro de
// <protNFe>/<infProt>, cStat=100 (Autorizado) ou outro código de rejeição.
function parseSEFAZResp(xmlResp, httpStatus) {
  const texto = xmlResp || '';
  const protocolos = _extrairProtNFe(texto);
  const cStatMatch = texto.match(/<cStat(?:\s[^>]*)?>(\d+)<\/cStat>/i);
  const cStatLote = cStatMatch ? cStatMatch[1] : '';
  const xMotivoLote = (texto.match(/<xMotivo(?:\s[^>]*)?>([^<]+)<\/xMotivo>/i) || [])[1] || '';

  // Prioridade: protocolo individual. Isso impede que 104 seja tratado
  // como se fosse uma rejeição da NF-e.
  if (protocolos.length) {
    const primeiro = protocolos[0];
    const autorizadas = protocolos.filter(p => p.cStat === '100' || p.cStat === '150');
    const rejeitadas = protocolos.filter(p => p.cStat && p.cStat !== '100' && p.cStat !== '150');
    const autorizado = protocolos.length === 1
      ? (primeiro.cStat === '100' || primeiro.cStat === '150')
      : autorizadas.length === protocolos.length;

    let status = 'REJEITADA';
    if (autorizado) status = 'AUTORIZADA';
    else if (protocolos.some(p => p.cStat === '110')) status = 'DENEGADA';

    return {
      cStat: primeiro.cStat || cStatLote || 'SEM_CSTAT',
      cStatLote: cStatLote || '',
      xMotivo: primeiro.xMotivo || xMotivoLote || 'Resultado fiscal recebido da SEFAZ',
      xMotivoLote: xMotivoLote || '',
      nProt: primeiro.nProt || '',
      dhRecbto: primeiro.dhRecbto || '',
      chNFe: primeiro.chNFe || '',
      digVal: primeiro.digVal || '',
      tpAmb: primeiro.tpAmb || '',
      verAplic: primeiro.verAplic || '',
      autorizado,
      status,
      protocolos,
      quantidadeProtocolos: protocolos.length,
      rejeitadas,
      respostaLote: cStatLote === '104' ? 'LOTE_PROCESSADO' : (cStatLote || ''),
    };
  }

  if (cStatLote) {
    const autorizado = cStatLote === '100' || cStatLote === '150';
    return {
      cStat: cStatLote,
      cStatLote,
      xMotivo: xMotivoLote || 'Erro desconhecido',
      xMotivoLote,
      nProt: '', dhRecbto: '', chNFe: '', digVal: '', tpAmb: '', verAplic: '',
      autorizado,
      status: autorizado ? 'AUTORIZADA' : (cStatLote === '110' ? 'DENEGADA' : 'REJEITADA'),
      protocolos: [], quantidadeProtocolos: 0, rejeitadas: [],
      respostaLote: cStatLote === '104' ? 'LOTE_PROCESSADO' : cStatLote,
    };
  }

  const faultMsg = (texto.match(/<faultstring>([^<]+)<\/faultstring>/i) || [])[1]
    || (texto.match(/<soap:Text[^>]*>([^<]+)<\/soap:Text>/i) || [])[1]
    || (texto.match(/<Text[^>]*>([^<]+)<\/Text>/i) || [])[1]
    || (texto.match(/<Reason>[\s\S]*?<Text[^>]*>([^<]+)<\/Text>/i) || [])[1];

  if (faultMsg) {
    return { cStat: 'SOAP_FAULT', cStatLote: '', xMotivo: faultMsg.trim(), xMotivoLote: '', nProt: '', dhRecbto: '', chNFe: '', autorizado: false, status: 'REJEITADA', protocolos: [], quantidadeProtocolos: 0, rejeitadas: [] };
  }

  const corpoVazio = !texto.trim();
  const trecho = texto.replace(/\s+/g, ' ').trim().slice(0, 1000);
  let motivo = corpoVazio
    ? 'A SEFAZ respondeu, mas sem nenhum conteúdo'
    : 'Resposta da SEFAZ em formato inesperado: ' + trecho;
  if (httpStatus === 404) {
    motivo = 'HTTP 404 - endpoint do Web Service não encontrado pela SEFAZ. Verifique URL, caminho e nome exato do .asmx. Resposta: ' + (trecho || '(vazia)');
  } else if (httpStatus === 403) {
    motivo = 'HTTP 403 - acesso negado pelo Web Service. O endpoint foi encontrado, mas a requisição foi recusada. Verifique certificado A1/mTLS, credenciamento e origem da conexão. Resposta: ' + (trecho || '(vazia)');
  } else if (httpStatus && httpStatus >= 400) {
    motivo = 'HTTP ' + httpStatus + ' retornado pelo Web Service da SEFAZ. Resposta: ' + (trecho || '(vazia)');
  }
  return {
    cStat: httpStatus === 404 ? 'HTTP_404' : (httpStatus === 403 ? 'HTTP_403' : 'SEM_CSTAT'),
    cStatLote: '', xMotivo: motivo, xMotivoLote: '', nProt: '', dhRecbto: '', chNFe: '',
    autorizado: false, status: 'REJEITADA', protocolos: [], quantidadeProtocolos: 0, rejeitadas: [],
  };
}

// Envia um evento (cancelamento, carta de correção etc.) já assinado
// para o webservice de Recepção de Evento da SEFAZ - serviço diferente
// do de autorização de NF-e, com SOAPAction e URL próprios.
async function transmitirEventoSEFAZ(envEventoAssinado, tpAmb, modelo) {
  const tipo = String(modelo || '55') === '65' ? 'nfce' : 'nfe';
  const url = ENDPOINTS.evento[tipo][tpAmb] || ENDPOINTS.evento[tipo]['2'];
  const soapAction = 'http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4/nfeRecepcaoEvento';

  // Mesma regra do lote de autorização: mensagem inteira em uma linha
  // só, sem espaço/quebra de linha entre tags (SEFAZ rejeita com
  // cStat 588 caso contrário).
  const soapEnv = `<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4">${envEventoAssinado}</nfeDadosMsg></soap12:Body></soap12:Envelope>`;

  if (!CERT_STATE.loaded) throw new Error('Certificado não carregado');

  const certPem = fs.readFileSync(path.join(__dirname, 'cert.pem'));
  const keyPem  = fs.readFileSync(path.join(__dirname, 'key.pem'));

  const resp = await httpsPostSefaz({ url, soapEnv, soapAction, certPem, keyPem, timeout: 30000 });
  return resp; // {http, xml}
}

function parseEventoResp(xmlResp) {
  // A resposta traz DOIS <cStat>: o do lote (dentro de <retEnvEvento>,
  // normalmente 128 = "Lote de Evento Processado" - só diz que a SEFAZ
  // processou o lote, não que o cancelamento foi aceito) e o do evento
  // em si (dentro de <retEvento><infEvento>, ex.: 135 = homologado, ou
  // o código de rejeição). É esse segundo que precisa ser lido; usar o
  // primeiro <cStat> encontrado faz o sistema sempre reportar 128 (ou
  // o status do lote) em vez do resultado real do cancelamento.
  const infEventoBloco = xmlResp.match(/<infEvento[^>]*>([\s\S]*?)<\/infEvento>/i);
  const escopo = infEventoBloco ? infEventoBloco[1] : xmlResp;

  const cStatMatch = escopo.match(/<cStat>(\d+)<\/cStat>/);
  if (!cStatMatch) {
    const faultMsg = (xmlResp.match(/<faultstring>([^<]+)<\/faultstring>/i) || [])[1]
      || (xmlResp.match(/<Text[^>]*>([^<]+)<\/Text>/i) || [])[1];
    return { cStat: faultMsg ? 'SOAP_FAULT' : 'SEM_CSTAT', xMotivo: faultMsg || 'Resposta da SEFAZ em formato inesperado', nProt: '', dhRegEvento: '', homologado: false };
  }
  const cStat   = cStatMatch[1];
  const xMotivo = (escopo.match(/<xMotivo>([^<]+)<\/xMotivo>/) || [])[1] || 'Erro desconhecido';
  const nProt   = (escopo.match(/<nProt>(\d+)<\/nProt>/) || [])[1] || '';
  const dhRegEvento = (escopo.match(/<dhRegEvento>([^<]+)<\/dhRegEvento>/) || [])[1] || '';
  // 135 = evento registrado e vinculado à NF-e (cancelamento efetivado)
  // 136 = evento registrado, mas não vinculado (raro, tratar como falha aqui)
  const homologado = cStat === '135';
  return { cStat, xMotivo, nProt, dhRegEvento, homologado };
}

// ============================================================
//  CLASSIFICADOR DE ERROS DE EMISSÃO
//  Garante que TODA falha (rede, certificado, XML, timeout,
//  SEFAZ fora do ar etc.) sempre volte pro front com cStat e
//  xMotivo preenchidos — nunca "undefined". Antes disso, um
//  erro lançado antes de chegar na resposta da SEFAZ (ex.: sem
//  internet) caía direto no catch e voltava só como
//  { ok:false, erro: err.message }, e a tela mostrava
//  "SEFAZ rejeitou: cStat undefined — undefined" porque o
//  front espera sempre res.cStat/res.xMotivo.
// ============================================================
const CA_ISSUER_HOSTS = ['nfe.fazenda.sp.gov.br', 'homologacao.nfe.fazenda.sp.gov.br', 'nfce.fazenda.sp.gov.br', 'homologacao.nfce.fazenda.sp.gov.br'];
function _invalidarCacheCA() {
  // Limpa o cache de cadeia de certificados (memória + disco) pra forçar
  // uma resolução do zero na próxima tentativa. Usado quando a
  // transmissão falha justamente por causa da cadeia de certificados —
  // é possível que a resolução anterior tenha sido parcial (ex.: timeout
  // baixando um certificado intermediário).
  for (const h of CA_ISSUER_HOSTS) {
    delete _caChainMem[h];
    try {
      const f = path.join(CA_CACHE_DIR, h.replace(/[^a-z0-9.-]/gi, '_') + '.pem');
      if (fs.existsSync(f)) fs.unlinkSync(f);
    } catch (e) {}
  }
}

// Quando a SEFAZ devolve algo diferente de <cStat> (SOAP Fault, HTML de
// erro do IIS, etc.), monta um texto explicando o que a conexão TLS
// realmente enviou/recebeu — em especial se o NOSSO certificado A1 foi
// aceito, o que separa "problema de certificado" de "IP bloqueado pela
// SEFAZ" (esse segundo não tem correção possível no código).
function _detalheDiagConexao(resp) {
  const d = resp && resp.diagConexao;
  if (!d) return '';
  const partes = [];
  if (typeof d.certClienteEnviado === 'boolean') {
    partes.push(d.certClienteEnviado
      ? 'certificado A1 do cliente FOI enviado e aceito na conexão TLS (assunto: ' + (d.certClienteAssunto || '?') + ')'
      : 'certificado A1 do cliente NÃO foi enviado na conexão TLS — isso por si só já explica um 403/negação de acesso');
  }
  if (d.tlsAuthorized === false && d.tlsAuthError) partes.push('TLS não autorizado: ' + d.tlsAuthError);
  return partes.join(' · ');
}

function classificarErroEmissao(err) {
  const msg = String((err && err.message) || err || 'Erro desconhecido');
  const m   = msg.toLowerCase();

  if (m.includes('csc_nao_configurado') || m.includes('csc') && m.includes('nfc-e'))
    return { cStat: 'SEM_CSC', xMotivo: msg.replace(/^CSC_NAO_CONFIGURADO:\s*/i, ''), categoria: 'CONFIGURACAO',
      sugestao: 'Cadastre o CSC e o ID do CSC do ambiente da NFC-e em Configurações > CSC da NFC-e.', corrigivel: true };

  if (m.includes('certificado não carregado') || m.includes('certificado nao carregado'))
    return { cStat: 'CERT', xMotivo: 'Certificado A1 não carregado no backend', categoria: 'CERTIFICADO',
      sugestao: 'Vá em Certificado A1 e carregue o arquivo .pfx com a senha novamente.', corrigivel: false };

  if (m.includes('expired') || m.includes('expirad'))
    return { cStat: 'CERT_VENC', xMotivo: 'Certificado A1 vencido', categoria: 'CERTIFICADO',
      sugestao: 'O certificado A1 expirou. É necessário renovar com a Autoridade Certificadora e carregar o novo .pfx.', corrigivel: false };

  if (m.includes('issuer certificate') || m.includes('unable_to_get_issuer_cert') || m.includes('use-system-ca') || m.includes('use_system_ca')) {
    const d = (err && err.diagCA) || null;
    const diagTxt = d ? (
      'Node ' + d.node + ' (' + d.plataforma + ') · '
      + 'via handshake: ' + (d.viaHandshake ?? '?') + ' certs · '
      + 'via AIA: ' + (d.viaAia ?? '?') + ' certs' + (d.aiaUrls && d.aiaUrls.length ? ' (URLs: ' + d.aiaUrls.join(', ') + ')' : ' (sem URL de AIA no certificado)') + ' · '
      + 'via raiz oficial: ' + (d.viaRaizOficial ?? '?') + ' certs · '
      + 'via sistema operacional: ' + (d.viaSistema ?? '?') + ' certs'
      + (d.erroConexao ? ' · erro de conexão ao resolver: ' + d.erroConexao : '')
      + (d.erroAia ? ' · erro no AIA: ' + d.erroAia : '')
      + (d.erroRaizOficial ? ' · erro ao baixar raiz oficial: ' + d.erroRaizOficial : '')
    ) : 'Sem informação de diagnóstico disponível.';
    return { cStat: 'CERT_CADEIA', xMotivo: 'Não foi possível validar a cadeia de certificados (ICP-Brasil) do servidor da SEFAZ', categoria: 'CERTIFICADO',
      sugestao: 'O sistema tenta resolver isso sozinho automaticamente na próxima tentativa. Se persistir, copie o "detalhe" deste erro no Log de Erros e envie — ele mostra exatamente qual etapa da resolução da cadeia falhou.',
      corrigivel: true, detalhe: diagTxt };
  }

  if (m.includes('unable_to_verify_leaf_signature') || m.includes('self signed') || m.includes('ssl') || m.includes('cert_') || m.includes('handshake'))
    return { cStat: 'CERT_SSL', xMotivo: 'Falha de SSL/TLS ao conectar na SEFAZ com o certificado atual', categoria: 'CERTIFICADO',
      sugestao: 'Confirme que o .pfx carregado é um certificado e-CNPJ/e-CPF A1 válido (não autoassinado) para o CNPJ emitente.', corrigivel: false };

  if (err && err.code === 'SEFAZ_656_BLOQUEIO_LOCAL')
    return { cStat: '656', xMotivo: err.message, categoria: 'PROTECAO_SEFAZ',
      sugestao: 'Nenhuma transmissão foi enviada à SEFAZ durante a proteção local. Aguarde o desbloqueio informado no ERP e não tente repetir em sequência.',
      corrigivel: false, bloqueadoAte: err.blockedUntil || null };
  if (err && err.code === 'SEFAZ_656_MESMA_REQUISICAO')
    return { cStat: '656', xMotivo: 'Rejeição: Consumo Indevido — esta NF-e já recebeu 656', categoria: 'SEFAZ',
      sugestao: 'Não retransmita o XML rejeitado. Gere uma nova emissão somente após o bloqueio da SEFAZ terminar.',
      corrigivel: false };

  if (err && err.code === 'SEFAZ_TRANSMISSAO_DUPLICADA')
    return { cStat: 'DUPLICADA', xMotivo: 'Esta mesma NF-e já está em transmissão', categoria: 'SEFAZ',
      sugestao: 'Aguarde a resposta da primeira transmissão. O ERP bloqueia apenas a duplicação simultânea.',
      corrigivel: true };

  if (m.includes('timeout'))
    return { cStat: 'TIMEOUT', xMotivo: 'A SEFAZ não respondeu a tempo (timeout de 30s)', categoria: 'REDE',
      sugestao: 'A SEFAZ pode estar instável. Aguarde um instante e tente transmitir novamente.', corrigivel: true };

  if (m.includes('econnrefused') || m.includes('enotfound') || m.includes('eai_again') || m.includes('network') || m.includes('getaddrinfo'))
    return { cStat: 'REDE', xMotivo: 'Falha de conexão com o webservice da SEFAZ', categoria: 'REDE',
      sugestao: 'Verifique a internet deste computador. Se estiver tudo certo, os servidores da SEFAZ podem estar fora do ar.', corrigivel: true };

  if (m.includes('pelo menos um item'))
    return { cStat: 'SEM_ITEM', xMotivo: msg, categoria: 'XML',
      sugestao: 'Adicione ao menos um produto antes de emitir.', corrigivel: false };

  if (m.includes('destinatario') || m.includes('destinatário'))
    return { cStat: 'DEST_INVALIDO', xMotivo: msg, categoria: 'XML',
      sugestao: 'Confira o CNPJ/CPF do destinatário — precisa ter 11 (CPF) ou 14 (CNPJ) dígitos.', corrigivel: true };

  return { cStat: 'ERRO', xMotivo: msg, categoria: 'SISTEMA',
    sugestao: 'Erro inesperado ao montar/assinar/transmitir a nota. Veja o log completo para detalhes.', corrigivel: false };
}

// ============================================================
//  ROTA: EMITIR NF-e (Mod. 55)
// ============================================================

app.post('/api/nfe/emitir', async (req, res) => {
  return comLockEmissao('nfe', async () => {
  if (!CERT_STATE.loaded) return res.status(400).json({
    ok: false, erro: 'Certificado A1 não carregado. Carregue via /api/certificado/carregar',
    cStat: 'CERT', xMotivo: 'Certificado A1 não carregado', categoria: 'CERTIFICADO',
    sugestao: 'Vá em Certificado A1 e carregue o arquivo .pfx com a senha.', corrigivel: false,
  });

  try {
    const vendaId = String(req.body && req.body.vendaId || '').trim();
    if (vendaId) {
      if (VENDA_EM_ANDAMENTO.has(vendaId)) {
        const e = new Error('Esta venda já está em transmissão. O ERP bloqueou a duplicação para não enviar duas NF-e à SEFAZ.');
        e.code='VENDA_DUPLICADA';
        throw e;
      }
      VENDA_EM_ANDAMENTO.add(vendaId);
    }

    const xmlDir = PASTA_XML;
    const MAX_TENTATIVAS_DUPLICIDADE = 20;
    let tentativa = 0;
    let dadosEmissao = { ...(req.body || {}) };
    // Reserva o número ANTES de montar o XML. Isso impede duas vendas
    // simultâneas de receberem o mesmo nNF.
    dadosEmissao._nNFOverride = reservarProximoNumero('55');
    let resultado, respSEFAZ, xmlAssinado, chave, nNF, tpAmb, vNF, dhEmi, teste, xmlStrAtual;

    while (tentativa < MAX_TENTATIVAS_DUPLICIDADE) {
      tentativa++;

      const built = buildXML(dadosEmissao, '55');
      ({ xmlStr: xmlStrAtual, chave, nNF, tpAmb, vNF, dhEmi, teste } = built);
      xmlAssinado = assinaarXML(xmlStrAtual, `NFe${chave}`);

      respSEFAZ = await transmitirSEFAZ(xmlAssinado, tpAmb, false);
      resultado = parseSEFAZResp(respSEFAZ.xml, respSEFAZ.http);

      if (resultado.cStat !== '539' || tentativa >= MAX_TENTATIVAS_DUPLICIDADE) break;

      // cStat 539 = a mesma série/número já existe com outra chave.
      // Não retransmitir a mesma chave: avança a numeração local, persiste
      // imediatamente e gera uma NOVA chave/XML/assinatura. Isso é seguro
      // porque a numeração anterior já está ocupada na SEFAZ.
      const proximoNumero = reservarNumeroApos539('55', resultado, nNF);
      dadosEmissao._nNFOverride = proximoNumero;

      console.warn(`[SEFAZ] cStat 539: número ${nNF} já utilizado. Tentativa automática ${tentativa + 1}/${MAX_TENTATIVAS_DUPLICIDADE} com nNF ${proximoNumero}.`);
    }

    if (resultado.cStat === '656') {
      registrarConsumoIndevido(xmlAssinado);
      registrarGuardSefaz(tpAmb, false, resultado.xMotivo);
    }

    const blocoProt = extrairBlocoProt(respSEFAZ.xml);

    if (resultado.autorizado) {
      const nfeProc = montarNFeProc(xmlAssinado, blocoProt);
      fs.writeFileSync(path.join(xmlDir, `nfe_${chave}.xml`), nfeProc);

      // A numeração já foi reservada e persistida antes da transmissão.
      // Não incrementar novamente aqui: isso evita saltos indevidos.
    } else {
      fs.writeFileSync(path.join(xmlDir, `nfe_${chave}_REJEITADA.xml`), xmlAssinado);
    }

    if (vendaId) VENDA_EM_ANDAMENTO.delete(vendaId);

    const recuperado539 = tentativa > 1 && resultado.autorizado;
    res.json({
      ok: resultado.autorizado,
      cStat: resultado.cStat,
      xMotivo: resultado.xMotivo,
      nProt: resultado.nProt,
      chNFe: resultado.chNFe,
      dhRecbto: resultado.dhRecbto,
      cStatLote: resultado.cStatLote,
      xMotivoLote: resultado.xMotivoLote,
      statusFiscal: resultado.status,
      protocolos: resultado.protocolos,
      quantidadeProtocolos: resultado.quantidadeProtocolos,
      detalhe: resultado.autorizado ? undefined : _detalheDiagConexao(respSEFAZ),
      sugestao: resultado.cStat === '434'
        ? 'O XML agora informa indIntermed=0 para venda direta, sem marketplace/intermediador. Se a operação usar marketplace, configure indIntermed=1 e os dados do intermediador.'
        : (resultado.cStat === '539'
          ? 'A numeração já estava ocupada na SEFAZ. O ERP tentou automaticamente a próxima numeração disponível, sem reenviar a mesma chave.'
          : (resultado.cStat === '656'
            ? 'A SEFAZ rejeitou por Consumo Indevido. O ERP interrompeu novas transmissões para proteger o ambiente fiscal; não haverá retransmissão automática.'
            : '')),
      corrigivel: resultado.cStat === '434' || resultado.cStat === '539',
      recuperadoAutomaticamente: recuperado539,
      tentativas: tentativa,
      http: respSEFAZ.http,
      chave,
      nNF,
      dhEmi,
      vNF,
      xmlAssinado,
      ambiente: tpAmb === '1' ? 'Produção' : 'Homologação',
      teste: tpAmb === '2',
    });

  } catch (err) {
    if (req.body && req.body.vendaId) VENDA_EM_ANDAMENTO.delete(String(req.body.vendaId));
    console.error('Erro NF-e:', err.message);
    const cls = classificarErroEmissao(err);
    if (cls.cStat === 'CERT_CADEIA') _invalidarCacheCA();
    res.status(500).json({ ok: false, erro: err.message, ...cls });
  }
  });
});

// ============================================================
//  ROTA: EMITIR NFC-e (Mod. 65)
// ============================================================

app.post('/api/nfce/emitir', async (req, res) => {
  return comLockEmissao('nfce', async () => {
  if (!CERT_STATE.loaded) return res.status(400).json({
    ok: false, erro: 'Certificado A1 não carregado',
    cStat: 'CERT', xMotivo: 'Certificado A1 não carregado', categoria: 'CERTIFICADO',
    sugestao: 'Vá em Certificado A1 e carregue o arquivo .pfx com a senha.', corrigivel: false,
  });

  try {
    const xmlDir = PASTA_XML;
    const MAX_TENTATIVAS_DUPLICIDADE = 20;
    let tentativa = 0;
    let dadosEmissao = { ...(req.body || {}) };
    // Reserva o número ANTES de montar o XML, inclusive para NFC-e.
    dadosEmissao._nNFOverride = reservarProximoNumero('65');
    let resultado, respSEFAZ, xmlAssinado, chave, nNF, tpAmb, vNF, dhEmi, teste, xmlStrAtual;

    while (tentativa < MAX_TENTATIVAS_DUPLICIDADE) {
      tentativa++;

      const built = buildXML(dadosEmissao, '65');
      ({ xmlStr: xmlStrAtual, chave, nNF, tpAmb, vNF, dhEmi, teste } = built);

      let xmlComSupl = assinaarXML(xmlStrAtual, `NFe${chave}`);
      xmlAssinado = inserirInfNFeSupl(xmlComSupl, chave, tpAmb);

      respSEFAZ = await transmitirSEFAZ(xmlAssinado, tpAmb, true);
      resultado = parseSEFAZResp(respSEFAZ.xml, respSEFAZ.http);

      if (resultado.cStat !== '539' || tentativa >= MAX_TENTATIVAS_DUPLICIDADE) break;

      const proximoNumero = reservarNumeroApos539('65', resultado, nNF);
      dadosEmissao._nNFOverride = proximoNumero;

      console.warn(`[SEFAZ] NFC-e cStat 539: número ${nNF} já utilizado. Tentativa automática ${tentativa + 1}/${MAX_TENTATIVAS_DUPLICIDADE} com nNF ${proximoNumero}.`);
    }

    if (resultado.cStat === '656') {
      registrarConsumoIndevido(xmlAssinado);
      registrarGuardSefaz(tpAmb, true, resultado.xMotivo);
    }

    const blocoProt = extrairBlocoProt(respSEFAZ.xml);

    if (resultado.autorizado) {
      const nfeProc = montarNFeProc(xmlAssinado, blocoProt);
      fs.writeFileSync(path.join(xmlDir, `nfce_${chave}.xml`), nfeProc);
      // A numeração já foi reservada e persistida antes da transmissão.
      // Não incrementar novamente aqui.
    } else {
      fs.writeFileSync(path.join(xmlDir, `nfce_${chave}_REJEITADA.xml`), xmlAssinado);
    }

    const recuperado539 = tentativa > 1 && resultado.autorizado;
    res.json({
      ok: resultado.autorizado,
      cStat: resultado.cStat,
      xMotivo: resultado.xMotivo,
      nProt: resultado.nProt,
      chNFe: resultado.chNFe,
      dhRecbto: resultado.dhRecbto,
      cStatLote: resultado.cStatLote,
      xMotivoLote: resultado.xMotivoLote,
      statusFiscal: resultado.status,
      protocolos: resultado.protocolos,
      quantidadeProtocolos: resultado.quantidadeProtocolos,
      detalhe: resultado.autorizado ? undefined : _detalheDiagConexao(respSEFAZ),
      sugestao: resultado.cStat === '539'
        ? 'A numeração já estava ocupada na SEFAZ. O ERP tentou automaticamente a próxima numeração disponível, sem reenviar a mesma chave.'
        : (resultado.cStat === '656'
          ? 'A SEFAZ rejeitou por Consumo Indevido. O ERP interrompeu novas transmissões para proteger o ambiente fiscal; não haverá retransmissão automática.'
          : ''),
      corrigivel: resultado.cStat === '539',
      recuperadoAutomaticamente: recuperado539,
      tentativas: tentativa,
      http: respSEFAZ.http,
      chave,
      nNF,
      dhEmi,
      vNF,
      xmlAssinado,
      ambiente: tpAmb === '1' ? 'Produção' : 'Homologação',
      teste: tpAmb === '2',
    });

  } catch (err) {
    console.error('Erro NFC-e:', err.message);
    const cls = classificarErroEmissao(err);
    if (cls.cStat === 'CERT_CADEIA') _invalidarCacheCA();
    res.status(500).json({ ok: false, erro: err.message, ...cls });
  }
  });
});

// ============================================================
//  ROTA: CANCELAR NOTA
// ============================================================

// ============================================================
//  ROTA: CANCELAR NOTA (evento 110111 - cancelamento)
// ============================================================
// IMPORTANTE: não existe "apagar" ou "resetar" uma nota autorizada na
// SEFAZ - ela é um registro público permanente. O único mecanismo
// legal é este evento de CANCELAMENTO, que só é aceito dentro do
// prazo definido pela SEFAZ-SP (em geral, algumas horas após a
// autorização - a própria SEFAZ informa o prazo no retorno se ele já
// tiver expirado). Depois desse prazo, o caminho é Carta de Correção
// (erros que não mudam valores) ou uma nota de devolução/ajuste.

app.post('/api/nfe/cancelar', async (req, res) => {
  const { chave, nProt, justificativa } = req.body;
  if (!chave || !/^\d{44}$/.test(chave)) return res.status(400).json({ ok: false, erro: 'Chave de acesso inválida (precisa ter 44 dígitos)' });
  const modeloEvento = String((req.body && req.body.modelo) || chave.slice(20, 22));
  if (modeloEvento !== '55' && modeloEvento !== '65') return res.status(400).json({ ok: false, erro: 'Modelo fiscal inválido. Informe 55 (NF-e) ou 65 (NFC-e).' });
  if (!nProt) return res.status(400).json({ ok: false, erro: 'Informe o número de protocolo de autorização da nota (nProt)' });
  if (!justificativa || justificativa.trim().length < 15) return res.status(400).json({ ok: false, erro: 'Justificativa precisa ter pelo menos 15 caracteres (exigência da SEFAZ)' });
  if (!CERT_STATE.loaded) return res.status(400).json({ ok: false, erro: 'Certificado A1 não carregado' });

  try {
    const tpAmb      = AMBIENTE_ATUAL === 'producao' ? '1' : '2';
    const dhEvento    = dataHoraFiscal();
    const nSeqEvento  = '1';
    const idEvento    = `ID110111${chave}${nSeqEvento.padStart(2,'0')}`;
    const xJust       = justificativa.trim().replace(/&/g,'&amp;').replace(/</g,'&lt;').substring(0,255);

    // O Id fica no <infEvento> (não no <evento>) - é esse elemento que
    // é assinado, conforme o schema oficial do evento de cancelamento.
    let infEventoXml = `<evento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">`
      + `<infEvento Id="${idEvento}">`
      + `<cOrgao>${EMPRESA.cuf}</cOrgao>`
      + `<tpAmb>${tpAmb}</tpAmb>`
      + `<CNPJ>${EMPRESA.cnpj}</CNPJ>`
      + `<chNFe>${chave}</chNFe>`
      + `<dhEvento>${dhEvento}</dhEvento>`
      + `<tpEvento>110111</tpEvento>`
      + `<nSeqEvento>${nSeqEvento}</nSeqEvento>`
      + `<verEvento>1.00</verEvento>`
      + `<detEvento versao="1.00">`
      + `<descEvento>Cancelamento</descEvento>`
      + `<nProt>${nProt}</nProt>`
      + `<xJust>${xJust}</xJust>`
      + `</detEvento>`
      + `</infEvento>`
      + `</evento>`;

    const eventoAssinado = assinaarXML(infEventoXml, idEvento, 'infEvento');

    // envEvento também fica dentro do SOAP Body e não pode conter
    // declaração XML própria.
    const envEvento = `<envEvento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">`
      + `<idLote>${Date.now()}</idLote>`
      + eventoAssinado
      + `</envEvento>`;

    const respSEFAZ = await transmitirEventoSEFAZ(envEvento, tpAmb, modeloEvento);
    const resultado = parseEventoResp(respSEFAZ.xml);

    const xmlDir = PASTA_XML;

    // DEBUG TEMPORÁRIO: grava sempre a resposta crua da SEFAZ para o
    // evento (sucesso ou falha), para investigar casos em que o cStat
    // reportado não bate com o esperado. Pode remover depois.
    try {
      fs.writeFileSync(
        path.join(xmlDir, `_debug_resp_cancelamento_${chave}.xml`),
        '<!-- HTTP status: ' + respSEFAZ.http + ' -->\n' + respSEFAZ.xml
      );
    } catch (e) { console.warn('Falha ao gravar debug do cancelamento:', e.message); }

    if (resultado.homologado) {
      // Guarda o evento homologado ao lado da nota original - a nota
      // autorizada NUNCA é apagada, apenas fica marcada como cancelada
      // através deste arquivo de evento (é assim que a SEFAZ trata).
      fs.writeFileSync(path.join(xmlDir, `evento_cancelamento_${chave}.xml`), envEvento + '\n<!-- resposta SEFAZ: cStat ' + resultado.cStat + ' nProt ' + resultado.nProt + ' -->');
    }

    res.json({
      ok:        resultado.homologado,
      cStat:     resultado.cStat,
      xMotivo:   resultado.xMotivo,
      nProt:     resultado.nProt,
      chave,
      modelo:    modeloEvento,
      http:      respSEFAZ.http,
      url:       ENDPOINTS.evento[modeloEvento === '65' ? 'nfce' : 'nfe'][tpAmb],
      detalhe:   resultado.homologado ? undefined : _detalheDiagConexao(respSEFAZ),
      mensagem:  resultado.homologado
        ? 'Cancelamento homologado pela SEFAZ - a nota está oficialmente cancelada.'
        : 'SEFAZ recusou o cancelamento: ' + resultado.xMotivo + ' (cStat ' + resultado.cStat + '). Motivos comuns: prazo de cancelamento expirado, protocolo incorreto, ou nota já cancelada.',
    });

  } catch (err) {
    console.error('Erro cancelamento:', err.message);
    res.status(500).json({ ok: false, erro: err.message });
  }
});

// ============================================================
//  ROTA: CONSULTAR NOTA NA SEFAZ
// ============================================================

app.get('/api/nfe/consultar/:chave', async (req, res) => {
  const { chave } = req.params;
  const xmlLocal  = path.join(PASTA_XML, `nfe_${chave}.xml`);
  const xmlLocalN = path.join(PASTA_XML, `nfce_${chave}.xml`);

  res.json({
    ok:      true,
    chave,
    local:   fs.existsSync(xmlLocal) || fs.existsSync(xmlLocalN),
    mensagem: 'Para consulta em tempo real na SEFAZ, utilize o endpoint com transmissão direta',
  });
});

// ============================================================
//  CATÁLOGO + SINCRONIZAÇÃO CONTÍNUA DE XMLs
// ============================================================
function extrairCatalogoXml(nomeArquivo, arquivoPath, xml) {
  try {
    if(!/<infNFe[\s>]/.test(xml)) return null;
    const mod = campo(xml,'mod') || ((chaveDoXmlTexto(xml)||'').slice(20,22)) || (nomeArquivo.startsWith('nfce_')?'65':'55');
    const ide = bloco(xml,'ide');
    const dest = bloco(xml,'dest');
    const endDest = bloco(dest,'enderDest');
    const prot = bloco(xml,'protNFe');
    const chave = chaveDoXmlTexto(xml) || (nomeArquivo.match(/(\d{44})/)||[])[1] || '';
    const dhEmi = campo(ide,'dhEmi') || campo(ide,'dEmi');
    const nNF = campo(ide,'nNF') || (chave ? String(parseInt(chave.slice(25,34),10)||0) : '');
    const vNF = parseFloat(campo(bloco(bloco(xml,'total'),'ICMSTot'),'vNF')||campo(xml,'vNF')||0)||0;
    const cStat = campo(prot,'cStat');
    const nProt = campo(prot,'nProt') || campo(xml,'nProt');
    const autorizado = cStat==='100' || (!cStat && !nomeArquivo.includes('_REJEITADA') && /<protNFe[\s>]/.test(xml));
    const dt = dhEmi ? fmtDataHora(dhEmi) : {data:''};
    let missingSource=false;
    if(XML_SYNC.ativo && chave){
      const rels=Object.keys(XML_SYNC.arquivos||{}).filter(k=>XML_SYNC.arquivos[k]&&XML_SYNC.arquivos[k].chave===chave);
      missingSource = rels.length>0 && rels.every(k=>!XML_SYNC.arquivos[k].presente);
    }
    return {
      nomeArquivo:nomeArquivo, arquivo:arquivoPath, chave:chave, nNF:String(nNF||'').padStart(6,'0'), num:String(nNF||'').padStart(6,'0'),
      tipo:String(mod)==='65'?'NFC-e':'NF-e', dest:campo(dest,'xNome')||'Destinatário não identificado',
      destDoc:fmtDoc(campo(dest,'CNPJ')||campo(dest,'CPF')), val:vNF, dhEmi:dhEmi, emissaoIso:dhEmi,
      data:dt.data||'', status:autorizado?'Autorizada':(nomeArquivo.includes('_REJEITADA')?'Rejeitada':(missingSource?'Faltando':'Importada')),
      nProt:nProt||'', cStat:cStat||'', missingSource:missingSource, presenteInterno:true,
      tamanho: (()=>{try{return fs.statSync(arquivoPath).size}catch(e){return 0}})(), mtime: (()=>{try{return fs.statSync(arquivoPath).mtime}catch(e){return null}})()
    };
  } catch(e) { return null; }
}

function sincronizarPastaXml() {
  if(!XML_SYNC.ativo || !XML_SYNC.pasta) return {ok:true,ativo:false,novos:0,atualizados:0,excluidos:0};
  if(!fs.existsSync(XML_SYNC.pasta)) return {ok:false,erro:'A pasta monitorada não existe mais: '+XML_SYNC.pasta,novos:0,atualizados:0,excluidos:0};
  const encontrados=listarXmlRecursivo(XML_SYNC.pasta);
  const agora={}; let novos=0, atualizados=0, excluidos=0;
  for(const f of encontrados){
    const sig=hashArquivoXml(f.path); if(!sig) continue;
    const anterior=XML_SYNC.arquivos[f.rel];
    const mudou=!anterior || anterior.assinatura!==sig || !anterior.presente;
    let chave=anterior&&anterior.chave||'';
    if(mudou){
      let xml=''; try{xml=fs.readFileSync(f.path,'utf8');}catch(e){continue;}
      chave=chaveDoXmlTexto(xml);
      if(!chave){ XML_SYNC.arquivos[f.rel]={assinatura:sig,chave:'',presente:true,ultimoErro:'XML sem chave de 44 dígitos',atualizadoEm:new Date().toISOString()}; continue; }
      const extNome=(/65$/.test(chave.slice(20,22))?'nfce_':'nfe_')+chave+'.xml';
      const destino=path.join(PASTA_XML,extNome);
      try{
        // Nunca substitui uma nota autorizada existente por um arquivo
        // externo diferente com a mesma chave; mantém o primeiro arquivo
        // fiscal arquivado e registra a nova origem.
        if(!fs.existsSync(destino)) fs.copyFileSync(f.path,destino);
        else {
          const atual=fs.readFileSync(destino,'utf8');
          if(atual!==xml && !fs.existsSync(path.join(PASTA_XML,'importado_'+chave+'.xml'))) fs.copyFileSync(f.path,path.join(PASTA_XML,'importado_'+chave+'.xml'));
        }
        if(!anterior) { novos++; xmlSyncEvento('novo',f.rel,chave,'XML inserido automaticamente no arquivo interno.'); }
        else { atualizados++; xmlSyncEvento('alterado',f.rel,chave,'XML alterado; arquivo interno atualizado quando necessário.'); }
      }catch(e){ console.log('[!] Falha ao sincronizar XML',f.path,e.message); }
    }
    agora[f.rel]={assinatura:sig,chave:chave,presente:true,ultimoErro:'',atualizadoEm:new Date().toISOString()};
  }
  for(const rel of Object.keys(XML_SYNC.arquivos||{})){
    if(!agora[rel] && XML_SYNC.arquivos[rel].presente){
      const old=XML_SYNC.arquivos[rel]; excluidos++; agora[rel]=Object.assign({},old,{presente:false,excluidoEm:new Date().toISOString()}); xmlSyncEvento('excluido',rel,old.chave||'', 'Arquivo removido da pasta monitorada; cópia interna preservada para recuperação.');
    } else if(!agora[rel] && XML_SYNC.arquivos[rel]) agora[rel]=XML_SYNC.arquivos[rel];
  }
  XML_SYNC.arquivos=agora; salvarXmlSync();
  return {ok:true,ativo:true,pasta:XML_SYNC.pasta,novos,atualizados,excluidos,totalArquivos:encontrados.length};
}

app.get('/api/xml/catalogo', (req,res)=>{
  try{
    const arquivos=catalogoXmlInterno().sort((a,b)=>new Date(b.emissaoIso||b.mtime||0)-new Date(a.emissaoIso||a.mtime||0));
    res.json({ok:true,arquivos,total:arquivos.length,pasta:PASTA_XML});
  }catch(e){res.status(500).json({ok:false,erro:e.message});}
});

app.get('/api/xml/sync/status',(req,res)=>{
  const totalInternos=fs.existsSync(PASTA_XML)?fs.readdirSync(PASTA_XML).filter(f=>/\\.xml$/i.test(f)).length:0;
  res.json({ok:true,ativo:!!XML_SYNC.ativo,pasta:XML_SYNC.pasta||'',arquivos:XML_SYNC.arquivos||{},eventos:(XML_SYNC.eventos||[]).slice(-30),totalArquivos:Object.values(XML_SYNC.arquivos||{}).filter(x=>x&&x.presente).length,totalInternos});
});

app.post('/api/xml/sync/scan',(req,res)=>{
  try{res.json(sincronizarPastaXml());}catch(e){res.status(500).json({ok:false,erro:e.message});}
});

app.post('/api/xml/sync/escolher',(req,res)=>{
  const title='Selecionar pasta de XMLs para monitoramento';
  let command, args;
  if(os.platform()==='win32'){
    command='powershell'; args=['-NoProfile','-Command',"Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description='"+title.replace(/'/g,"''")+"'; if($d.ShowDialog() -eq 'OK'){Write-Output $d.SelectedPath}"];
  } else if(os.platform()==='darwin'){
    command='osascript'; args=['-e',`POSIX path of (choose folder with prompt "${title.replace(/"/g,'\\"')}")`];
  } else {
    command='zenity'; args=['--file-selection','--directory','--title='+title];
  }
  execFile(command,args,{timeout:120000,maxBuffer:1024*1024},(err,stdout,stderr)=>{
    const pasta=String(stdout||'').trim();
    if(err || !pasta){ return res.json({ok:false,cancelado:!pasta,erro:err && err.code==='ENOENT'?'O seletor de pastas requer o Zenity no Linux. Instale-o com: sudo apt install zenity':(stderr||'Seleção cancelada.')}); }
    if(!fs.existsSync(pasta) || !fs.statSync(pasta).isDirectory()) return res.json({ok:false,erro:'O caminho selecionado não é uma pasta válida.'});
    XML_SYNC.ativo=true; XML_SYNC.pasta=path.resolve(pasta); XML_SYNC.arquivos={}; salvarXmlSync();
    const r=sincronizarPastaXml(); res.json(Object.assign({ok:true,pasta:XML_SYNC.pasta},r));
  });
});

app.post('/api/xml/sync/configurar',(req,res)=>{
  try{
    const pasta=String(req.body&&req.body.pasta||'').trim();
    if(!pasta) return res.status(400).json({ok:false,erro:'Informe o caminho da pasta de XMLs.'});
    const alvo=path.resolve(pasta);
    if(!fs.existsSync(alvo) || !fs.statSync(alvo).isDirectory()) return res.status(400).json({ok:false,erro:'A pasta informada não existe ou não é uma pasta.'});
    XML_SYNC.ativo=true; XML_SYNC.pasta=alvo; XML_SYNC.arquivos={}; salvarXmlSync();
    res.json(Object.assign({ok:true,pasta:alvo},sincronizarPastaXml()));
  }catch(e){res.status(500).json({ok:false,erro:e.message});}
});

app.post('/api/xml/sync/desativar',(req,res)=>{XML_SYNC.ativo=false; salvarXmlSync(); res.json({ok:true});});

app.post('/api/xml/sync/recuperar',(req,res)=>{
  try{
    const chave=String(req.body&&req.body.chave||'').replace(/\D/g,'');
    if(!/^\d{44}$/.test(chave)) return res.status(400).json({ok:false,erro:'Chave de acesso inválida.'});
    if(!XML_SYNC.ativo||!XML_SYNC.pasta) return res.status(400).json({ok:false,erro:'Nenhuma pasta monitorada está configurada.'});
    if(!fs.existsSync(XML_SYNC.pasta)) return res.status(400).json({ok:false,erro:'A pasta monitorada não existe mais.'});
    const origem=encontrarArquivoPorChave(chave); if(!origem) return res.status(404).json({ok:false,erro:'Cópia interna do XML não encontrada.'});
    const nome=/65$/.test(chave.slice(20,22))?'nfce_'+chave+'.xml':'nfe_'+chave+'.xml';
    const destino=path.join(XML_SYNC.pasta,nome); if(fs.existsSync(destino)) return res.json({ok:true,arquivo:destino,jaExistia:true});
    fs.copyFileSync(origem,destino); sincronizarPastaXml(); res.json({ok:true,arquivo:destino,jaExistia:false});
  }catch(e){res.status(500).json({ok:false,erro:e.message});}
});

// ============================================================
//  ROTA: LISTAR XMLs LOCAIS
// ============================================================

app.get('/api/xml/listar', (req, res) => {
  const arquivos = catalogoXmlInterno().sort((a,b)=>new Date(b.emissaoIso||b.mtime||0)-new Date(a.emissaoIso||a.mtime||0));
  res.json({ ok: true, arquivos, total: arquivos.length, pasta: PASTA_XML });
});

// Baixar o XML de uma nota pela chave de 44 dígitos (mais prático que
// saber o nome exato do arquivo). Procura nfe_/nfce_, autorizada ou
// rejeitada, e devolve a que existir.
function encontrarArquivoPorChave(chave) {
  const xmlDir = PASTA_XML;
  if (!fs.existsSync(xmlDir)) return null;
  const candidatos = [
    `nfe_${chave}.xml`, `nfce_${chave}.xml`,
    `nfe_${chave}_REJEITADA.xml`, `nfce_${chave}_REJEITADA.xml`,
    `importado_${chave}.xml`,
  ];
  for (const nome of candidatos) {
    const p = path.join(xmlDir, nome);
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// ============================================================
//  ROTA: IMPORTAR XML AVULSO (gerado em qualquer outro sistema)
//  Só grava uma cópia em disco pra ficar junto dos demais XMLs -
//  não reprocessa nem retransmite nada pra SEFAZ. A validação e
//  extração dos dados já acontece no front antes de chamar aqui.
// ============================================================
app.post('/api/xml/importar', (req, res) => {
  try {
    const { xml, chave, nomeArquivo } = req.body || {};
    if (!xml || typeof xml !== 'string' || !xml.includes('infNFe')) {
      return res.status(400).json({ ok: false, erro: 'XML inválido ou vazio' });
    }
    const chaveSegura = /^\d{44}$/.test(chave || '') ? chave : ('sem_chave_' + Date.now());
    const nomeSeguro = 'importado_' + chaveSegura + '.xml';
    fs.writeFileSync(path.join(PASTA_XML, nomeSeguro), xml);
    res.json({ ok: true, arquivo: nomeSeguro });
  } catch (err) {
    res.status(500).json({ ok: false, erro: err.message });
  }
});

app.get('/api/xml/porchave/:chave', (req, res) => {
  const file = encontrarArquivoPorChave(req.params.chave);
  if (!file) return res.status(404).json({ ok: false, erro: 'XML não encontrado para essa chave' });
  res.setHeader('Content-Type', 'application/xml');
  res.setHeader('Content-Disposition', `attachment; filename="${path.basename(file)}"`);
  res.send(fs.readFileSync(file, 'utf8'));
});

// ============================================================
//  ROTA: PASTA DOS XMLs (caminho + abrir no explorador de arquivos)
// ============================================================

app.get('/api/xml/pasta', (req, res) => {
  res.json({ ok: true, pasta: PASTA_DADOS, subpastas: { xml: PASTA_XML, danfePdf: PASTA_DANFE_PDF, backups: PASTA_BACKUPS } });
});

// Abre a pasta no explorador de arquivos do sistema operacional.
// Só funciona porque o backend roda na própria máquina do usuário
// (servidor escuta em 127.0.0.1) - é um atalho de conveniência local,
// não uma ação remota. Abre backend/dados/ (mostra xml/, danfe-pdf/ e
// backups/ juntas).
app.post('/api/xml/abrir-pasta', (req, res) => {
  const alvo = PASTA_DADOS;
  const plataforma = os.platform();
  const cmd = plataforma === 'win32' ? `explorer "${alvo}"`
            : plataforma === 'darwin' ? `open "${alvo}"`
            : `xdg-open "${alvo}"`;
  exec(cmd, (err) => {
    if (err) return res.status(500).json({ ok: false, erro: 'Não foi possível abrir a pasta automaticamente. Caminho: ' + alvo });
    res.json({ ok: true, pasta: alvo });
  });
});

// ============================================================
//  ROTA: EXPORTAR TODOS OS XMLs EM UM ZIP
// ============================================================

app.get('/api/xml/zip', (req, res) => {
  const xmlDir = PASTA_XML;
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="xmls_${Date.now()}.zip"`);
  const arquivo = archiver('zip', { zlib: { level: 9 } });
  arquivo.on('error', (err) => { res.status(500).end('Erro ao gerar ZIP: ' + err.message); });
  arquivo.pipe(res);
  arquivo.directory(xmlDir, false);
  arquivo.finalize();
});

// IMPORTANTE: esta rota curinga (/api/xml/:qualquer-coisa) precisa vir
// DEPOIS de todas as rotas específicas acima (pasta, zip, listar,
// porchave) - senão o Express casa "pasta" ou "zip" como se fossem
// nome de arquivo, e as rotas específicas nunca são alcançadas. Esse
// era exatamente o bug que fez /api/xml/pasta parar de funcionar.
app.get('/api/xml/:arquivo', (req, res) => {
  // path.basename evita path traversal (ex: ../../server.js)
  const nomeSeguro = path.basename(req.params.arquivo);
  const file = path.join(PASTA_XML, nomeSeguro);
  if (!fs.existsSync(file)) return res.status(404).json({ ok: false, erro: 'Arquivo não encontrado' });
  res.setHeader('Content-Type', 'application/xml');
  res.setHeader('Content-Disposition', `attachment; filename="${nomeSeguro}"`);
  res.send(fs.readFileSync(file, 'utf8'));
});

// ============================================================
//  ROTA: BACKUP COMPLETO (pasta própria, separada dos XMLs)
// ============================================================
// Gera um .zip com XMLs + DANFEs em PDF já geradas + numeração +
// ambiente, e SALVA em backend/dados/backups/ (não fica misturado
// com os XMLs correntes) - além de te devolver pra baixar na hora.

// ============================================================
//  ROTA: Estado completo do ERP (clientes, produtos, financeiro,
//  vendas, estoque, fornecedores, compras, ativo fixo...)
//
//  Isso é o que resolve o risco de perder tudo se o navegador for
//  limpo: o ERP manda o estado inteiro pra cá a cada mudança (com
//  debounce, no lado do navegador), e recarrega DAQUI na próxima vez
//  que abrir — o navegador vira só um cache rápido, não é mais o
//  único lugar onde os dados existem.
// ============================================================
const ESTADO_FILE        = path.join(PASTA_DADOS, 'estado_erp.json');
const ESTADO_VERSOES_DIR = path.join(PASTA_DADOS, 'estado-versoes');
fs.mkdirSync(ESTADO_VERSOES_DIR, { recursive: true });

app.get('/api/estado', (req, res) => {
  try {
    if (!fs.existsSync(ESTADO_FILE)) return res.json({ ok: true, estado: null });
    const raw = fs.readFileSync(ESTADO_FILE, 'utf8');
    res.json({ ok: true, estado: JSON.parse(raw) });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  }
});

app.post('/api/estado', (req, res) => {
  try {
    const corpo = req.body || {};
    // Escrita atômica: grava num arquivo temporário e só troca pelo
    // definitivo depois de gravado por completo (rename é atômico no
    // sistema de arquivos) — se o processo cair no meio do caminho,
    // o arquivo anterior continua íntegro, nunca fica pela metade.
    const tmp = ESTADO_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(corpo), { mode: 0o600 });
    fs.renameSync(tmp, ESTADO_FILE);

    // Guarda uma versão rotativa (últimas 10) como seguro extra — se
    // por qualquer motivo o arquivo principal se corromper, dá pra
    // voltar pra uma versão recente em vez de perder tudo.
    const nomeVersao = 'estado_' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
    fs.writeFileSync(path.join(ESTADO_VERSOES_DIR, nomeVersao), JSON.stringify(corpo), { mode: 0o600 });
    const versoes = fs.readdirSync(ESTADO_VERSOES_DIR).filter(f => f.endsWith('.json')).sort();
    while (versoes.length > 10) fs.unlinkSync(path.join(ESTADO_VERSOES_DIR, versoes.shift()));

    res.json({ ok: true, tamanho: JSON.stringify(corpo).length });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  }
});

app.get('/api/estado/versoes', (req, res) => {
  if (!fs.existsSync(ESTADO_VERSOES_DIR)) return res.json({ ok: true, versoes: [] });
  const versoes = fs.readdirSync(ESTADO_VERSOES_DIR)
    .filter(f => f.endsWith('.json'))
    .map(f => { const st = fs.statSync(path.join(ESTADO_VERSOES_DIR, f)); return { arquivo: f, tamanho: st.size, data: st.mtime }; })
    .sort((a, b) => b.data - a.data);
  res.json({ ok: true, versoes });
});

app.post('/api/estado/restaurar-versao', (req, res) => {
  try {
    const nomeSeguro = path.basename(req.body.arquivo || '');
    const origem = path.join(ESTADO_VERSOES_DIR, nomeSeguro);
    if (!fs.existsSync(origem)) return res.status(404).json({ ok: false, erro: 'Versão não encontrada' });
    fs.copyFileSync(origem, ESTADO_FILE);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  }
});

app.post('/api/backup/gerar', (req, res) => {
  const agora = new Date();
  const nomeArq = `backup_${agora.toISOString().replace(/[:.]/g,'-')}.zip`;
  const destino = path.join(PASTA_BACKUPS, nomeArq);

  const out = fs.createWriteStream(destino);
  const arquivo = archiver('zip', { zlib: { level: 9 } });

  out.on('close', () => {
    res.json({ ok: true, arquivo: nomeArq, tamanho: arquivo.pointer(), pasta: PASTA_BACKUPS });
  });
  arquivo.on('error', (err) => res.status(500).json({ ok: false, erro: err.message }));

  arquivo.pipe(out);
  if (fs.existsSync(PASTA_XML))       arquivo.directory(PASTA_XML, 'xml');
  if (fs.existsSync(PASTA_DANFE_PDF)) arquivo.directory(PASTA_DANFE_PDF, 'danfe-pdf');
  if (fs.existsSync(NUM_FILE))        arquivo.file(NUM_FILE, { name: 'numeracao.json' });
  if (fs.existsSync(AMBIENTE_FILE))   arquivo.file(AMBIENTE_FILE, { name: 'ambiente.json' });
  if (fs.existsSync(ESTADO_FILE))     arquivo.file(ESTADO_FILE, { name: 'estado_erp.json' });
  arquivo.finalize();
});

app.get('/api/backup/listar', (req, res) => {
  if (!fs.existsSync(PASTA_BACKUPS)) return res.json({ ok: true, arquivos: [], pasta: PASTA_BACKUPS });
  const arquivos = fs.readdirSync(PASTA_BACKUPS)
    .filter(f => f.endsWith('.zip'))
    .map(f => { const st = fs.statSync(path.join(PASTA_BACKUPS, f)); return { arquivo: f, tamanho: st.size, data: st.mtime }; })
    .sort((a,b) => b.data - a.data);
  res.json({ ok: true, arquivos, pasta: PASTA_BACKUPS });
});

app.get('/api/backup/baixar/:arquivo', (req, res) => {
  const nomeSeguro = path.basename(req.params.arquivo);
  const file = path.join(PASTA_BACKUPS, nomeSeguro);
  if (!fs.existsSync(file)) return res.status(404).json({ ok: false, erro: 'Backup não encontrado' });
  res.download(file, nomeSeguro);
});

app.post('/api/backup/abrir-pasta', (req, res) => {
  const plataforma = os.platform();
  const cmd = plataforma === 'win32' ? `explorer "${PASTA_BACKUPS}"`
            : plataforma === 'darwin' ? `open "${PASTA_BACKUPS}"`
            : `xdg-open "${PASTA_BACKUPS}"`;
  exec(cmd, (err) => {
    if (err) return res.status(500).json({ ok: false, erro: 'Não foi possível abrir. Caminho: ' + PASTA_BACKUPS });
    res.json({ ok: true, pasta: PASTA_BACKUPS });
  });
});

// ============================================================
//  ROTA: DANFE (visualização online, formato imprimível)
// ============================================================
// Renderiza uma página HTML com o essencial de uma DANFE a partir do
// XML salvo (chave, emitente, destinatário, itens, totais, protocolo).
// Não é o layout oficial pixel-a-pixel do Manual de Orientação da
// DANFE, mas traz os campos obrigatórios e pode ser impressa/salva em
// PDF pelo próprio navegador (Ctrl+P -> Salvar como PDF).

function campo(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}>([^<]*)</${tag}>`));
  return m ? m[1] : '';
}

function bloco(xml, tag) {
  const m = xml.match(new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)</' + tag + '>'));
  return m ? m[1] : '';
}

function fmtNum(v, d) { const n = parseFloat(v || 0); return n.toLocaleString('pt-BR', { minimumFractionDigits: d === undefined ? 2 : d, maximumFractionDigits: d === undefined ? 2 : d }); }
function fmtDoc(v) {
  const d = String(v || '').replace(/\D/g, '');
  if (d.length === 14) return d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
  if (d.length === 11) return d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');
  return d;
}
function fmtCep(v) { const d = String(v || '').replace(/\D/g, ''); return d.length === 8 ? d.replace(/^(\d{5})(\d{3})$/, '$1-$2') : d; }
// Formata o número da NF-e com zeros à esquerda no padrão usado pela
// maioria dos sistemas de emissão (000.000.035) - só para EXIBIÇÃO na
// DANFE. O <nNF> dentro do XML continua sem zeros à esquerda, como o
// schema da NF-e exige (senão a nota é rejeitada pela SEFAZ).
function fmtNNF(v) {
  const n = String(parseInt(v, 10) || 0).padStart(9, '0');
  return n.replace(/^(\d{3})(\d{3})(\d{3})$/, '$1.$2.$3');
}
function fmtFone(v) {
  const d = String(v || '').replace(/\D/g, '');
  if (d.length === 11) return d.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
  if (d.length === 10) return d.replace(/^(\d{2})(\d{4})(\d{4})$/, '($1) $2-$3');
  return d;
}
function fmtDataHora(dh) {
  if (!dh) return { data: '', hora: '' };
  const m = String(dh).match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/);
  if (!m) return { data: String(dh), hora: '' };
  return { data: `${m[3]}/${m[2]}/${m[1]}`, hora: `${m[4]}:${m[5]}:${m[6]}` };
}
function chaveFormatada(chave) { return String(chave).replace(/(\d{4})(?=\d)/g, '$1 ').trim(); }

// Barras Code128-C da chave de acesso (44 digitos), desenhadas em SVG puro.
// A DANFE oficial usa exatamente Code128-C para a chave.
const C128_PAD = ['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'];
function code128cSvg(digitos, larguraPx, alturaPx) {
  const d = String(digitos).replace(/\D/g, '');
  const pares = [];
  const src = d.length % 2 ? d + '0' : d;
  for (let i = 0; i < src.length; i += 2) pares.push(parseInt(src.substr(i, 2), 10));
  let codes = [105].concat(pares); // 105 = START C
  let soma = 105;
  pares.forEach((v, i) => { soma += v * (i + 1); });
  codes.push(soma % 103);
  codes.push(106); // STOP
  let padrao = '';
  codes.forEach(c => { padrao += C128_PAD[c] || '212222'; });
  const totalModulos = padrao.split('').reduce((a, b) => a + parseInt(b, 10), 0);
  const mod = larguraPx / totalModulos;
  let x = 0, barras = '', preto = true;
  padrao.split('').forEach(ch => {
    const w = parseInt(ch, 10) * mod;
    if (preto) barras += `<rect x="${x.toFixed(2)}" y="0" width="${w.toFixed(2)}" height="${alturaPx}" fill="#000"/>`;
    x += w; preto = !preto;
  });
  return `<svg width="${larguraPx}" height="${alturaPx}" viewBox="0 0 ${larguraPx} ${alturaPx}" xmlns="http://www.w3.org/2000/svg">${barras}</svg>`;
}

app.get('/danfe/:chave', (req, res) => {
  const chave = String(req.params.chave || '').replace(/\D/g, '');
  const file  = encontrarArquivoPorChave(chave);
  if (!file) return res.status(404).send('<h2>Nota nao encontrada para a chave informada.</h2>');

  const xml = fs.readFileSync(file, 'utf8');
  const rejeitada = file.includes('_REJEITADA');
  // Descobre NF-e x NFC-e pela própria tag <mod> do XML (55/65), não só
  // pelo nome do arquivo — XMLs importados de outros sistemas usam o
  // prefixo "importado_", então dependeria do conteúdo mesmo.
  const modXml583 = (xml.match(/<mod>(\d+)<\/mod>/) || [])[1];
  const isNFCe = modXml583 ? modXml583 === '65' : path.basename(file).startsWith('nfce_');

  const ide     = bloco(xml, 'ide');
  const emitX   = bloco(xml, 'emit');
  const enderE  = bloco(emitX, 'enderEmit');
  const destX   = bloco(xml, 'dest');
  const enderD  = bloco(destX, 'enderDest');
  const totX    = bloco(bloco(xml, 'total'), 'ICMSTot');
  const transpX = bloco(xml, 'transp');
  const pagX    = bloco(xml, 'pag');
  const infAdX  = bloco(xml, 'infAdic');

  const nNF   = campo(ide, 'nNF');
  const serie = campo(ide, 'serie');
  const natOp = campo(ide, 'natOp');
  const tpNF  = campo(ide, 'tpNF') === '0' ? 'ENTRADA' : 'SAIDA';
  const emi   = fmtDataHora(campo(ide, 'dhEmi'));
  const said  = fmtDataHora(campo(ide, 'dhSaiEnt') || campo(ide, 'dhEmi'));
  const tpAmbNota = campo(ide, 'tpAmb');

  const nProt    = campo(xml, 'nProt');
  const dhRecbto = fmtDataHora(campo(xml, 'dhRecbto'));

  const emitCnpjRaw = campo(emitX, 'CNPJ').replace(/\D/g,'');
  const emitEhAguaMister = emitCnpjRaw && emitCnpjRaw === String(EMPRESA.cnpj||'').replace(/\D/g,'');
  const emit = {
    nome: campo(emitX, 'xNome') || EMPRESA.nome,
    fant: campo(emitX, 'xFant'),
    cnpj: fmtDoc(campo(emitX, 'CNPJ')),
    ie:   campo(emitX, 'IE'),
    lgr:  emitEhAguaMister ? EMPRESA.logradouro : campo(enderE, 'xLgr'),
    nro:  emitEhAguaMister ? EMPRESA.numero : campo(enderE, 'nro'),
    cpl:  emitEhAguaMister ? EMPRESA.complemento : campo(enderE, 'xCpl'),
    bairro: emitEhAguaMister ? EMPRESA.bairro : campo(enderE, 'xBairro'),
    mun: emitEhAguaMister ? EMPRESA.municipio : campo(enderE, 'xMun'),
    uf: emitEhAguaMister ? EMPRESA.uf : campo(enderE, 'UF'),
    cep: emitEhAguaMister ? fmtCep(EMPRESA.cep) : fmtCep(campo(enderE, 'CEP')),
    fone: emitEhAguaMister ? fmtFone(EMPRESA.fone) : fmtFone(campo(enderE, 'fone')),
  };
  const dest = {
    nome: campo(destX, 'xNome') || 'CONSUMIDOR NAO IDENTIFICADO',
    doc:  fmtDoc(campo(destX, 'CNPJ') || campo(destX, 'CPF')),
    ie:   campo(destX, 'IE'),
    lgr:  campo(enderD, 'xLgr'), nro: campo(enderD, 'nro'),
    bairro: campo(enderD, 'xBairro'), mun: campo(enderD, 'xMun'),
    uf: campo(enderD, 'UF'), cep: fmtCep(campo(enderD, 'CEP')),
    fone: fmtFone(campo(enderD, 'fone')),
  };

  const tot = {
    vBC: campo(totX, 'vBC'), vICMS: campo(totX, 'vICMS'), vBCST: campo(totX, 'vBCST'),
    vST: campo(totX, 'vST'), vProd: campo(totX, 'vProd'), vFrete: campo(totX, 'vFrete'),
    vSeg: campo(totX, 'vSeg'), vDesc: campo(totX, 'vDesc'), vII: campo(totX, 'vII'),
    vIPI: campo(totX, 'vIPI'), vPIS: campo(totX, 'vPIS'), vCOFINS: campo(totX, 'vCOFINS'),
    vOutro: campo(totX, 'vOutro'), vNF: campo(totX, 'vNF'),
  };

  const modFrete = campo(transpX, 'modFrete');
  const freteTxt = { '0': '0-EMITENTE', '1': '1-DESTINATARIO', '2': '2-TERCEIROS', '3': '3-PROPRIO/REM', '4': '4-PROPRIO/DEST', '9': '9-SEM FRETE' }[modFrete] || '9-SEM FRETE';

  const itens = [...xml.matchAll(/<det nItem="(\d+)">([\s\S]*?)<\/det>/g)].map(([_, nItem, det]) => {
    const prod = bloco(det, 'prod');
    const icmsBloco = bloco(det, 'ICMS');
    return {
      nItem,
      cProd: campo(prod, 'cProd'), xProd: campo(prod, 'xProd'),
      ncm: campo(prod, 'NCM'), cfop: campo(prod, 'CFOP'), uCom: campo(prod, 'uCom'),
      qCom: campo(prod, 'qCom'), vUnCom: campo(prod, 'vUnCom'), vProd: campo(prod, 'vProd'),
      cst: (campo(icmsBloco, 'CSOSN') || ((campo(icmsBloco, 'orig') || '0') + (campo(icmsBloco, 'CST') || '')))
             || campo(icmsBloco, 'CST'),
      vBC: campo(icmsBloco, 'vBC') || '0.00',
      vICMS: campo(icmsBloco, 'vICMS') || '0.00',
      pICMS: campo(icmsBloco, 'pICMS') || '0.00',
    };
  });

  const linhasItens = itens.map(it => `<tr>
      <td class="c">${it.cProd}</td>
      <td>${it.xProd}</td>
      <td class="c">${it.ncm}</td>
      <td class="c">${it.cst}</td>
      <td class="c">${it.cfop}</td>
      <td class="c">${it.uCom}</td>
      <td class="r">${fmtNum(it.qCom, 3)}</td>
      <td class="r">${fmtNum(it.vUnCom)}</td>
      <td class="r">${fmtNum(it.vProd)}</td>
      <td class="r">${fmtNum(it.vBC)}</td>
      <td class="r">${fmtNum(it.vICMS)}</td>
      <td class="r">${fmtNum(it.pICMS, 2)}</td>
    </tr>`).join('');

  const infCpl = campo(infAdX, 'infCpl');

  // FATURA / DUPLICATA — datas de vencimento (grupo cobr/dup do XML).
  // A DANFE em papel usa esta faixa "Número / Valor / Vencimento" logo
  // abaixo do cabeçalho; sem ela a nota fica sem informar o vencimento.
  const cobrX = bloco(xml, 'cobr');
  const duplicatas = [...cobrX.matchAll(/<dup>([\s\S]*?)<\/dup>/g)].map(([_, dupBloco]) => ({
    nDup:  campo(dupBloco, 'nDup'),
    dVenc: fmtDataHora(campo(dupBloco, 'dVenc') + 'T00:00:00').data,
    vDup:  campo(dupBloco, 'vDup'),
  }));
  // Com muitas parcelas (6, 8, 12...) tudo numa linha só espreme as
  // colunas até ficar ilegível. Quebra em linhas de até 4 parcelas
  // (12 células) cada, do jeito que qualquer DANFE de papel faz.
  const PARCELAS_POR_LINHA = 4;
  const linhasDuplicata = [];
  for (let i = 0; i < duplicatas.length; i += PARCELAS_POR_LINHA) linhasDuplicata.push(duplicatas.slice(i, i + PARCELAS_POR_LINHA));
  const celulasDuplicata = linhasDuplicata.map(linha => `<div class="g">${linha.map(d => `
    <div class="cel" style="flex:1"><span class="lbl">Número</span><div class="val">${d.nDup}</div></div>
    <div class="cel" style="flex:1"><span class="lbl">Valor</span><div class="val">${fmtNum(d.vDup)}</div></div>
    <div class="cel" style="flex:1"><span class="lbl">Vencimento</span><div class="val">${d.dVenc}</div></div>`).join('')}</div>`).join('');
  const blocoDuplicatas = `
  <div class="tit">Fatura</div>
  ${duplicatas.length ? celulasDuplicata : `<div class="g">
    <div class="cel" style="flex:1"><span class="lbl">Número</span><div class="val">${nNF}</div></div>
    <div class="cel" style="flex:1"><span class="lbl">Valor</span><div class="val">${fmtNum(tot ? tot.vNF : '')}</div></div>
    <div class="cel" style="flex:1"><span class="lbl">Vencimento</span><div class="val">${said.data}</div></div></div>`}`;

  const logoDataUrl = obterLogoDataUrl();
  const barcode = code128cSvg(chave, 480, 46);
  const urlConsulta = isNFCe
    ? 'https://www.nfce.fazenda.sp.gov.br/consulta'
    : 'https://www.nfe.fazenda.gov.br/portal/consulta.aspx';

  const avisoAmb = tpAmbNota === '2'
    ? '<div class="tarja">EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL</div>' : '';

  res.send(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<title>DANFE ${nNF} - ${chave}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:Arial,Helvetica,sans-serif;font-size:8.5pt;color:#000;background:#eee;margin:0;padding:10px}
  .folha{width:210mm;min-height:297mm;margin:0 auto;background:#fff;padding:6mm;display:flex;flex-direction:column;}
  .dados-adic{flex:1 1 auto;display:flex;flex-direction:column;margin-top:14px}
  .dados-adic .g{flex:1 1 auto}
  .dados-adic .cel{display:flex;flex-direction:column}
  .dados-adic .cel > div:last-child{flex:1}
  .b{border:1px solid #000}
  .lbl{font-size:5.5pt;text-transform:uppercase;letter-spacing:.2px;display:block;line-height:1.1}
  .val{font-size:8.5pt;font-weight:bold;line-height:1.2;min-height:11px}
  .cel{border:1px solid #000;padding:2px 3px;overflow:hidden}
  .g{display:flex}
  .g>.cel{flex:1}
  .tit{text-align:center;font-size:7pt;font-weight:bold;text-transform:uppercase;border:1px solid #000;border-bottom:none;padding:1px}
  .c{text-align:center}.r{text-align:right}
  table.itens{width:100%;border-collapse:collapse;font-size:6.5pt}
  table.itens th{border:1px solid #000;padding:2px 1px;font-size:5.5pt;text-transform:uppercase;background:#fff}
  table.itens td{border:1px solid #000;padding:2px 1px;font-size:7pt}
  .chavebox{text-align:center}
  .chave{font-family:"Courier New",monospace;font-size:7.6pt;font-weight:bold;letter-spacing:.15px;white-space:nowrap}
  .danfe-mid{text-align:center;line-height:1.15}
  .emit-head{display:flex;align-items:center;gap:6px;min-height:72px}
  .emit-logo{width:54px;max-width:54px;max-height:54px;object-fit:contain;flex:0 0 54px}
  .emit-info{min-width:0;flex:1}
  .danfe-mid .dz{font-size:15pt;font-weight:bold;letter-spacing:1px}
  .recibo{display:flex;border:1px solid #000;margin-bottom:2px}
  .tarja{border:2px solid #000;text-align:center;font-weight:bold;padding:4px;margin-bottom:4px;font-size:10pt}
  .rej{border:2px solid #b00;color:#b00;text-align:center;font-weight:bold;padding:4px;margin-bottom:4px}
  .tracejado{border-top:1px dashed #000;margin:4px 0}
  .barra{max-width:210mm;margin:0 auto 8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  .barra button,.barra a{font-size:11px;padding:6px 10px;border-radius:5px;border:1px solid #999;background:#fff;color:#111;text-decoration:none;cursor:pointer}
  @media print{ .noprint{display:none} body{background:#fff;padding:0} .folha{width:auto;padding:0;min-height:283mm} img,.emit-logo{-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact} }
  @page{ size:A4; margin:6mm }
</style></head><body>
<div class="barra noprint">
  <button onclick="window.print()">Imprimir / Salvar PDF</button>
  <a href="/danfe/${chave}/pdf" target="_blank">PDF do servidor</a>
  <a href="/api/xml/porchave/${chave}">Baixar XML</a>
  <a href="${urlConsulta}" target="_blank">Consultar na SEFAZ</a>
</div>
<div class="folha">
${rejeitada ? '<div class="rej">NOTA NAO AUTORIZADA PELA SEFAZ - XML assinado e recusado na transmissao. Sem validade fiscal.</div>' : ''}
${avisoAmb}

  <!-- CABECALHO -->
  <div class="g">
    <div class="cel" style="flex:3;min-width:0">
      <div class="emit-head">
        ${logoDataUrl ? `<img class="emit-logo" src="${logoDataUrl}" alt="Logo Água Mister" width="54" height="54">` : ''}
        <div class="emit-info">
          <div class="val" style="font-size:8.5pt;line-height:1.05">${emit.nome}</div>
          <div style="font-size:6.5pt;line-height:1.2;margin-top:3px">
            ${emit.lgr}, ${emit.nro}${emit.cpl ? ' '+emit.cpl : ''}<br>
            ${emit.bairro} - ${emit.mun}/${emit.uf} - CEP ${emit.cep}<br>
            ${emit.fone ? 'Fone: ' + emit.fone : ''}
          </div>
        </div>
      </div>
    </div>
    <div class="cel danfe-mid" style="flex:1.5;min-width:0">
      <div class="dz">DANFE</div>
      <div style="font-size:6pt">Documento Auxiliar da<br>Nota Fiscal Eletronica</div>
      <div style="font-size:5.8pt;margin:3px 0">0 - ENTRADA&nbsp;&nbsp;1 - SAIDA</div>
      <div class="val" style="font-size:7pt">${tpNF === 'SAIDA' ? '1' : '0'} - ${tpNF}</div>
      <div class="val" style="font-size:6.8pt">N&ordm; ${fmtNNF(nNF)} &nbsp; SERIE ${serie}<br>FOLHA 1/1</div>
    </div>
    <div class="cel chavebox" style="flex:4.5;min-width:0">
      ${barcode}
      <div style="font-size:5.5pt;text-transform:uppercase">Chave de acesso</div>
      <div class="chave">${chaveFormatada(chave)}</div>
      <div style="font-size:6.2pt;margin-top:2px">Consulta de autenticidade no portal nacional da NF-e<br>www.nfe.fazenda.gov.br/portal ou no site da Sefaz autorizadora</div>
    </div>
  </div>
  <div class="g">
    <div class="cel" style="flex:2"><span class="lbl">Natureza da operacao</span><div class="val">${natOp}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Protocolo de autorizacao de uso</span><div class="val">${nProt ? nProt + (dhRecbto.data ? ' - ' + dhRecbto.data + ' ' + dhRecbto.hora : '') : (rejeitada ? 'NAO AUTORIZADA' : '')}</div></div>
  </div>
  <div class="g">
    <div class="cel"><span class="lbl">Inscricao estadual</span><div class="val">${emit.ie}</div></div>
    <div class="cel"><span class="lbl">Inscr. estadual do subst. tributario</span><div class="val">&nbsp;</div></div>
    <div class="cel"><span class="lbl">CNPJ</span><div class="val">${emit.cnpj}</div></div>
  </div>

  <!-- DESTINATARIO -->
  <div class="tit">Destinatario / Remetente</div>
  <div class="g">
    <div class="cel" style="flex:5"><span class="lbl">Nome / Razao social</span><div class="val">${dest.nome}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">CNPJ / CPF</span><div class="val">${dest.doc || '-'}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Data de emissao</span><div class="val">${emi.data}</div></div>
  </div>
  <div class="g">
    <div class="cel" style="flex:4"><span class="lbl">Endereco</span><div class="val">${dest.lgr ? dest.lgr + ', ' + dest.nro : '-'}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Bairro / Distrito</span><div class="val">${dest.bairro || '-'}</div></div>
    <div class="cel" style="flex:1"><span class="lbl">CEP</span><div class="val">${dest.cep || '-'}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Data de saida / entrada</span><div class="val">${said.data}</div></div>
  </div>
  <div class="g">
    <div class="cel" style="flex:3"><span class="lbl">Municipio</span><div class="val">${dest.mun || '-'}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Fone / Fax</span><div class="val">${dest.fone || '-'}</div></div>
    <div class="cel" style="flex:1"><span class="lbl">UF</span><div class="val">${dest.uf || '-'}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Inscricao estadual</span><div class="val">${dest.ie || '-'}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Hora de saida</span><div class="val">${said.hora}</div></div>
  </div>
  ${blocoDuplicatas}

  <!-- IMPOSTOS -->
  <div class="tit">Calculo do imposto</div>
  <div class="g">
    <div class="cel"><span class="lbl">Base de calculo do ICMS</span><div class="val r">${fmtNum(tot.vBC)}</div></div>
    <div class="cel"><span class="lbl">Valor do ICMS</span><div class="val r">${fmtNum(tot.vICMS)}</div></div>
    <div class="cel"><span class="lbl">Base de calc. ICMS ST</span><div class="val r">${fmtNum(tot.vBCST)}</div></div>
    <div class="cel"><span class="lbl">Valor do ICMS ST</span><div class="val r">${fmtNum(tot.vST)}</div></div>
    <div class="cel"><span class="lbl">Valor total dos produtos</span><div class="val r">${fmtNum(tot.vProd)}</div></div>
  </div>
  <div class="g">
    <div class="cel"><span class="lbl">Valor do frete</span><div class="val r">${fmtNum(tot.vFrete)}</div></div>
    <div class="cel"><span class="lbl">Valor do seguro</span><div class="val r">${fmtNum(tot.vSeg)}</div></div>
    <div class="cel"><span class="lbl">Desconto</span><div class="val r">${fmtNum(tot.vDesc)}</div></div>
    <div class="cel"><span class="lbl">Outras despesas</span><div class="val r">${fmtNum(tot.vOutro)}</div></div>
    <div class="cel"><span class="lbl">Valor do IPI</span><div class="val r">${fmtNum(tot.vIPI)}</div></div>
    <div class="cel"><span class="lbl">Valor total da nota</span><div class="val r" style="font-size:10pt">${fmtNum(tot.vNF)}</div></div>
  </div>

  <!-- TRANSPORTADOR -->
  <div class="tit">Transportador / Volumes transportados</div>
  <div class="g">
    <div class="cel" style="flex:4"><span class="lbl">Razao social</span><div class="val">${campo(bloco(transpX,'transporta'),'xNome') || '-'}</div></div>
    <div class="cel" style="flex:2"><span class="lbl">Frete por conta</span><div class="val">${freteTxt}</div></div>
    <div class="cel" style="flex:1"><span class="lbl">Placa</span><div class="val">-</div></div>
    <div class="cel" style="flex:1"><span class="lbl">UF</span><div class="val">-</div></div>
    <div class="cel" style="flex:2"><span class="lbl">CNPJ / CPF</span><div class="val">${fmtDoc(campo(bloco(transpX,'transporta'),'CNPJ')) || '-'}</div></div>
  </div>
  <div class="g">
    <div class="cel"><span class="lbl">Quantidade</span><div class="val">${campo(bloco(transpX,'vol'),'qVol') || '-'}</div></div>
    <div class="cel"><span class="lbl">Especie</span><div class="val">${campo(bloco(transpX,'vol'),'esp') || '-'}</div></div>
    <div class="cel"><span class="lbl">Marca</span><div class="val">${campo(bloco(transpX,'vol'),'marca') || '-'}</div></div>
    <div class="cel"><span class="lbl">Numeracao</span><div class="val">${campo(bloco(transpX,'vol'),'nVol') || '-'}</div></div>
    <div class="cel"><span class="lbl">Peso bruto</span><div class="val">${campo(bloco(transpX,'vol'),'pesoB') || '-'}</div></div>
    <div class="cel"><span class="lbl">Peso liquido</span><div class="val">${campo(bloco(transpX,'vol'),'pesoL') || '-'}</div></div>
  </div>

  <!-- PRODUTOS -->
  <div class="tit">Dados dos produtos / servicos</div>
  <table class="itens">
    <thead><tr>
      <th style="width:8%">Codigo</th><th>Descricao do produto / servico</th>
      <th style="width:7%">NCM/SH</th><th style="width:5%">CST/CSOSN</th><th style="width:5%">CFOP</th>
      <th style="width:4%">Un</th><th style="width:7%">Qtd</th><th style="width:8%">Vl. unit.</th>
      <th style="width:8%">Vl. total</th><th style="width:8%">BC ICMS</th><th style="width:7%">Vl. ICMS</th><th style="width:5%">% ICMS</th>
    </tr></thead>
    <tbody>${linhasItens || '<tr><td colspan="12" class="c">Sem itens</td></tr>'}</tbody>
  </table>

  <!-- ESPAÇADOR — cresce pra empurrar Dados Adicionais + canhoto pro
       rodapé da folha, deixando o espaço em branco entre a tabela de
       produtos e o rodapé (e não dentro do próprio bloco de baixo). -->
  <div style="flex:1 1 auto"></div>

  <!-- DADOS ADICIONAIS (fixo no rodape da folha, como na nota em papel) -->
  <div class="tit" style="border-top:1px solid #000;margin-top:8px">Dados adicionais</div>
  <div class="g">
    <div class="cel" style="flex:3;min-height:70px"><span class="lbl">Informacoes complementares</span>
      <div style="font-size:7pt;line-height:1.3">${infCpl || ''}${infCpl ? '<br>' : ''}${campo(pagX,'tPag') ? 'Forma de pagamento informada no XML: ' + campo(pagX,'tPag') : ''}</div>
    </div>
    <div class="cel" style="flex:2;min-height:70px"><span class="lbl">Reservado ao fisco</span><div>&nbsp;</div></div>
  </div>

  <div class="tracejado"></div>

  <!-- CANHOTO / RECIBO — fica por ultimo, na base da folha, pra ser
       destacado (recorte) igual na nota impressa. -->
  <div class="recibo">
    <div class="cel" style="flex:3;border:none;border-right:1px solid #000">
      <span class="lbl">Recebemos de ${emit.nome} os produtos constantes da nota fiscal indicada ao lado</span>
      <div class="g" style="margin-top:2px">
        <div class="cel" style="flex:1;border:none;border-right:1px solid #000"><span class="lbl">Data de recebimento</span><div class="val">&nbsp;</div></div>
        <div class="cel" style="flex:2;border:none"><span class="lbl">Identificacao e assinatura do recebedor</span><div class="val">&nbsp;</div></div>
      </div>
    </div>
    <div class="cel c" style="flex:1;border:none"><b style="font-size:11pt">N&ordm; ${fmtNNF(nNF)}</b><div class="val">SERIE ${serie}<br>FOLHA 1/1</div></div>
  </div>
</div>
</body></html>`);
});

// ============================================================
//  ROTA: DANFE EM PDF (gerado no servidor com PDFKit, mantendo o
//  mesmo conteúdo e composição visual da DANFE exibida no navegador)
// ============================================================
// ?formato=a4 (padrão) | p80 (bobina 80mm) | p58 (bobina 58mm)

app.get('/danfe/:chave/pdf', (req, res) => {
  const chave = req.params.chave;
  const file  = encontrarArquivoPorChave(chave);
  if (!file) return res.status(404).send('Nota não encontrada para a chave informada.');


  const xml = fs.readFileSync(file, 'utf8');
  const rejeitada = file.includes('_REJEITADA');
  const modXml1856 = (xml.match(/<mod>(\d+)<\/mod>/) || [])[1];
  const isNFCe = modXml1856 ? modXml1856 === '65' : path.basename(file).startsWith('nfce_');

  const nNF     = campo(xml, 'nNF');
  const serie   = campo(xml, 'serie');
  const dhEmi   = campo(xml, 'dhEmi');
  const xNomeEmit = campo(xml, 'xNome');
  const cnpjEmit  = campo(xml, 'CNPJ');
  const nProt   = campo(xml, 'nProt');
  const vNF     = campo(xml, 'vNF');
  const nomes  = [...xml.matchAll(/<xNome>([^<]*)<\/xNome>/g)].map(m => m[1]);
  const xNomeDest = nomes[1] || 'CONSUMIDOR';
  const itensXml = [...xml.matchAll(/<det nItem="(\d+)">([\s\S]*?)<\/det>/g)].map(([_, nItem, det]) => {
    const prod = bloco(det, 'prod');
    const icmsBloco = bloco(det, 'ICMS');
    return {
      nItem, cProd: campo(prod, 'cProd'), xProd: campo(prod, 'xProd'), ncm: campo(prod, 'NCM'),
      cfop: campo(prod, 'CFOP'), uCom: campo(prod, 'uCom'),
      qCom: campo(prod, 'qCom'), vUnCom: campo(prod, 'vUnCom'), vProd: campo(prod, 'vProd'),
      // Mesma regra da versão HTML: CSOSN (Simples Nacional) tem prioridade;
      // senão monta Origem+CST (padrão do regime normal). Tudo isolado ao
      // bloco <ICMS> do item, pra não colidir com o <CST> de PIS/COFINS
      // que vem logo depois no mesmo <det>.
      cst: (campo(icmsBloco, 'CSOSN') || ((campo(icmsBloco, 'orig') || '0') + (campo(icmsBloco, 'CST') || '')))
             || campo(icmsBloco, 'CST'),
      vBC: campo(icmsBloco, 'vBC') || '0.00',
      vICMS: campo(icmsBloco, 'vICMS') || '0.00',
      pICMS: campo(icmsBloco, 'pICMS') || '0.00',
    };
  });

  // Dados compartilhados com a DANFE visual, para que o PDF do servidor
  // use os mesmos valores e a mesma configuração da tela de visualização.
  const ideX=bloco(xml,'ide');
  const emitX=bloco(xml,'emit');
  const enderE=bloco(emitX,'enderEmit');
  const destX=bloco(xml,'dest');
  const enderD=bloco(destX,'enderDest');
  const totX=bloco(bloco(xml,'total'),'ICMSTot');
  const transpX=bloco(xml,'transp');
  const pagX=bloco(xml,'pag');
  const infAdX=bloco(xml,'infAdic');
  const natOp=campo(ideX,'natOp');
  const tpNF=campo(ideX,'tpNF')==='0'?'ENTRADA':'SAIDA';
  const emi=fmtDataHora(dhEmi);
  const said=fmtDataHora(campo(ideX,'dhSaiEnt')||dhEmi);
  const emitCnpjRaw=String(cnpjEmit||'').replace(/\D/g,'');
  const emitEhAguaMister=emitCnpjRaw===String(EMPRESA.cnpj||'').replace(/\D/g,'');
  const emit={
    ie:campo(emitX,'IE')||EMPRESA.ie,
    cnpj:fmtDoc(cnpjEmit||EMPRESA.cnpj)
  };
  const dest={
    nome:campo(destX,'xNome')||xNomeDest,
    doc:fmtDoc(campo(destX,'CNPJ')||campo(destX,'CPF')),
    ie:campo(destX,'IE'),
    lgr:campo(enderD,'xLgr'), nro:campo(enderD,'nro'),
    bairro:campo(enderD,'xBairro'), mun:campo(enderD,'xMun'),
    uf:campo(enderD,'UF'), cep:fmtCep(campo(enderD,'CEP')),
    fone:fmtFone(campo(enderD,'fone'))
  };
  const tot={
    vBC:campo(totX,'vBC'),vICMS:campo(totX,'vICMS'),vBCST:campo(totX,'vBCST'),vST:campo(totX,'vST'),
    vProd:campo(totX,'vProd'),vFrete:campo(totX,'vFrete'),vSeg:campo(totX,'vSeg'),vDesc:campo(totX,'vDesc'),
    vOutro:campo(totX,'vOutro'),vIPI:campo(totX,'vIPI'),vNF:campo(totX,'vNF')||vNF
  };
  const freteTxt=({'0':'0-EMITENTE','1':'1-DESTINATARIO','2':'2-TERCEIROS','3':'3-PROPRIO/REM','4':'4-PROPRIO/DEST','9':'9-SEM FRETE'})[campo(transpX,'modFrete')]||'9-SEM FRETE';
  const infCpl=campo(infAdX,'infCpl');
  const cobrX = bloco(xml, 'cobr');
  const duplicatas = [...cobrX.matchAll(/<dup>([\s\S]*?)<\/dup>/g)].map(([_, dupBloco]) => ({
    nDup:  campo(dupBloco, 'nDup'),
    dVenc: fmtDataHora(campo(dupBloco, 'dVenc') + 'T00:00:00').data,
    vDup:  campo(dupBloco, 'vDup'),
  }));

  const formato = req.query.formato || 'a4';
  // Tamanhos em pontos (1mm = 2.8346pt). Bobina térmica: altura livre
  // (cresce com o conteúdo), largura fixa conforme a bobina.
  const larguras = { a4: 595.28, p80: 226.77, p58: 164.4 };
  const largura  = larguras[formato] || larguras.a4;
  const altura   = formato === 'a4' ? 841.89 : Math.max(400, 220 + itensXml.length * 26);

  const doc = new PDFDocument({ size: [largura, altura], margin: formato === 'a4' ? 36 : 10 });
  const nomePdf = `danfe_${String(chave).replace(/\D/g,'')}_${formato}.pdf`;
  const caminhoPdf = path.join(PASTA_DANFE_PDF, nomePdf);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="danfe_${String(chave).replace(/\D/g,'')}.pdf"`);

  // Primeiro grava o PDF completo em disco; somente depois envia o arquivo
  // ao navegador. Isso evita PDF truncado quando a resposta HTTP e o arquivo
  // são alimentados simultaneamente pelo PDFKit.
  let saidaPdf;
  try {
    saidaPdf = fs.createWriteStream(caminhoPdf);
    saidaPdf.on('error', err => {
      console.log('[!] Falha ao salvar DANFE PDF:', err.message);
      if (!res.headersSent) res.status(500).send('Não foi possível gerar o PDF da DANFE.');
      else res.end();
    });
    saidaPdf.on('finish', () => {
      try {
        const dadosPdf = fs.readFileSync(caminhoPdf);
        if (!res.headersSent) res.setHeader('Content-Length', String(dadosPdf.length));
        res.end(dadosPdf);
      } catch (err) {
        if (!res.headersSent) res.status(500).send('Não foi possível ler o PDF gerado.');
        else res.end();
      }
    });
    doc.pipe(saidaPdf);
  } catch (e) {
    console.log('[!] Não foi possível preparar o arquivo PDF:', e.message);
    return res.status(500).send('Não foi possível gerar o PDF da DANFE.');
  }

  // O PDF A4 usa a mesma composição visual da DANFE exibida no navegador:
  // caixas, cabeçalho, logotipo, chave/barras, destinatário, impostos,
  // transportador, produtos e dados adicionais. Mantemos PDFKit para não
  // introduzir dependência externa nem alterar o funcionamento do backend.
  const fsz = formato === 'a4' ? 7.2 : 7;
  const logoDataUrl = obterLogoDataUrl();
  const margem = formato === 'a4' ? 17 : 10;
  const conteudoW = largura - margem * 2;
  const preto = '#000000';
  const cinza = '#555555';

  function box(x,y,w,h){ doc.save().lineWidth(0.65).rect(x,y,w,h).stroke(preto).restore(); }
  function cell(x,y,w,h,label,value,opt){
    opt=opt||{}; box(x,y,w,h);
    doc.fillColor(preto).font('Helvetica').fontSize(opt.labelSize||4.8).text(String(label||'').toUpperCase(),x+3,y+2,{width:w-6,height:7,ellipsis:false});
    doc.font(opt.bold===false?'Helvetica':'Helvetica-Bold').fontSize(opt.valueSize||7.2)
      .text(String(value==null?'':value),x+3,y+(opt.valueY||9),{width:w-6,height:h-(opt.valueY||9)-2,align:opt.align||'left',ellipsis:false,lineGap:0});
  }
  function centerText(txt,x,y,w,size,bold){
    doc.font(bold?'Helvetica-Bold':'Helvetica').fontSize(size||7).fillColor(preto).text(String(txt||''),x,y,{width:w,align:'center',lineGap:0});
  }
  function drawBarcodePdf(digitos,x,y,w,h){
    const d=String(digitos).replace(/\D/g,'');
    const src=d.length%2?d+'0':d;
    const pares=[]; for(let i=0;i<src.length;i+=2) pares.push(parseInt(src.substr(i,2),10));
    const codes=[105].concat(pares); let soma=105; pares.forEach((v,i)=>soma+=v*(i+1)); codes.push(soma%103,106);
    let padrao=''; codes.forEach(c=>{padrao+=C128_PAD[c]||'212222';});
    const mods=padrao.split('').reduce((a,b)=>a+parseInt(b,10),0); const escala=w/mods;
    let xx=x, black=true;
    doc.save().fillColor(preto);
    for(const ch of padrao){const ww=parseInt(ch,10)*escala;if(black)doc.rect(xx,y,ww,h).fill();xx+=ww;black=!black;}
    doc.restore();
  }

  doc.font('Helvetica').fillColor(preto);
  const x0=margem, y0=margem;
  let y=y0, xx=x0;

  // CABEÇALHO PRINCIPAL
  const hCab=100, wEsq=conteudoW*0.40, wMid=conteudoW*0.16, wCh=conteudoW-wEsq-wMid;
  box(x0,y,conteudoW,hCab);
  box(x0,y,wEsq,hCab); box(x0+wEsq,y,wMid,hCab); box(x0+wEsq+wMid,y,wCh,hCab);
  const cnpjFmt=fmtDoc(cnpjEmit||EMPRESA.cnpj);
  const cnpjPdfEmit=String(cnpjEmit||'').replace(/\D/g,'');
  const enderecoEmit=(cnpjPdfEmit && cnpjPdfEmit===String(EMPRESA.cnpj||'').replace(/\D/g,''))
    ? `${EMPRESA.logradouro}, ${EMPRESA.numero}${EMPRESA.complemento?' '+EMPRESA.complemento:''}\n${EMPRESA.bairro} - ${EMPRESA.municipio}/${EMPRESA.uf} - CEP ${fmtCep(EMPRESA.cep)}\nFone: ${fmtFone(EMPRESA.fone)}`
    : `${campo(enderE,'xLgr')||''}, ${campo(enderE,'nro')||''}${campo(enderE,'xCpl')?' '+campo(enderE,'xCpl'):''}\n${campo(enderE,'xBairro')||''} - ${campo(enderE,'xMun')||''}/${campo(enderE,'UF')||''} - CEP ${fmtCep(campo(enderE,'CEP'))}\nFone: ${fmtFone(campo(enderE,'fone'))}`;

  // Emitente: logo ao lado do nome/endereço, sem ocupar a área da chave.
  if(logoDataUrl && logoDataUrl.startsWith('data:image')){
    try{ const buf=Buffer.from(logoDataUrl.split(',')[1],'base64'); doc.image(buf,x0+7,y+9,{fit:[43,43],align:'left',valign:'center'}); }catch(e){}
  }
  const infoX=x0+55, infoW=wEsq-61;
  doc.font('Helvetica-Bold').fontSize(8.5).text(String(xNomeEmit||EMPRESA.nome),infoX,y+9,{width:infoW,height:22,align:'left',lineGap:0});
  doc.font('Helvetica').fontSize(6.5).text(enderecoEmit,infoX,y+30,{width:infoW,height:34,align:'left',lineGap:1});

  centerText('DANFE',x0+wEsq,y+7,wMid,15,true);
  centerText('Documento Auxiliar da\nNota Fiscal Eletrônica',x0+wEsq,y+28,wMid,6,false);
  centerText('0 - ENTRADA   1 - SAÍDA',x0+wEsq,y+46,wMid,5.8,false);
  centerText(`${tpNF==='SAIDA'?'1':'0'} - ${tpNF}`,x0+wEsq,y+56,wMid,7,true);
  centerText(`Nº ${fmtNNF(nNF)}  SERIE ${serie}`,x0+wEsq,y+69,wMid,6.8,true);
  centerText('FOLHA 1/1',x0+wEsq,y+79,wMid,6.8,true);

  drawBarcodePdf(chave,x0+wEsq+wMid+7,y+8,wCh-14,32);
  centerText('CHAVE DE ACESSO',x0+wEsq+wMid,y+42,wCh,4.8,false);
  centerText(chaveFormatada(chave),x0+wEsq+wMid,y+49,wCh,6.7,true);
  centerText('Consulta de autenticidade no portal nacional da NF-e',x0+wEsq+wMid,y+64,wCh,4.8,false);
  centerText('www.nfe.fazenda.gov.br/portal ou no site da Sefaz autorizadora',x0+wEsq+wMid,y+72,wCh,4.5,false);
  y+=hCab+2;

  // NATUREZA / PROTOCOLO
  cell(x0,y,conteudoW*0.58,24,'Natureza da operação',natOp,{valueSize:7.5});
  cell(x0+conteudoW*0.58,y,conteudoW*0.42,24,'Protocolo de autorização de uso',nProt ? `${nProt}${dhEmi?' - '+fmtDataHora(campo(xml,'dhRecbto')).data+' '+fmtDataHora(campo(xml,'dhRecbto')).hora:''}` : (rejeitada?'NÃO AUTORIZADA':''),{valueSize:7});
  y+=26;
  cell(x0,y,conteudoW*0.33,25,'Inscrição estadual',emit.ie,{valueSize:7.5});
  cell(x0+conteudoW*0.33,y,conteudoW*0.34,25,'Inscrição estadual do subst. tributário','',{valueSize:7.5});
  cell(x0+conteudoW*0.67,y,conteudoW*0.33,25,'CNPJ',emit.cnpj,{valueSize:7.5});
  y+=27;

  // DESTINATÁRIO
  centerText('DESTINATÁRIO / REMETENTE',x0,y,conteudoW,7.2,true); y+=10;
  const d1=conteudoW*0.58,d2=conteudoW*0.22,d3=conteudoW-d1-d2;
  cell(x0,y,d1,25,'Nome / Razão social',dest.nome,{valueSize:7.4}); cell(x0+d1,y,d2,25,'CNPJ / CPF',dest.doc||'-',{valueSize:7.2}); cell(x0+d1+d2,y,d3,25,'Data de emissão',emi.data,{valueSize:7.2}); y+=25;
  const a1=conteudoW*0.47,a2=conteudoW*0.20,a3=conteudoW*0.10,a4=conteudoW-a1-a2-a3;
  cell(x0,y,a1,25,'Endereço',dest.lgr?`${dest.lgr}, ${dest.nro}`:'-',{valueSize:7.1}); cell(x0+a1,y,a2,25,'Bairro / Distrito',dest.bairro||'-',{valueSize:7.1}); cell(x0+a1+a2,y,a3,25,'CEP',dest.cep||'-',{valueSize:7.1}); cell(x0+a1+a2+a3,y,a4,25,'Data de saída / entrada',said.data,{valueSize:7.0}); y+=25;
  const m1=conteudoW*0.33,m2=conteudoW*0.22,m3=conteudoW*0.08,m4=conteudoW-m1-m2-m3;
  cell(x0,y,m1,25,'Município',dest.mun||'-',{valueSize:7.1}); cell(x0+m1,y,m2,25,'Fone / Fax',dest.fone||'-',{valueSize:7.1}); cell(x0+m1+m2,y,m3,25,'UF',dest.uf||'-',{valueSize:7.1,align:'center'}); cell(x0+m1+m2+m3,y,m4,25,'Inscrição estadual / Hora saída',`${dest.ie||'-'}  ${said.hora||''}`,{valueSize:6.6}); y+=27;

  // FATURA — vencimento(s) da venda (grupo cobr/dup do XML). Sempre
  // aparece, igual na nota impressa (em branco quando à vista). Com
  // muitas parcelas, quebra em linhas de até 4 (12 células) em vez de
  // espremer tudo numa linha só.
  centerText('FATURA',x0,y,conteudoW,7.2,true); y+=10;
  if(duplicatas.length){
    const PARCELAS_POR_LINHA_PDF = 4;
    const dw=conteudoW/(PARCELAS_POR_LINHA_PDF*3);
    for(let i=0;i<duplicatas.length;i+=PARCELAS_POR_LINHA_PDF){
      const linha=duplicatas.slice(i,i+PARCELAS_POR_LINHA_PDF);
      xx=x0;
      linha.forEach(d=>{
        cell(xx,y,dw,22,'Número',d.nDup,{valueSize:6.6}); xx+=dw;
        cell(xx,y,dw,22,'Valor',fmtNum(d.vDup),{valueSize:6.6}); xx+=dw;
        cell(xx,y,dw,22,'Vencimento',d.dVenc,{valueSize:6.6}); xx+=dw;
      });
      y+=22;
    }
    y-=22; // compensa o +24 fixo logo abaixo, que já soma a última linha
  } else {
    const dw=conteudoW/3;
    cell(x0,y,dw,22,'Número',nNF,{valueSize:6.6});
    cell(x0+dw,y,dw,22,'Valor',fmtNum(tot.vNF),{valueSize:6.6});
    cell(x0+dw*2,y,dw,22,'Vencimento',said.data,{valueSize:6.6});
  }
  y+=24;

  // CÁLCULO DO IMPOSTO
  centerText('CÁLCULO DO IMPOSTO',x0,y,conteudoW,7.2,true); y+=10;
  const impostos=[['Base de cálculo do ICMS',fmtNum(tot.vBC)],['Valor do ICMS',fmtNum(tot.vICMS)],['Base de cálc. ICMS ST',fmtNum(tot.vBCST)],['Valor do ICMS ST',fmtNum(tot.vST)],['Valor total dos produtos',fmtNum(tot.vProd)]];
  let iw; iw=conteudoW/5; xx=x0; impostos.forEach(([l,v])=>{cell(xx,y,iw,24,l,v,{valueSize:7.0,align:'right'});xx+=iw;}); y+=24;
  const imp2=[['Valor do frete',fmtNum(tot.vFrete)],['Valor do seguro',fmtNum(tot.vSeg)],['Desconto',fmtNum(tot.vDesc)],['Outras despesas',fmtNum(tot.vOutro)],['Valor do IPI',fmtNum(tot.vIPI)],['Valor total da nota',fmtNum(tot.vNF)]];
  xx=x0; const iw2=conteudoW/6; imp2.forEach(([l,v],i)=>{cell(xx,y,iw2,24,l,v,{valueSize:i===5?8.5:7.0,align:'right'});xx+=iw2;}); y+=27;

  // TRANSPORTADOR
  centerText('TRANSPORTADOR / VOLUMES TRANSPORTADOS',x0,y,conteudoW,7.2,true); y+=10;
  const transNome=campo(bloco(transpX,'transporta'),'xNome')||'-';
  const tw=[conteudoW*.36,conteudoW*.18,conteudoW*.12,conteudoW*.07,conteudoW*.27]; xx=x0;
  [['Nome / Razão social',transNome],['Frete por conta',freteTxt],['Placa','-'],['UF','-'],['CNPJ / CPF',fmtDoc(campo(bloco(transpX,'transporta'),'CNPJ'))||'-']].forEach((a,i)=>{cell(xx,y,tw[i],25,a[0],a[1],{valueSize:6.7});xx+=tw[i];}); y+=27;
  const volX=bloco(transpX,'vol');
  const volCols=[conteudoW*.16,conteudoW*.20,conteudoW*.20,conteudoW*.20,conteudoW*.12,conteudoW*.12]; xx=x0;
  [['Quantidade',campo(volX,'qVol')||'-'],['Espécie',campo(volX,'esp')||'-'],['Marca',campo(volX,'marca')||'-'],['Numeração',campo(volX,'nVol')||'-'],['Peso bruto',campo(volX,'pesoB')||'-'],['Peso líquido',campo(volX,'pesoL')||'-']]
    .forEach((a,i)=>{cell(xx,y,volCols[i],25,a[0],a[1],{valueSize:6.7});xx+=volCols[i];}); y+=27;

  // PRODUTOS
  centerText('DADOS DOS PRODUTOS / SERVIÇOS',x0,y,conteudoW,7.2,true); y+=10;
  const cols=[36,180,38,28,28,20,32,40,40,40,36,43];
  const headers=['Código','Descrição do produto / serviço','NCM/SH','CST/CSOSN','CFOP','Un','Qtd','Vl. unit.','Vl. total','BC ICMS','Vl. ICMS','% ICMS'];
  xx=x0; headers.forEach((h,i)=>{box(xx,y,cols[i],22);doc.font('Helvetica-Bold').fontSize(4.7).text(h.toUpperCase(),xx+1,y+5,{width:cols[i]-2,align:'center',height:14});xx+=cols[i];}); y+=22;
  itensXml.forEach(it=>{
    const vals=[it.cProd||'',it.xProd||'',it.ncm||'',it.cst||'',it.cfop||'',it.uCom||'',fmtNum(it.qCom,3),fmtNum(it.vUnCom),fmtNum(it.vProd),fmtNum(it.vBC||0),fmtNum(it.vICMS||0),fmtNum(it.pICMS||0,2)];
    xx=x0; vals.forEach((v,i)=>{box(xx,y,cols[i],18);doc.font('Helvetica').fontSize(5.4).text(String(v),xx+1,y+5,{width:cols[i]-2,align:(i===1?'left':'center'),height:11,ellipsis:true});xx+=cols[i];}); y+=18;
  });
  // DADOS ADICIONAIS — no modelo de referência esse bloco fica ancorado
  // perto do rodapé, com altura normal (não esticada), deixando o espaço
  // em branco REAL (sem caixa/borda) entre a tabela de produtos e ele -
  // igual ao padrão usado pela maioria dos emissores de NF-e. A versão
  // anterior esticava a própria caixa de Dados Adicionais pra preencher
  // o vão, o que desenhava uma borda gigante em vez de deixar em branco.
  const reciboH=42, gapCanhoto=6, adHFixo=95;
  const yProdutosFim = y; // logo depois da última linha de produto
  const limiteRodape = altura - margem - reciboH - gapCanhoto;
  const yDadosAdicionais = Math.max(yProdutosFim, limiteRodape - adHFixo);
  y = yDadosAdicionais;
  centerText('DADOS ADICIONAIS',x0,y,conteudoW,7.2,true); y+=10;
  const adW=conteudoW*0.60;
  const adH = Math.max(40, limiteRodape - y); // nunca negativo se a lista de itens for longa
  cell(x0,y,adW,adH,'Informações complementares',`${infCpl||''}${infCpl?'\n':''}${campo(pagX,'tPag')?'Forma de pagamento informada no XML: '+campo(pagX,'tPag'):''}`,{valueSize:6.0,valueY:10,bold:false});
  cell(x0+adW,y,conteudoW-adW,adH,'Reservado ao fisco','',{valueSize:6.0,bold:false});
  y+=adH;

  // Linha tracejada de corte, separando Dados Adicionais do canhoto.
  doc.save().dash(3,{space:2}).moveTo(x0,y+3).lineTo(x0+conteudoW,y+3).stroke().undash().restore();

  // CANHOTO / RECIBO — ancorado na base real da folha.
  const yCanhoto = altura - margem - reciboH;
  const reciboLeft=conteudoW*0.75, reciboRight=conteudoW-reciboLeft;
  box(x0,yCanhoto,conteudoW,reciboH);
  doc.fontSize(5.2).font('Helvetica').fillColor(preto).text(`RECEBEMOS DE ${String(xNomeEmit||EMPRESA.nome).toUpperCase()} OS PRODUTOS E/OU SERVIÇOS CONSTANTES DA NOTA FISCAL ELETRÔNICA INDICADA AO LADO.`,x0+3,yCanhoto+3,{width:reciboLeft-8,height:10});
  cell(x0,yCanhoto+13,reciboLeft*0.30,reciboH-13,'Data de recebimento','');
  cell(x0+reciboLeft*0.30,yCanhoto+13,reciboLeft*0.70,reciboH-13,'Identificação e assinatura do recebedor','');
  cell(x0+reciboLeft,yCanhoto,reciboRight,reciboH,'Nº',`Nº ${fmtNNF(nNF)}\nSÉRIE ${serie}\nFOLHA 1/1`,{valueSize:7.5,align:'center',valueY:9});

  if(rejeitada){
    doc.font('Helvetica-Bold').fontSize(6.8).fillColor('#a00000').text('NOTA NÃO AUTORIZADA PELA SEFAZ - XML assinado e recusado na transmissão. Sem validade fiscal.',x0,y-8,{width:conteudoW,align:'center'});
  }

  doc.end();
});

// ============================================================
//  ROTA: STATUS SEFAZ (consulta de disponibilidade)
// ============================================================

// Consulta REAL do servico de status da SEFAZ-SP (NfeStatusServico4),
// usando o certificado A1 em mTLS. Serve tambem como teste de ponta a
// ponta da comunicacao antes de emitir qualquer nota.
const ENDPOINTS_STATUS = {
  nfe: {
    '1': 'https://nfe.fazenda.sp.gov.br/ws/nfestatusservico4.asmx',
    '2': 'https://homologacao.nfe.fazenda.sp.gov.br/ws/nfestatusservico4.asmx',
  },
  nfce: {
    '1': 'https://nfce.fazenda.sp.gov.br/ws/NFeStatusServico4.asmx',
    '2': 'https://homologacao.nfce.fazenda.sp.gov.br/ws/NFeStatusServico4.asmx',
  },
};

async function consultarStatusSEFAZ(tpAmb, modelo) {
  const tipo = String(modelo || '55') === '65' ? 'nfce' : 'nfe';
  const url = ENDPOINTS_STATUS[tipo][tpAmb] || ENDPOINTS_STATUS[tipo]['2'];
  const consulta = `<consStatServ xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">`
    + `<tpAmb>${tpAmb}</tpAmb><cUF>${somenteDigitos(EMPRESA.cuf)}</cUF><xServ>STATUS</xServ>`
    + `</consStatServ>`;

  // Mesma regra: mensagem em uma linha só, sem espaço/quebra de linha
  // entre tags (evita a rejeição cStat 588 da SEFAZ).
  const soapEnv = `<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeStatusServico4">${consulta}</nfeDadosMsg></soap12:Body></soap12:Envelope>`;

  if (!CERT_STATE.loaded) throw new Error('Certificado A1 nao carregado - a SEFAZ exige certificado para responder.');
  const certPem = fs.readFileSync(path.join(__dirname, 'cert.pem'));
  const keyPem  = fs.readFileSync(path.join(__dirname, 'key.pem'));
  const soapAction = 'http://www.portalfiscal.inf.br/nfe/wsdl/NFeStatusServico4/nfeStatusServicoNF';

  const resp = await httpsPostSefaz({ url, soapEnv, soapAction, certPem, keyPem, timeout: 20000 });
  return { http: resp.http, xml: resp.xml, url, diagConexao: resp.diagConexao };
}

// Diagnóstico independente da resolução da cadeia de certificados —
// não emite nada, só testa e mostra exatamente o que cada camada
// (handshake, AIA, raiz oficial ICP-Brasil, sistema operacional)
// conseguiu encontrar para o host da SEFAZ.
app.get('/api/sefaz/diagnostico-certificado', async (req, res) => {
  const tpAmb = req.query.tpAmb === '1' ? '1' : '2';
  const modelo = String(req.query.modelo || req.query.mod || '55') === '65' ? '65' : '55';
  const tipo = modelo === '65' ? 'nfce' : 'nfe';
  const hostname = new URL(ENDPOINTS[tipo][tpAmb]).hostname;
  const diag = { versaoBackend: '1.6.0', node: process.version, plataforma: process.platform, host: hostname, modelo, endpoint: ENDPOINTS[tipo][tpAmb] };
  try {
    const cadeia = await resolverCadeiaCA(hostname, diag);
    diag.totalCertsResolvidos = (cadeia.match(/BEGIN CERTIFICATE/g) || []).length;
    diag.sucesso = diag.totalCertsResolvidos > 0;
    res.json({ ok: true, diagnostico: diag });
  } catch (err) {
    diag.erroInesperado = err.message;
    res.json({ ok: false, diagnostico: diag });
  }
});

app.get('/api/sefaz/status', async (req, res) => {
  const tpAmb = req.query.tpAmb === '2' ? '2' : (AMBIENTE_ATUAL === 'producao' ? '1' : '2');
  const ambienteTxt = tpAmb === '1' ? 'Produção' : 'Homologação';
  try {
    const modelo = String(req.query.modelo || req.query.mod || '55') === '65' ? '65' : '55';
    const r = await consultarStatusSEFAZ(tpAmb, modelo);
    const resultado = parseSEFAZResp(r.xml, r.http);
    const tMed = (r.xml.match(/<tMed>(\d+)<\/tMed>/) || [])[1] || '';
    const dhRetorno = (r.xml.match(/<dhRetorno>([^<]+)<\/dhRetorno>/) || [])[1] || '';
    res.json({
      ok: true,
      online: resultado.cStat === '107',
      cStat: resultado.cStat, xMotivo: resultado.xMotivo, tMed, dhRetorno,
      ambiente: ambienteTxt,
      modelo,
      url: r.url,
      http: r.http,
      cert: CERT_STATE.loaded ? 'Carregado' : 'Não carregado',
      detalhe: resultado.cStat === '107' ? undefined : _detalheDiagConexao(r),
      mensagem: resultado.cStat === '107'
        ? `SEFAZ ${ambienteTxt} respondeu: serviço em operação (tempo médio ${tMed || '?'}s)`
        : (resultado.xMotivo || 'A SEFAZ respondeu, mas o serviço não está em operação agora.'),
    });
  } catch (err) {
    const cls = classificarErroEmissao(err);
    res.json({
      ok: false, online: false, ambiente: ambienteTxt,
      cert: CERT_STATE.loaded ? 'Carregado' : 'Não carregado',
      erro: err.message, ...cls,
    });
  }
});

// ============================================================
//  ROTA: NUMERAÇÃO
// ============================================================

app.get('/api/numeracao', (req, res) => res.json({ ok: true, numeracao: NUMERACAO }));
app.post('/api/numeracao', (req, res) => {
  const { nfe, nfce } = req.body;
  if (nfe  !== undefined) NUMERACAO.nfe  = parseInt(nfe);
  if (nfce !== undefined) NUMERACAO.nfce = parseInt(nfce);
  salvarNumeracao();
  res.json({ ok: true, numeracao: NUMERACAO });
});

// Monitoramento leve por varredura periódica. Não depende de chokidar
// nem de recursos específicos do sistema operacional e continua funcionando
// mesmo com subpastas dentro da pasta selecionada.
setInterval(()=>{
  if(XML_SYNC.ativo){ try{ sincronizarPastaXml(); }catch(e){ console.log('[!] Falha na sincronização automática:',e.message); } }
},5000);

// ============================================================
//  INICIAR SERVIDOR
// ============================================================

// Por padrão, escuta só em 127.0.0.1 (loopback) - só a própria máquina
// acessa, é o modo seguro para uso local. Se você for hospedar o
// backend num servidor (VPS, etc.) e precisar aceitar conexões de
// fora, defina a variável de ambiente HOST=0.0.0.0 antes de iniciar -
// mas nesse caso COLOQUE um proxy HTTPS na frente (nginx/Caddy) e
// restrinja o acesso, porque este backend guarda o certificado A1 em
// texto puro no disco (cert.pem/key.pem) e não tem autenticação própria.
const HOST = process.env.HOST || '127.0.0.1';

app.listen(PORT, HOST, () => {
  tentarAutoCarregarCertificado();
  console.log('\n========================================================');
  console.log('|    ERP AGUA MISTER - Backend NF-e/NFC-e v1.7.0        |');
  console.log('========================================================');
  console.log(`|  Servidor:    http://${HOST}:${PORT}                  `);
  console.log(`|  Ambiente:    ${AMBIENTE_ATUAL.toUpperCase().padEnd(36)}|`);
  if (HOST !== '127.0.0.1') {
    console.log('|  [!]  ESCUTANDO EM REDE - use HTTPS/proxy e restrinja  |');
    console.log('|      o acesso; este backend não tem login próprio.    |');
  }
  console.log('========================================================');
  console.log('|  Carregue o certificado .pfx via API ou pelo ERP     |');
  console.log('========================================================\n');
});

module.exports = app;
