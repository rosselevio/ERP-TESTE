@echo off
setlocal
title ERP Agua Mister - Backend NF-e / NFC-e
color 0A
cd /d "%~dp0"

echo ==========================================================
echo    ERP AGUA MISTER - Backend NF-e / NFC-e (porta 3000)
echo ==========================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo [ERRO] Node.js nao encontrado.
  echo Baixe a versao LTS em https://nodejs.org e instale.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo Instalando dependencias ^(primeira execucao, pode demorar^)...
  call npm install
  if errorlevel 1 (
    echo [ERRO] Falha ao instalar dependencias.
    pause
    exit /b 1
  )
  echo.
)

REM Ambiente da SEFAZ: homologacao (teste) ou producao (nota valida)
if "%NFE_AMBIENTE%"=="" set NFE_AMBIENTE=homologacao
echo Ambiente SEFAZ: %NFE_AMBIENTE%
echo.
echo Servidor iniciando... NAO FECHE ESTA JANELA.
echo Para encerrar o backend, pressione CTRL+C.
echo.

node server.js
echo.
echo [AVISO] O servidor foi encerrado.
pause
