#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "[ERRO] Node.js nao encontrado. Instale a versao LTS: https://nodejs.org"
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "Instalando dependencias (primeira execucao)..."
  npm install
fi
export NFE_AMBIENTE="${NFE_AMBIENTE:-homologacao}"
echo "Ambiente SEFAZ: $NFE_AMBIENTE"
echo "Servidor em http://localhost:3000  (CTRL+C para encerrar)"

# Inicia o backend em segundo plano somente para permitir a abertura
# automática do ERP no navegador; o script continua aguardando o processo.
node server.js &
SERVER_PID=$!
sleep 2
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "http://localhost:3000" >/dev/null 2>&1 &
else
  echo "Abra manualmente: http://localhost:3000"
fi
wait "$SERVER_PID"
